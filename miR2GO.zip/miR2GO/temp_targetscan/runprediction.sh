#!/bin/bash

kv=$1
algo=$2
mirid=$3
point=$4
allele=$5
thrval=$6
filter=$7

mirname=$mirid"_"$point"_"$allele

export LC_ALL="C"

#input files

tp="./temp/"$kv

mut_t=$tp$mirname"mut_t.tmp"
ref_t=$tp$mirname"ref_t.tmp"
mut=$tp$mirname"mut.tmp"
ref=$tp$mirname"ref.tmp"


data1_tmp=$tp"data1.tmp"
data2_tmp=$tp"data2.tmp"

data1m_tmp=$tp"data1m.tmp"
data2m_tmp=$tp"data2m.tmp"

data1t_tmp=$tp"data1t.tmp"
data2t_tmp=$tp"data2t.tmp"


data1txt=$tp"data1txt.tmp"
data2txt=$tp"data2txt.tmp"
data3txt=$tp"data3txt.tmp"

f_output=$tp"output.tmp" 
gossfile=$f_output".goss"

gossfiletemp=$f_output".goss.tmp"

f_ref="./disrupted/"$kv$mirname
f_mut="./created/"$kv$mirname
f_common="./common/"$kv$mirname
f_figinput=$tp$mirname"figBP"
f_figinputMF=$tp$mirname"figMF"
f_figinputCC=$tp$mirname"figCC"


predict_ref_human_t=$tp$mirname"predict_ref_human_t.tmp"
predict_mut_human_t=$tp$mirname"predict_mut_human_t.tmp"


predict_ref_human_m=$tp$mirname"predict_ref_human_m.tmp"
predict_mut_human_m=$tp$mirname"predict_mut_human_m.tmp"

newresultref_miranda=$tp$mirname"predict_ref_human_tmp.tmp"
newresultmut_miranda=$tp$mirname"predict_mut_human_tmp.tmp"



if [ $algo == "TS" ] 
then

	./targetscan_60.pl $ref_t UTR_Sequences_humanonly $predict_ref_human_t
	./targetscan_60.pl $mut_t UTR_Sequences_humanonly $predict_mut_human_t
	cat $predict_ref_human_t|cut -f1>$data1_tmp
	cat $predict_mut_human_t|cut -f1>$data2_tmp
	awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt
elif [ $algo == "MR" ] 
then

	../miRanda-3.3a/bin/miranda  $ref 3utr.fasta -out $newresultref_miranda
	../miRanda-3.3a/bin/miranda  $mut 3utr.fasta -out $newresultmut_miranda
	grep ">>" $newresultref_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_ref_human_m   
	grep ">>" $newresultmut_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_mut_human_m   
	cat $predict_ref_human_m|cut -f2>$data1_tmp
	cat $predict_mut_human_m|cut -f2>$data2_tmp
	awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt
	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">$predict_ref_human_t
	cat $predict_ref_human_m>>$predict_ref_human_t
	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">$predict_mut_human_t
	cat $predict_mut_human_m>>$predict_mut_human_t

elif [ $algo == "TSunionMR" ] 
then

	./targetscan_60.pl $ref_t UTR_Sequences_humanonly $predict_ref_human_t
	./targetscan_60.pl $mut_t UTR_Sequences_humanonly $predict_mut_human_t
	cat $predict_ref_human_t|cut -f1>$data1m_tmp
	cat $predict_mut_human_t|cut -f1>$data2m_tmp

	../miRanda-3.3a/bin/miranda  $ref 3utr.fasta -out $newresultref_miranda
	../miRanda-3.3a/bin/miranda  $mut 3utr.fasta -out $newresultmut_miranda
	grep ">>" $newresultref_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_ref_human_m   
	grep ">>" $newresultmut_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_mut_human_m   
	cat $predict_ref_human_m|cut -f2>>$data1m_tmp
	cat $predict_mut_human_m|cut -f2>>$data2m_tmp

	cat $data1m_tmp|awk '!x[$0]++'>$data1_tmp
	cat $data2m_tmp|awk '!x[$0]++'>$data2_tmp
	awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt

	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_ref_human_t
	cat $predict_ref_human_m>>$predict_ref_human_t
	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_mut_human_t
	cat $predict_mut_human_m>>$predict_mut_human_t

elif [ $algo == "TSintersectionMR" ] 
then

	./targetscan_60.pl $ref_t UTR_Sequences_humanonly $predict_ref_human_t
	./targetscan_60.pl $mut_t UTR_Sequences_humanonly $predict_mut_human_t

	cat $predict_ref_human_t|cut -f1>$data1t_tmp
	cat $predict_mut_human_t|cut -f1>$data2t_tmp

	../miRanda-3.3a/bin/miranda  $ref 3utr.fasta -out $newresultref_miranda
	../miRanda-3.3a/bin/miranda  $mut 3utr.fasta -out $newresultmut_miranda

	grep ">>" $newresultref_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_ref_human_m   
	grep ">>" $newresultmut_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_mut_human_m   

	cat $predict_ref_human_m|cut -f2>$data1m_tmp
	cat $predict_mut_human_m|cut -f2>$data2m_tmp


	awk 'NR==FNR{a[$0];next} $0 in a' $data1t_tmp $data1m_tmp|awk '!x[$0]++'>$data1_tmp
	awk 'NR==FNR{a[$0];next} $0 in a' $data2t_tmp $data2m_tmp|awk '!x[$0]++'>$data2_tmp
	awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt

	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_ref_human_t
	cat $predict_ref_human_m>>$predict_ref_human_t
	echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_mut_human_t
	cat $predict_mut_human_m>>$predict_mut_human_t


fi

>$gossfiletemp 
>$f_figinput
>$f_figinputMF
>$f_figinputCC

echo -e "NA\tNA\tNA">$gossfiletemp

#R CMD BATCH �-vanilla --slave "--args $thrval $filter $data1_tmp $data2_tmp $data3txt $f_ref $f_mut $f_common $gossfiletemp $f_figinput $f_figinputMF $f_figinputCC" goscore.r  

Rscript goscore.r $thrval $filter $data1_tmp $data2_tmp $data3txt $f_ref $f_mut $f_common $gossfiletemp $f_figinput $f_figinputMF $f_figinputCC 


#grep "BP" $f_ref|cut -f9|grep -v "TF">$f_figinput
#grep "BP" $f_mut|cut -f9|grep -v "TF">>$f_figinput
#grep "BP" $f_common|cut -f9|grep -v "TF">>$f_figinput

#grep "MF" $f_ref|cut -f9|grep -v "TF">$f_figinputMF
#grep "MF" $f_mut|cut -f9|grep -v "TF">>$f_figinputMF
#grep "MF" $f_common|cut -f9|grep -v "TF">>$f_figinputMF

#grep "CC" $f_ref|cut -f9|grep -v "TF">$f_figinputCC
#grep "CC" $f_mut|cut -f9|grep -v "TF">>$f_figinputCC
#grep "CC" $f_common|cut -f9|grep -v "TF">>$f_figinputCC



#grep "BP" $f_ref|cut -f9|grep -v "TF">bp_ref
#grep "MF" $f_ref|cut -f9|grep -v "TF">mf_ref
#grep "CC" $f_ref|cut -f9|grep -v "TF">cc_ref


#grep "BP" $f_mut|cut -f9|grep -v "TF">bp_mut
#grep "CC" $f_mut|cut -f9|grep -v "TF">cc_mut
#grep "MF" $f_mut|cut -f9|grep -v "TF">mf_mut

#Rscript goscore_p2.r bp_ref bp_mut mf_ref mf_mut cc_ref cc_mut $gossfiletemp"new" 

      
echo -e  "$mirid\t$point\t$allele\t$predict_ref_human_t\t$predict_mut_human_t\t$f_ref\t$f_mut\t$f_common">>$f_output

mkdir "./Results.all."$kv   
#cp $predict_ref_human_t ./temp/$kvData/$mirid_$point_$allele_Reference_targets.txt
#cp $predict_mut_human_t ./temp/$kv"Data"/$mirid_$point_$allele_Derived_targets.txt
#cp $f_ref ./temp/$kv"_Data"/$mirid_$point_$allele_enrichments.txt
#cp $f_mut ./temp/$kv"_Data"/$mirid_$point_$allele_Derived_target_functional_enrichments.txt
#cp $f_common ./temp/$kv"_Data"/$mirid_$point_$allele_Common_target_functional_enrichments.txt

cp $predict_ref_human_t "./Results.all."$kv"/"$allele"_at_position_"$point"_"$mirid"Reference_targets.txt"
cp $predict_mut_human_t "./Results.all."$kv"/"$allele"_at_position_"$point"_"$mirid"Derived_targets.txt"
cp $f_ref "./Results.all."$kv"/"$allele"_at_position_"$point"_"$mirid"Referance_target_functional_enrichments.txt"
cp $f_mut "./Results.all."$kv"/"$allele"_at_position_"$point"_"$mirid"Derived_target_functional_enrichments.txt"
cp $f_common "./Results.all."$kv"/"$allele"_at_position_"$point"_"$mirid"Common_target_functional_enrichments.txt"


gossval=`cat $gossfiletemp`
echo -e "$mirid\t$point\t$allele\t$gossval">>$gossfile   
 

