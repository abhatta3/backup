<?php
$myFile=$_GET["My_key"];

$myFileload="./temp/".$myFile.".png";
shell_exec('sh goscoreTS.sh '.$myFile);

print("<br />");
print("<br />");

$input=shell_exec('cat ./temp/'.$myFile);
$output=shell_exec('cat ./temp/'.$myFile.'*output.tmp');
$display=$input."\t".$output;

print("id sequence mut_loc mut_allele GOSS_BP GOSS_MF GOSS_CC");
print("<br />");
print($display); 

shell_exec('sh creategraphFulltable.sh '.$myFile);

?>

<img src="<?php print($myFileload)?>" width="960" alt="GOdag">