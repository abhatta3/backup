<?php
include("header_new.inc");

//LLJ;hsa-miR-146a-3p;4;G
$myFiledata=$_GET["My_key"];

//echo $myFiledata;

$str_arrmat=array();
$str_arrmat=explode(";",$myFiledata);
$myFile=$str_arrmat[0];
$id=$str_arrmat[1];
$loc=$str_arrmat[2];
$mut=$str_arrmat[3];

shell_exec('sh creategraphMF.sh '.$myFile.' '.$id.' '.$loc.' '.$mut);


//sh creategraphFulltable.sh LLJ hsa-miR-146a-3p 4 G


$picpath='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'newMF.png';
$tablepath='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'newtableMF.tmp';


$matrix1=file_get_contents("$tablepath");
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRSNP2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/downloads/">Download</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>



<div id="outernew">
<img src="<?php print($picpath);?>" width="600"></img>
</br>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 13px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">Node number</td>
<td style="background-color: #9932CC; color: #FFFFFF">GO ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Term</td>
<td style="background-color: #9932CC; color: #FFFFFF">Disrupted</br>p-value, Number of gene</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common</br>p-value, Number of gene</td>
<td style="background-color: #9932CC; color: #FFFFFF">Created</br>p-value, Number of gene</td>
</tr>
<?php
  foreach($str_arrmat as $datamat)
  {
      if(strlen($datamat)>1)
      {

            $data_cell=explode('#',$datamat);
           ?>
           <tr>
           <?php  
            foreach($data_cell as $cell)
            {  
                  ?>
                  <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
                  <?php
                   
            }
            ?>
            </tr>
           <?php
      }
  }  
?>
</table>
