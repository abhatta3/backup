#!/bin/bash
#input files

>goscore_Report_filemiranda.txt
>output.txt
>seed2_enrichment
>data_statmiranda  

mirna_file=$1

disrupted_file="disrupted_human.txt"
created_file="created_human.txt"
export LC_ALL="C"


while read line           
do  

>mut
>ref
>mut_t
>ref_t
         
	set -- $line
       mirid=$1
       seed=$2
       point=$3
       allele=$4
       if [ $allele == "T" ]
       then
          allele="U"
       fi

       mirname=$mirid"_"$point"_"$allele

       f_ref="./disruptedmiranda/"$mirname
       f_mut="./createdmiranda/"$mirname
       f_common="./commonmiranda/"$mirname


       if [ $point -eq 2 ]
       then

       	fr=`echo $seed|cut -c1`
       	fo=`echo $seed|cut -c3-22`
              
              fr_t=""
              fo_t=`echo $seed|cut -c3-8`

       	echo -e ">$mirname\n$fr$allele$fo">>mut 
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       elif [ $point -eq 3 ]
       then

       	fr=`echo $seed|cut -c1-2`
       	fo=`echo $seed|cut -c4-22`

              fr_t=`echo $seed|cut -c2`
              fo_t=`echo $seed|cut -c4-8`

       	echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       elif [ $point -eq 4 ]
       then

       	fr=`echo $seed|cut -c1-3`
       	fo=`echo $seed|cut -c5-22`
              fr_t=`echo $seed|cut -c2-3`
              fo_t=`echo $seed|cut -c5-8`

       	echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t


       elif [ $point -eq 5 ]
       then

       	fr=`echo $seed|cut -c1-4`
       	fo=`echo $seed|cut -c6-22`

              fr_t=`echo $seed|cut -c2-4`
              fo_t=`echo $seed|cut -c6-8`

       	echo -e ">$mirname\n$fr$allele$fo">>mut       
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       elif [ $point -eq 6 ]
       then

       	fr=`echo $seed|cut -c1-5`
       	fo=`echo $seed|cut -c7-22`

              fr_t=`echo $seed|cut -c2-5`
              fo_t=`echo $seed|cut -c7-8`


       	echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       elif [ $point -eq 7 ]
       then
	       fr=`echo $seed|cut -c1-6`
       	fo=`echo $seed|cut -c8-22`

              fr_t=`echo $seed|cut -c2-6`
              fo_t=`echo $seed|cut -c8`


       	echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       elif [ $point -eq 8 ]
       then
	       fr=`echo $seed|cut -c1-7`
       	fo=`echo $seed|cut -c9-22`

              fr_t=`echo $seed|cut -c2-7`
              fo_t=""


       	echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">>mut_t

       fi
       
       echo -e ">$mirname\n$seed">>ref 
       seedonly=`echo $seed|cut -c2-8`
       echo -e "$mirname\t$seedonly\t9606">>ref_t

   

#run miranda

      ./miRanda-3.3a/src/miranda  ref 3UTR_human.fasta -out newresultref_miranda.txt
      ./miRanda-3.3a/src/miranda  mut 3UTR_human.fasta -out newresultmut_miranda.txt


#miranda

      grep ">>$mirname" newresultref_miranda.txt >predict_ref_human_miranda   
      grep ">>$mirname" newresultmut_miranda.txt >predict_mut_human_miranda


      cat predict_ref_human_miranda|cut -f2|awk '!x[$0]++' >data1_tmp
      cat predict_mut_human_miranda|cut -f2|awk '!x[$0]++' >data2_tmp


      tnts_ref=`cat data1_tmp|wc -l`
      tnts_mut=`cat data2_tmp|wc -l`
      awk 'NR==FNR{a[$0];next} $0 in a' data1_tmp data2_tmp>data3.txt
      tnts_common=`cat data3.txt|wc -l`

      awk 'FNR==NR{a[$1]++;next}!a[$1]' data2_tmp data1_tmp >data1.txt
      awk 'FNR==NR{a[$1]++;next}!a[$1]' data1_tmp data2_tmp >data2.txt
       
      >output.txt

      R CMD BATCH goscore.r 
      targetscanlineout=`cat output.txt`
    
       cat ref_enrich.txt>$f_ref 
       cat mut_enrich.txt>$f_mut
       cat common_enrich.txt>$f_common

      echo   -e "$line\t$tnts_ref\t$tnts_mut\t$tnts_common">>data_statmiranda  
      echo   -e "$line\t$targetscanlineout">>goscore_Report_filemiranda.txt


done <$mirna_file                

