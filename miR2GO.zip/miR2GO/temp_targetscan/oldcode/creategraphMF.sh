#!/bin/bash
#input files

kv=$1
mirid=$2
point=$3
allele=$4
mirnafile="./temp/"$kv



export LC_ALL="C"


       if [ $allele == "T" ]
       then
          allele="U"
       fi
       
       mirname=$mirid"_"$point"_"$allele

       f_ref="./disrupted/"$kv$mirname
       f_mut="./created/"$kv$mirname
       f_common="./common/"$kv$mirname

	f_figinput=$mirnafile$mirname"figMF"
       
       cat $f_figinput|awk '!x[$0]++'>$mirnafile"figfileinput.tmp"
       
       Rscript gofig.r $mirnafile"figfileinput.tmp" $mirnafile"godag.dot"

       #cat $mirnafile"godag.dot">$mirname

       grep -v "label" $mirnafile"godag.dot"|sed 's/none/normal/g'>$mirnafile"p1.tmp"

       grep "GO:" $mirnafile"godag.dot"|sed 's/<TD>/\t/g'|sed 's/<\/TD>/\t/g'|sed 's/<br\/>/\t/g'|cut -f3>$mirnafile"p2.tmp"
 
       >$mirnafile$mirname"newtableMF.tmp"
       >$mirnafile"temp.tmp" 

       lnumber=1 
       tnumber=1 
       >$mirnafile"p2new.tmp"
  
	while read -r lineid           
	do  
          
         refn=`grep -w "$lineid" $f_ref|cut -f6`
         commonn=`grep -w "$lineid" $f_common|cut -f6`
         mutn=`grep -w "$lineid" $f_mut|cut -f6`
                
         n1=`echo $refn|wc -w`
         n2=`echo $mutn|wc -w`
         n3=`echo $commonn|wc -w`
           
         if [ $n1 -eq 0 ]
         then   
            refn=0
         fi

         if [ $n2 -eq 0 ]
         then   
            mutn=0
         fi
         if [ $n3 -eq 0 ]
         then   
            commonn=0
         fi
         total=$[refn+mutn+commonn]
   
         echo -e "$lineid\t$lnumber\t$total\t$refn\t$mutn\t$commonn">>$mirnafile"p2new.tmp"        
         lnumber=$[lnumber+1]
       done < $mirnafile"p2.tmp"

       sort -n -r -k3 $mirnafile"p2new.tmp">$mirnafile"p2.tmp"        


	while read -r lineread           
	do  
          
         set -- $lineread
         lineid=$1
         lnumber=$2
         total=$3
         refn=$4
         mutn=$5
         commonn=$6

        #templine11=`grep "$lineid" $f_ref|cut -f3`
        #templine21=`grep "$lineid" $f_common|cut -f3`
        #templine31=`grep "$lineid" $f_mut|cut -f3`

        #refn=`grep "$lineid" $f_ref|cut -f6`
        #commonn=`grep "$lineid" $f_common|cut -f6`
        #mutn=`grep "$lineid" $f_mut|cut -f6`
           
       #  refn=`echo $templine11| sed -e 's/[eE]+*/\\*10\\^/'| bc -l`
       #  commonn=`echo $templine21| sed -e 's/[eE]+*/\\*10\\^/'| bc -l`
       #  mutn=`echo $templine31| sed -e 's/[eE]+*/\\*10\\^/'| bc -l`

              
        # n1=`echo $refn|wc -w`
        # n2=`echo $mutn|wc -w`
        # n3=`echo $commonn|wc -w`
         #if [ $n1 -eq 0 ]
         #then   
         #   refn=0
         #fi

        # if [ $n2 -eq 0 ]
        # then   
         #   mutn=0
         #fi
         #if [ $n3 -eq 0 ]
         #then   
         #   commonn=0
         #fi

         #if [ $n1 -eq 0 ]
         #then
         #  refn=0
         #else
         #     refn=`echo "-l($refn)/l(10)"| bc -l`
         #     refn=`echo $refn | awk '{printf("%d\n",$1 + 0.5)}'`
         #fi   

         #if [ $n2  -eq 0 ]
         #then
         #  mutn=0
         #else
         #  mutn=`echo "-l($mutn)/l(10)"| bc -l`
         #  mutn=`echo $mutn | awk '{printf("%d\n",$1 + 0.5)}'`

         #fi   

         #if [ $n3  -eq 0 ]
         #then
         #  commonn=0
         #else
         #  commonn=`echo "-l($commonn)/l(10)"| bc -l`
         #  commonn=`echo $commonn | awk '{printf("%d\n",$1 + 0.5)}'`

         #fi   

         v1=255
         v2=255
         v3=255
   
         #total=$[refn+mutn+commonn]


         times=$[total/100]
     
         if [ $total -gt 0 ]
         then
         	f1=`echo $refn/$total|bc -l`
         	f2=`echo $mutn/$total|bc -l`
         	f3=`echo $commonn/$total|bc -l`
              #ref
         	v1=`echo "$v1*$f2"|bc`
              #common
         	v2=`echo "$v2*$f3"|bc`
              #mut
         	v3=`echo "$v3*$f1"|bc`
        	p1=`echo $v1 | awk '{printf("%d\n",$1 + 0.5)}'`  
         	p2=`echo $v2 | awk '{printf("%d\n",$1 + 0.5)}'` 
         	p3=`echo $v3 | awk '{printf("%d\n",$1 + 0.5)}'`
           	if [ $p1 -eq 0 ]
         	then
          	   p1="00"
         	else
       	    p1=`printf %x $p1`      
	  	fi 

         	if [ $p2 -eq 0 ]
         	then
          		p2="00"
         	else
       		p2=`printf %x $p2`      
	  	fi 

         	if [ $p3 -eq 0 ]
         	then
          		p3="00"
         	else
       	  	p3=`printf %x $p3`      
	  	fi 
         	hcode="#"$p1$p2$p3

           else
              hcode="#FFFFFF"
         fi
         
 
         wv=$[total+1]
      
         #echo -e "node$lnumber [label=\"\", fillcolor=\"$hcode\", style=filled, width=$wv, height=$wv];">>$mirname"temp"  

         name=`grep -w $lineid $mirnafile"godag.dot"|sed 's/<TD>/\t/g'|sed 's/<\/TD>/\t/g'|sed 's/<br\/>/\t/g'|cut -f4`

          if [ $total -gt 0 ]
          then  

            wv=`echo 1.0+$times*0.1|bc -l`
            hv=`echo 0.75+$times*0.1|bc -l`

 
            templine1=`grep "$lineid" $f_ref|cut -f3,6 --output-delimiter=";"`
            templine2=`grep "$lineid" $f_common|cut -f3,6 --output-delimiter=";"`       
            templine3=`grep "$lineid" $f_mut|cut -f3,6 --output-delimiter=";"`  

            echo -e "node$lnumber [label=$tnumber, fillcolor=\"$hcode\", style=filled, width=$wv, height=$hv];">>$mirnafile"temp.tmp"   
              
            echo -e "$tnumber#$lineid#$name#$templine1#$templine2#$templine3">>$mirnafile$mirname"newtableMF.tmp" 

            tnumber=$[tnumber+1] 
              
          else
            echo -e "node$lnumber [label=\"\", fillcolor=\"$hcode\", style=filled, width=0.75, height=0.5];">>$mirnafile"temp.tmp"  

          fi
         


       done < $mirnafile"p2.tmp"

	#FF0000	rgb(255,0,0) red created
	#00FF00	rgb(0,255,0) green common
	#0000FF	rgb(0,0,255) blue disrupted
       #00ffff       rgb(0,255,255) light blue disrupted+common 
       #ffff00       rgb(255,255,0) yellow common+created
       #ffffff       rgb(255,255,255) white no gene  

       echo -e   "digraph dagfig {\n node [fontname="luximb",fontsize=20];\n nodesep=0.1;\n">$mirnafile"godagdisplay.dot"


       cat $mirnafile"temp.tmp">>$mirnafile"godagdisplay.dot"
       lno=`cat $mirnafile"p1.tmp"|wc -l` 
       lno=$[lno-3]
       tail -n $lno $mirnafile"p1.tmp">>$mirnafile"godagdisplay.dot"   
       #dot -Tsvg $mirnafile"godagdisplay.dot" -o $mirnafile$mirname".svg"
 
       dot -Tpng $mirnafile"godagdisplay.dot" -o $mirnafile$mirname"newMF.png" 


