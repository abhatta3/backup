<?php
//LLJ;hsa-miR-146a-3p;4;G
$myFiledata=$_GET["My_key"];

//echo $myFiledata;

$str_arrmat=array();
$str_arrmat=explode(";",$myFiledata);
$myFile=$str_arrmat[0];
$id=$str_arrmat[1];

shell_exec('sh pair_creategraphFulltable.sh '.$myFile.' '.$id);


//sh creategraphFulltable.sh LLJ hsa-miR-146a-3p 4 G


$picpath='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'.png';


//<iframe frameborder="1" scrolling="yes" width="1550" height="900"
//   src="" name="imgbox" id="imgbox">
// </iframe>


?>
<img src="<?php print($picpath);?>" alt="description of the photo"></img>
