<?php

 mkdir("created",0775); 
 mkdir("common",0775);  
 mkdir(".disrupted",0775);
  mkdir("temp",0775);  
?>
