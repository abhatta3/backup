#!/bin/bash

kv=$1
mirna_file="./temp/"$kv
export LC_ALL="C"

#input files
tp="./temp/"$kv
mut_t=$tp"mut_t.tmp"
ref_t=$tp"ref_t.tmp"
predict_ref_human_t=$tp"predict_ref_human_t.tmp"
predict_mut_human_t=$tp"predict_mut_human_t.tmp"
data1_tmp=$tp"data1.tmp"
data2_tmp=$tp"data2.tmp"
data1txt=$tp"data1txt.tmp"
data2txt=$tp"data2txt.tmp"
data3txt=$tp"data3txt.tmp"



while read line           
do  
	set -- $line
       mirid=$1
       seed=$2
       point=$3
       allele=$4
       if [ $allele == "T" ]
       then
          allele="U"
       fi

       mirname=$mirid"_"$point"_"$allele

       f_ref="./disrupted/"$kv$mirname
       f_mut="./created/"$kv$mirname
       f_common="./common/"$kv$mirname
       f_output=$tp$mirname"output.tmp" 

       if [ $point -eq 2 ]
       then

       	fr=`echo $seed|cut -c1`
       	fo=`echo $seed|cut -c3-22`
              
              fr_t=""
              fo_t=`echo $seed|cut -c3-8`

       	#echo -e ">$mirname\n$fr$allele$fo">>mut 
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       elif [ $point -eq 3 ]
       then

       	fr=`echo $seed|cut -c1-2`
       	fo=`echo $seed|cut -c4-22`

              fr_t=`echo $seed|cut -c2`
              fo_t=`echo $seed|cut -c4-8`

       	#echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       elif [ $point -eq 4 ]
       then

       	fr=`echo $seed|cut -c1-3`
       	fo=`echo $seed|cut -c5-22`
              fr_t=`echo $seed|cut -c2-3`
              fo_t=`echo $seed|cut -c5-8`

       	#echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t


       elif [ $point -eq 5 ]
       then

       	fr=`echo $seed|cut -c1-4`
       	fo=`echo $seed|cut -c6-22`

              fr_t=`echo $seed|cut -c2-4`
              fo_t=`echo $seed|cut -c6-8`

       	#echo -e ">$mirname\n$fr$allele$fo">>mut       
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       elif [ $point -eq 6 ]
       then

       	fr=`echo $seed|cut -c1-5`
       	fo=`echo $seed|cut -c7-22`

              fr_t=`echo $seed|cut -c2-5`
              fo_t=`echo $seed|cut -c7-8`


       	#echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       elif [ $point -eq 7 ]
       then
	       fr=`echo $seed|cut -c1-6`
       	fo=`echo $seed|cut -c8-22`

              fr_t=`echo $seed|cut -c2-6`
              fo_t=`echo $seed|cut -c8`


       	#echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       elif [ $point -eq 8 ]
       then
	       fr=`echo $seed|cut -c1-7`
       	fo=`echo $seed|cut -c9-22`

              fr_t=`echo $seed|cut -c2-7`
              fo_t=""


       	#echo -e ">$mirname\n$fr$allele$fo">>mut
              echo -e "$mirname\t$fr_t$allele$fo_t\t9606">$mut_t

       fi
       
       #echo -e ">$mirname\n$seed">>ref 
       seedonly=`echo $seed|cut -c2-8`
       echo -e "$mirname\t$seedonly\t9606">$ref_t

   

#run target scan

     ./targetscan_60.pl $ref_t UTR_Sequences_humanonly $predict_ref_human_t
     ./targetscan_60.pl $mut_t UTR_Sequences_humanonly $predict_mut_human_t
  
#target scan

      cat $predict_ref_human_t|cut -f1|awk '!x[$0]++' >$data1_tmp
      cat $predict_mut_human_t|cut -f1|awk '!x[$0]++' >$data2_tmp

      awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt
      awk 'FNR==NR{a[$1]++;next}!a[$1]' $data2_tmp $data1_tmp >$data1txt
      awk 'FNR==NR{a[$1]++;next}!a[$1]' $data1_tmp $data2_tmp >$data2txt

      thrval="0.00001"    
      Rscript goscore.r $thrval $data1txt $data2txt $data3txt $f_ref $f_mut $f_common $f_output

done <$mirna_file                

