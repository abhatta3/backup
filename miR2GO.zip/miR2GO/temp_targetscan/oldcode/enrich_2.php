<?php
include("header_new.inc");

$myFile=$_GET["My_key"];

$matrixfile=file_get_contents("./temp/$myFile");

$statusfile="./temp/$myFile"."status";


$thresholdfile="./temp/$myFile"."threshold";
$filterfile="./temp/$myFile"."filter";

$thrval=file_get_contents("$thresholdfile");
print($thrval);
$filter=file_get_contents("$filterfile");
 
$str_arrmat0=array();
$str_arrmat0=explode("\n",$matrixfile);
$data_cell0=array(); 
$fileval=array();

if(!file_exists($statusfile))
{

foreach($str_arrmat0 as $datamat0)
{
  if(strlen($datamat0)>5)
  {
   $data_cell0=explode(' ',$datamat0);
   $i=0;
   foreach($data_cell0 as $cell)
   {  
    if(strlen($cell)>0)
    {   
      $fileval[$i]=trim($cell);
      $i++;
    } 
   }
   if(strlen($fileval[0])<3 || strlen($fileval[1])<6 || strlen($fileval[2])!=1 || strlen($fileval[3])!=1)
   {
     print("Input data formatting error");
   }
   else
   {
       $mirid=$fileval[0];
       $seed1=$fileval[1];
       $point=$fileval[2];
       $allele=$fileval[3];
       $seed2=$seed1;
       if($allele=='T')
             $allele='U';
       $seed2[$point-1]=$allele;
  
       $thrval="0.01";

       $mirname=$mirid."_".$point."_".$allele;

       $seed1=substr($seed1, 1, 7);
       $seed2=substr($seed2, 1, 7);

       $dataref=$mirid."\t".$seed1."\t9606";
       $datamut=$mirid."\t".$seed2."\t9606";

       $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref_t.tmp";
       $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut_t.tmp";

       $fhref = fopen($dirref, 'w') or die("can't open file");
       fwrite($fhref, "$dataref");
       fclose($fhref);

       $fhmut = fopen($dirmut, 'w') or die("can't open file");
       fwrite($fhmut, "$datamut");
       fclose($fhmut);

       shell_exec('sh runprediction.sh '.$myFile.' '.$mirid.' '.$point.' '.$allele.' '.$thrval.' '.$filter);

   } 

  }
  
 }

}//end of status

//shell_exec('sh goscoreTSnew.sh '.$myFile);

$myFileload="./temp/".$myFile.".png";
//shell_exec('sh goscoreTSnew.sh '.$myFile);

$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';

//shell_exec('sh creategraphFulltable.sh '.$myFile);


//$matrix3=file_get_contents("$outputfilefig");

$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);


//$str_arrmat2=array();
//$data_cell2=array(); 
//$str_arrmat2=explode("\n",$matrix3);

?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="../mirsnp.php?My_key=<?php print($keyval);?>">miRNA SNPs analyzer</a>
  <li><a href="../mirna.php?My_key=<?php print($keyval);?>">miRNA function analyzer</a>  
  <li><a href="../genegroup.php?My_key=<?php print($keyval);?>">Gene group functional analyzer</a>
  <li><a href="../genegroup_pair.php?My_key=<?php print($keyval);?>">Gene group pair functional analyzer</a>
  <li><a href="../help.php">Help</a>
  <li><a href="../faq.php">FAQ</a>
  <li><a href="../downloads/BNW_src_files.tar">Download</a>
  <li><a href="../home.php">Home</a>
</ul>

<div id="outernew">
</ br>
</ br>
<h2>Result</h2>

<table style="background-color: #9932CC; font-weight: bold; font-size: 13px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>location</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>allele</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derive</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>disrupted reference</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>new derive</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>common</td>
</tr>

<?php
foreach($str_arrmat as $datamat)
{
  if(strlen($datamat)>5)
  {

  $data_cell=explode("\t",$datamat);

?>
  <tr>
  <?php
  $i=1;
  foreach($data_cell as $cell)
  {
       $cell=trim($cell);
       if($i<4)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
       <?php
       }
       else if($i>=4 && $i<6)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($cell);?>>download</a> </td>
       <?php
       }
       else
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaydisrupted.php?My_key=<?php print($cell);?>" target='_blank'>Display</a>/<a href=<?php print($cell);?>>download</a> </td>
       <?php
       } 
    $i++; 
  }
   ?>
  </tr>
 <?php
 }
}
?>
</table>
</br>
</br>

<table style="background-color: #9932CC; font-weight: bold; font-size: 13px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>location</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>allele</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mulicular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Celular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">View GO DAG</td>
</tr>

<?php
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>5)
  {

   $data_cell1=explode("\t",$datamat1);
 
  $datatosend1=str_replace("\t", ";", $datamat1);
  $datatosend=$myFile.";".$datatosend1;
?>
  <tr>
  <?php
  foreach($data_cell1 as $cell)
  {
        $cell=trim($cell);
  ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
 
  <?php
  }
  ?>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a href="godagBP.php?My_key=<?php print($datatosend);?>" target='_blank'>Biological Process</a></br>
  <a href="godagMF.php?My_key=<?php print($datatosend);?>" target='_blank'>Molecular Function</a></br>
  <a href="godagCC.php?My_key=<?php print($datatosend);?>" target='_blank'>Celular Component</a></br>
  </td> 
  </tr>
 <?php
 }
}
?>
</table>

</div>
<?php
$stausprint=1;
$fhrefstatus = fopen($statusfile, 'w') or die("can't open file");
fwrite($fhrefstatus, $stausprint);
fclose($fhrefstatus)
?>