#!/bin/bash

kv=$1
mirid=$2

thrval=$3
filter=$4

mirname=$mirid

export LC_ALL="C"

#input files

tp="./temp/"$kv

mut=$tp$mirname"mut.tmp"
ref=$tp$mirname"ref.tmp"

mut_t=$tp$mirname"mut_t.tmp"
ref_t=$tp$mirname"ref_t.tmp"


data1_tmp=$tp"data1.tmp"
data2_tmp=$tp"data2.tmp"

data1m_tmp=$tp"data1m.tmp"
data2m_tmp=$tp"data2m.tmp"



data1txt=$tp"data1txt.tmp"
data2txt=$tp"data2txt.tmp"
data3txt=$tp"data3txt.tmp"

f_output=$tp"output.tmp" 
gossfile=$f_output".goss"

gossfiletemp=$f_output".goss.tmp"

f_ref="./disrupted/"$kv$mirname
f_mut="./created/"$kv$mirname
f_common="./common/"$kv$mirname
f_figinput=$tp$mirname"fig"
f_figinputMF=$tp$mirname"figMF"
f_figinputCC=$tp$mirname"figCC"


 
predict_ref_human_t=$tp$mirname"predict_ref_human_t.tmp"
predict_mut_human_t=$tp$mirname"predict_mut_human_t.tmp"


predict_ref_human_m=$tp$mirname"predict_ref_human_m.tmp"
predict_mut_human_m=$tp$mirname"predict_mut_human_m.tmp"



newresultref_miranda=$tp$mirname"predict_ref_human_tmp.tmp"
newresultmut_miranda=$tp$mirname"predict_mut_human_tmp.tmp"

#run target scan

./targetscan_60.pl $ref_t UTR_Sequences_humanonly $predict_ref_human_t
./targetscan_60.pl $mut_t UTR_Sequences_humanonly $predict_mut_human_t

cat $predict_ref_human_t|cut -f1>$data1m_tmp
cat $predict_mut_human_t|cut -f1>$data2m_tmp

  
#run miranda

../miRanda-3.3a/bin/miranda  $ref 3utr.fasta -out $newresultref_miranda
../miRanda-3.3a/bin/miranda  $mut 3utr.fasta -out $newresultmut_miranda

#miranda 3UTR_human.fasta

grep ">>$mirid" $newresultref_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_ref_human_m   
grep ">>$mirid" $newresultmut_miranda|sed 's/hg19_refGene_//g'|sed 's/>>//g'>$predict_mut_human_m   


cat $predict_ref_human_m|cut -f2>>$data1m_tmp
cat $predict_mut_human_m|cut -f2>>$data2m_tmp

cat $data1m_tmp|awk '!x[$0]++'>$data1_tmp
cat $data2m_tmp|awk '!x[$0]++'>$data2_tmp


awk 'NR==FNR{a[$0];next} $0 in a' $data1_tmp $data2_tmp>$data3txt
#awk 'FNR==NR{a[$1]++;next}!a[$1]' $data2_tmp $data1_tmp >$data1txt
#awk 'FNR==NR{a[$1]++;next}!a[$1]' $data1_tmp $data2_tmp >$data2txt
   

echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_ref_human_t
cat $predict_ref_human_m>>$predict_ref_human_t
echo -e "\nmiRanda Result\nSeq1\tSeq2\tTot Score\tTot Energy\tMax Score\tMax Energy\tStrand\tLen1\tLen2\tPositions">>$predict_mut_human_t
cat $predict_mut_human_m>>$predict_mut_human_t

>$gossfiletemp 
>$f_figinput
>$f_figinputMF
>$f_figinputCC

echo -e "NA\tNA\tNA">$gossfiletemp

Rscript goscore.r $thrval $filter $data1_tmp $data2_tmp $data3txt $f_ref $f_mut $f_common $gossfiletemp $f_figinput $f_figinputMF $f_figinputCC
      
echo -e  "$mirid\t$predict_ref_human_t\t$predict_mut_human_t\t$f_ref\t$f_mut\t$f_common">>$f_output
gossval=`cat $gossfiletemp`
echo -e "$mirid\t$gossval">>$gossfile   


            

