#!/bin/bash

x=""
n=`echo $x|wc -w`
if [ $n -eq 0 ]
then
  echo "Hello"
else
  echo "GO"
fi

