<?php
$myFile=$_GET["My_key"];

$myFileload="./temp/".$myFile.".png";
shell_exec('sh goscoreTSnew.sh '.$myFile);

$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';

//shell_exec('sh creategraphFulltable.sh '.$myFile);


//$matrix3=file_get_contents("$outputfilefig");

$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);


//$str_arrmat2=array();
//$data_cell2=array(); 
//$str_arrmat2=explode("\n",$matrix3);


?>
</ br>
</ br>
<h2>Result</h2>

<table style="background-color: #9932CC; font-weight: bold; font-size: 13px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>location</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>allele</td>
<td style="background-color: #9932CC; color: #FFFFFF">Targets</br>reference</td>
<td style="background-color: #9932CC; color: #FFFFFF">Targets</br>mutant</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>disrupted</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>new</td>
<td style="background-color: #9932CC; color: #FFFFFF">Enrichment</br>common</td>
</tr>

<?php
foreach($str_arrmat as $datamat)
{
  $data_cell=explode("\t",$datamat);
?>
  <tr>
  <?php
  $i=1;
  foreach($data_cell as $cell)
  {
       $cell=trim($cell);
       if($i<5 && $i!=2)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
       <?php
       }
       else if($i>=5)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> Table view/<a href=<?php print($cell);?>>download</a> </td>
       <?php
       }
    $i++; 
  }
   ?>
  </tr>
 <?php
}
?>
</table>
</br>
</br>

<table style="background-color: #9932CC; font-weight: bold; font-size: 13px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mature</br>sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>location</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mutation</br>allele</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological</br>process score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Mulicular</br>function score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Celular</br>component score</td>
<td style="background-color: #9932CC; color: #FFFFFF">View DAG</br>Biological process</td>
</tr>

<?php
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>10)
  {

  $data_cell1=explode("\t",$datamat1);
 
  $datatosend1=str_replace("\t", ";", $datamat1);
  $datatosend=$myFile.";".$datatosend1;
?>
  <tr>
  <?php
  $flag=1;  
  foreach($data_cell1 as $cell)
  {
        $cell=trim($cell);
        if($cell=="")
        { 
              $cell="NA";
               $flag=0;
        }
  
  ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
 
  <?php
  }
  if($flag==1)
  {
  ?>
  <td style="background-color: #EFCFFE; color: #6B248E"><a href="godagBP.php?My_key=<?php print($datatosend);?>" target='_blank'>Display</a></td> 
<?php
  }
  else
  {
?>
    <td style="background-color: #EFCFFE; color: #6B248E"> NA </td>

<?php
  }
?>

  </tr>
 <?php
 }
}
?>
</table>

