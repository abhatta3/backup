#!/bin/bash
#input files

kv=$1
mirid=$2

snpfile="snp138";
outputfile=$kv

export LC_ALL="C"

grep $mirid $snpfile|cut -f1-4>>$outputfile
