<?php
$myFile=$_GET["My_key"];

$statusfile="./temp/$myFile"."status";

$status=trim(file_get_contents("$statusfile"));
print($myFile);
print($status);

?> 