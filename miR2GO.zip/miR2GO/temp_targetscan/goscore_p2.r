#perform functional enrichment for input gene list #
#use gprofiler for functional enrichment and then gosimsem for compariso between two groups of functionally enriched terms for two input gene lists #

args <- commandArgs(trailingOnly = TRUE)
pval_thr=as.numeric(args[1])

bp_ref=args[1]
bp_mut=args[2] 

mf_ref=args[3]
mf_mut=args[4] 

cc_ref=args[5]
cc_mut=args[6] 

f_output=args[7]


library(GOSemSim)    


gs1_BP <- scan(bp_ref, what="", sep="\n")
gs2_BP <- scan(bp_mut, what="", sep="\n")

gs1_MF <- scan(mf_ref, what="", sep="\n")
gs2_MF <- scan(mf_mut, what="", sep="\n")

gs1_CC <- scan(cc_ref, what="", sep="\n")
gs2_CC <- scan(cc_mut, what="", sep="\n")



mywangscore <- function (GO1, GO2, ont = "MF", organism = "human", measure = "Wang")
{
    wh_ont <- match.arg(ont, c("MF", "BP", "CC"))
    wh_organism <- match.arg(organism, c("human", "fly", "mouse",
        "rat", "yeast", "zebrafish", "worm", "arabidopsis", "ecolik12",
        "bovine", "canine", "anopheles", "ecsakai", "chicken",
        "chimp", "malaria", "rhesus", "pig", "xenopus"))
    wh_measure <- match.arg(measure, c("Resnik", "Jiang", "Lin",
        "Rel", "Wang"))
    GO1 <- unlist(GO1)
    GO2 <- unlist(GO2)
    m <- length(GO1)
    n <- length(GO2)

    if (n == 0 && m == 0) {
        return(NA)
    }
    else if (n == 0 && m != 0) {
        return(0)
    }
    else if (n != 0 && m == 0) {
        return(0)
    }

    scores <- matrix(nrow = m, ncol = n)
   
    rownames(scores) <- GO1
    colnames(scores) <- GO2

    for (i in 1:m) {
        for (j in 1:n) {
           scores[i, j]<-goSim(GO1[i], GO2[j], wh_ont, wh_organism,wh_measure) 
           if(!is.finite(scores[i, j])) {
              scores[i, j]=0
           } 
               
        }
    }

    if (!sum(!is.na(scores))) {
        return(NA)
    }
    if(m>1 && n>1) {
      p1<-sum(sapply(1:m, function(x) {max(scores[x, ], na.rm = TRUE)}))
      p2<-sum(sapply(1:n, function(x) {max(scores[, x], na.rm = TRUE)}))
      sim<-(p1+p2)/(m+n)    
     
    } else {
       p1<-max(scores, na.rm = TRUE)
       p2<-sum(scores, na.rm = TRUE)
       sim<-(p1+p2)/(m+n)
    }

   #write.table(scores, file = "ref_enrich.txt", sep = "\t")
   #return(sim)
   return(round(sim, digits = 3))
}


  BPD<-mywangscore(gs1_BP, gs2_BP, ont="BP", measure="Wang")
  MFD<-mywangscore(gs1_MF, gs2_MF, ont="MF", measure="Wang")
  CCD<-mywangscore(gs1_CC, gs2_CC, ont="CC", measure="Wang")
  
  x<-c(BPD,MFD,CCD)

  write(x, file=f_output, sep = "\t")
