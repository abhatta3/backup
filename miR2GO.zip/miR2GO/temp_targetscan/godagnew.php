<?php

include("header_new.inc");
//LLJ;hsa-miR-146a-3p;4;G
$myFiledata=$_GET["My_key"];
//echo $myFiledata;
$str_arrmat=array();
$str_arrmat=explode(";",$myFiledata);
$myFile=$str_arrmat[0];
$id=$str_arrmat[1];
$loc=$str_arrmat[2];
$mut=$str_arrmat[3];
$gotype=$str_arrmat[7];

$picstatusfile="./temp/".$myFile.$id."_".$loc."_".$mut."new".$gotype.".png";

$picpath='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'.png';
$picpath2='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'2.png';


$picpath_jpg='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'.jpg';
$picpath2_jpg='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'2.jpg';


$picpath_tiff='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'.tiff';
$picpath2_tiff='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'2.tiff';


$picpath_pdf='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'.pdf';
$picpath2_pdf='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'new'.$gotype.'2.pdf';


$tablepath='http://compbio.uthsc.edu/miR2GO/temp_targetscan/temp/'.$myFile.$id.'_'.$loc.'_'.$mut.'newtable'.$gotype.'.tmp';

if(!file_exists($picstatusfile))
{
  shell_exec('sh creategraph.sh '.$myFile.' '.$id.' '.$loc.' '.$mut.' '.$gotype);
}

//sh creategraphFulltable.sh LLJ hsa-miR-146a-3p 4 G

if($gotype=="BP")
   $text="Biological Process";
else if($gotype=="MF")
   $text="Molecular Function";
else if($gotype=="CC")
   $text="Cellular Component";

$matrix1=file_get_contents("$tablepath");
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 

?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="<?php print($picpath2);?>" target="_blank">Detailed Gene Ontology figure</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/help_GO.php">Help</a>
</ul>
<br>
<div id="outernew">


<h3 align=center><a href="http://compbio.uthsc.edu/miR2GO/help_GO.php">Gene Ontology figure: <?php print($text);?></a></h3>
<br />

<a href="<?php print($picpath2);?>" target="_blank" title="Click image to open detail gene ontology figure"><img src="<?php print($picpath);?>" alt="Click to open the detail layout" width="900"></img></a>
<br />

<font color="blue" size=4>Download Gene Ontology figure: <a href="<?php print($picpath_jpg);?>">[jpg]</a> <a href="<?php print($picpath);?>">[png]</a> <a href="<?php print($picpath_pdf);?>">[pdf]</a> <a href="<?php print($picpath_tiff);?>">[tiff]</a> </font>
</br>
<font color="blue" size=4>Download Detailed Gene Ontology figure: <a href="<?php print($picpath2_jpg);?>">[jpg]</a> <a href="<?php print($picpath2);?>">[png]</a> <a href="<?php print($picpath2_pdf);?>">[pdf]</a> <a href="<?php print($picpath2_tiff);?>">[tiff]</a> </font>

<br />
<br />
<br />

<h3>Node descriptions</h3>
<table align="center" style="background-color: #9932CC; font-family:arial; font-weight: bold; font-size: 14px; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">Node number</td>
<td style="background-color: #9932CC; color: #FFFFFF">GO ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Name</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference</br>p-value; Number of genes</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common</br>p-value; Number of genes</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived</br>p-value; Number of genes</td>
</tr>
<?php
  foreach($str_arrmat as $datamat)
  {
      if(strlen($datamat)>1)
      {

            $data_cell=explode('#',$datamat);
           ?>
           <tr>
           <?php  
            foreach($data_cell as $cell)
            {  
                  ?>
                  <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
                  <?php
                   
            }
            ?>
            </tr>
           <?php
      }
  }  
?>
</table>
