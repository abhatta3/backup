#include<stdio.h>
#include<string.h>
#define l 2233
#define mirfile "snp137humanmir"
#define snpfile "snp137human"


//arg1: input snp file
//arg2: output descritption table 
//arg3:output seed with reference file
//arg4: output seed with mutation file

struct mir{
char mid[100],chr[50],strand[2],seed[8],seedtemp[20],seed1[10],seed2[10];
int loc1,loc2;
}mird[l];


struct snp{
char chr[50],strand[2],id[100],al1,al2;
int loc;
}snpd;


main()
{
	int i,j,k,pos;
	FILE *fpsnp,*fpmir,*out,*out1,*out2;
	char temp[10000];
       
	fpsnp=fopen(snpfile,"r");
       fpmir=fopen(mirfile,"r");
       out=fopen("table","w");
       out1=fopen("seed_ref","w");
       out2=fopen("seed_mut","w");

	for(i=0;i<l;i++)
	{
      		fscanf(fpmir,"%s %s %s %d %d %s",mird[i].mid,mird[i].chr,mird[i].strand,&mird[i].loc1,&mird[i].loc2,mird[i].seed);
       }
         
       while (fgets(temp, sizeof(temp), fpsnp))
       {
              sscanf(temp,"%s %s %d %s %c %c",snpd.chr,snpd.strand,&snpd.loc,snpd.id,&snpd.al1,&snpd.al2);

		for(k=0;k<l;k++)
   		{
              	if(strcmp(snpd.chr,mird[k].chr)==0 && snpd.loc>=mird[k].loc1 && snpd.loc<=mird[k].loc2)
              	{
                 		if(mird[k].strand[0]=='+')
                    			 pos=snpd.loc-mird[k].loc1;
                 		else
                     		 pos=mird[k].loc2-snpd.loc;
	  	   		if(snpd.strand[0]!=mird[k].strand[0])
    		   		{
              			if(snpd.al1=='T')
              				snpd.al1='A';
              			else if(snpd.al1=='A')
              				snpd.al1='T';
              			else if(snpd.al1=='G')
              				snpd.al1='C';
              			else if(snpd.al1=='C')
              				snpd.al1='G';

              			if(snpd.al2=='T')
              				snpd.al2='A';
              			else if(snpd.al2=='A')
              				snpd.al2='T';
              			else if(snpd.al2=='G')
              				snpd.al2='C';
              			else if(snpd.al2=='C')
              				snpd.al2='G';
    	 	   		}

                 		if(mird[k].seed[pos]==snpd.al1)
                 		{
                    			strcpy(mird[k].seed1,mird[k].seed);
                    			strcpy(mird[k].seed2,mird[k].seed);
                    			mird[k].seed2[pos]=snpd.al2;
                    			fprintf(out1,"%s\t%s\t9606\n",snpd.id,mird[k].seed1);             
                    			fprintf(out2,"%s\t%s\t9606\n",snpd.id,mird[k].seed2);
                    			fprintf(out,"%s\t%s\t%s\t",mird[k].mid,mird[k].chr,mird[k].strand);
                   		      for(i=0;i<pos;i++)  
                                      fprintf(out,"%c",mird[k].seed[i]);
                                  fprintf(out,"[%c/%c]",snpd.al1,snpd.al2);
                                  j=strlen(mird[k].seed);

                                  for(i=pos+1;i<j;i++)  
                                    fprintf(out,"%c",mird[k].seed[i]);
                                  j=0;
                                  if((snpd.al1=='A' && snpd.al2=='G') || (snpd.al1=='G' && snpd.al2=='A'))
                                      j=1;

                                 fprintf(out,"\t%s\t%d\t%c/%c\t%d\n",snpd.id,snpd.loc,snpd.al1,snpd.al2,j);

                            }  
                            else if(mird[k].seed[pos]==snpd.al2)
                            {
                    			strcpy(mird[k].seed1,mird[k].seed);
                    			strcpy(mird[k].seed2,mird[k].seed);
                    			mird[k].seed2[pos]=snpd.al1;

                    			fprintf(out1,"%s\t%s\t9606\n",snpd.id,mird[k].seed1);             
                    			fprintf(out2,"%s\t%s\t9606\n",snpd.id,mird[k].seed2);
                    			fprintf(out,"%s\t%s\t%s\t",mird[k].mid,mird[k].chr,mird[k].strand);
                    			for(i=0;i<pos;i++)  
                         			fprintf(out,"%c",mird[k].seed[i]);
                    			fprintf(out,"[%c/%c]",snpd.al2,snpd.al1);
                    			j=strlen(mird[k].seed);

                    			for(i=pos+1;i<j;i++)  
                         			fprintf(out,"%c",mird[k].seed[i]);
                   			j=0;
                   			if((snpd.al1=='A' && snpd.al2=='G') || (snpd.al1=='G' && snpd.al2=='A'))
                         			j=1;

                    			fprintf(out,"\t%s\t%d\t%c/%c\t%d\n",snpd.id,snpd.loc,snpd.al2,snpd.al1,j);



                 		}

                            //break;
                   }
                  
            }
    }


}