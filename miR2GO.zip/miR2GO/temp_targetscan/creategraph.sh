#!/bin/bash
#input files

kv=$1
mirid=$2
point=$3
allele=$4
gotype=$5

mirnafile="./temp/"$kv



export LC_ALL="C"


       if [ $allele == "T" ]
       then
          allele="U"
       fi
       
       mirname=$mirid"_"$point"_"$allele

       f_ref="./disrupted/"$kv$mirname
       f_mut="./created/"$kv$mirname
       f_common="./common/"$kv$mirname

	f_figinput=$mirnafile$mirname"fig"$gotype
       
       cat $f_figinput>$mirnafile$gotype"figfileinput.tmp"
       
       Rscript gofig.r $mirnafile$gotype"figfileinput.tmp" $mirnafile$gotype"godag.dot"

       #cat $mirnafile"godag.dot">$mirname

       grep -v "label" $mirnafile$gotype"godag.dot"|sed 's/none/normal/g'|cut -d' ' -f1-3>$mirnafile$gotype"p1.tmp"


        if [ $gotype == "BP" ] 
     	 then   
         	 x=`grep -w "GO:0008150" $mirnafile$gotype"godag.dot"|cut -d' ' -f1`
    
      	fi


      	if [ $gotype == "MF" ] 
     	 then   
         	 x=`grep -w "GO:0003674" $mirnafile$gotype"godag.dot"|cut -d' ' -f1`
    
      	fi

      	if [ $gotype == "CC" ] 
      	then   
         	 x=`grep -w "GO:0005575" $mirnafile$gotype"godag.dot"|cut -d' ' -f1`
    
      	fi



       grep "label" $mirnafile$gotype"godag.dot"|sed 's/<TD>/\t/g'|sed 's/<\/TD>/\t/g'|sed 's/<br\/>/\t/g'|cut -f3|sed '/^$/d'>$mirnafile$gotype"p2.tmp"

     #  grep "node" $mirnafile$gotype"p1.tmp"|cut -d' ' -f3>$mirnafile$gotype"c2.tmp"
 
     #  nnumber=`cat $mirnafile$gotype"p2.tmp"|wc -l` 

      
     #  >$mirnafile$gotype"p1.tempcolect"

     # 	for (( c=1; c<=$nnumber; c++ )); 
     #  	 do 
     #      n_c=`grep -w -c "node"$c $mirnafile$gotype"c2.tmp"` 
     #     if [ "node"$c != $x ] && [ $n_c -eq 0 ]
     #     then
     #          echo "$x -> node$c">>$mirnafile$gotype"p1.tempcolect"
     #     fi
     #  	done

 
       >$mirnafile$mirname"newtable"$gotype".tmp"
       >$mirnafile$gotype"temp.tmp" 
      
       >$mirnafile$gotype"temp2.tmp" 

       lnumber=1 
       tnumber=1 
       >$mirnafile$gotype"p2new.tmp"
  
	while read -r lineid           
	do  
          
         refn=`grep -w "$lineid" $f_ref|cut -f6`
         commonn=`grep -w "$lineid" $f_common|cut -f6`
         mutn=`grep -w "$lineid" $f_mut|cut -f6`
                
         n1=`echo $refn|wc -w`
         n2=`echo $mutn|wc -w`
         n3=`echo $commonn|wc -w`
           
         if [ $n1 -eq 0 ] || [ $lineid == "GO:0008150" ] || [ $lineid == "GO:0003674" ] || [ $lineid == "GO:0005575" ]
         then   
            refn=0
         fi

         if [ $n2 -eq 0 ] || [ $lineid == "GO:0008150" ] || [ $lineid == "GO:0003674" ] || [ $lineid == "GO:0005575" ]
         then   
            mutn=0
         fi
         if [ $n3 -eq 0 ] || [ $lineid == "GO:0008150" ] || [ $lineid == "GO:0003674" ] || [ $lineid == "GO:0005575" ]
         then   
            commonn=0
         fi
         total=$[refn+mutn+commonn]
   
         echo -e "$lineid\t$lnumber\t$total\t$refn\t$mutn\t$commonn">>$mirnafile$gotype"p2new.tmp"        
         lnumber=$[lnumber+1]
       done < $mirnafile$gotype"p2.tmp"

       sort -n -r -k3 $mirnafile$gotype"p2new.tmp">$mirnafile$gotype"p2_1.tmp"        
       
       while read -r lineread           
       do  
          
         set -- $lineread
         lineid=$1
         lnumber=$2
         total=$3
         refn=$4
         mutn=$5
         commonn=$6

         v1=255
         v2=255
         v3=255
   
     
         if [ $total -gt 0 ]
         then
         	f1=`echo $refn/$total|bc -l`
         	f2=`echo $mutn/$total|bc -l`
         	f3=`echo $commonn/$total|bc -l`
              #ref
         	v1=`echo "$v1*$f2"|bc`
              #common
         	v2=`echo "$v2*$f3"|bc`
              #mut
         	v3=`echo "$v3*$f1"|bc`
        	p1=`echo $v1 | awk '{printf("%d\n",$1 + 0.5)}'`  
         	p2=`echo $v2 | awk '{printf("%d\n",$1 + 0.5)}'` 
         	p3=`echo $v3 | awk '{printf("%d\n",$1 + 0.5)}'`
           	if [ $p1 -eq 0 ]
         	then
          	   p1="00"
         	else
       	    p1=`printf %x $p1`      
	  	fi 

         	if [ $p2 -eq 0 ]
         	then
          		p2="00"
         	else
       		p2=`printf %x $p2`      
	  	fi 

         	if [ $p3 -eq 0 ]
         	then
          		p3="00"
         	else
       	  	p3=`printf %x $p3`      
	  	fi 
         	hcode="#"$p1$p2$p3

           else
              hcode="#FFFFFF"
         fi
         
 
         wv=$[total+1]
      
 
         name=`grep -w $lineid $mirnafile$gotype"godag.dot"|sed 's/<TD>/\t/g'|sed 's/<\/TD>/\t/g'|sed 's/<br\/>/\t/g'|cut -f4`

          if [ $total -gt 0 ]
          then  


            times=`echo "l($total)/l(10)"| bc -l`
            times=`echo $times | awk '{printf("%d\n",$1 + 0.5)}'`

            wv=`echo 0.5+$times*0.5|bc -l`
            hv=`echo 0.25+$times*0.5|bc -l`

            templine1=""
            templine2=""
	     templine3=""       
            templine12=""
            templine22=""
	     templine32=""       

            templine1p=`grep "$lineid" $f_ref|cut -f3`
            templine1n=`grep "$lineid" $f_ref|cut -f6`

            templine2p=`grep "$lineid" $f_common|cut -f3`
            templine2n=`grep "$lineid" $f_common|cut -f6`

            templine3p=`grep "$lineid" $f_mut|cut -f3`
            templine3n=`grep "$lineid" $f_mut|cut -f6`

            nc1=`echo $templine1n|wc -w`

            if [ $nc1 -gt 0 ] 
            then
               templine1="Reference:[p="$templine1p";n="$templine1n"]"
               templine12=$templine1p";"$templine1n

            fi
   
            nc2=`echo $templine2n|wc -w`

            if [ $nc2 -gt 0 ] 
            then
               templine2="Common:[p="$templine2p";n="$templine2n"]"
               templine22=$templine2p";"$templine2n
            fi

            nc3=`echo $templine3n|wc -w`
            if [ $nc3 -gt 0 ] 
            then
               templine3="Derived:[p="$templine3p";n="$templine3n"]"
               templine32=$templine3p";"$templine3n
            fi

           
            echo -e "node$lnumber [label=$tnumber, fontname=\"luximb\",fontsize=50, fontcolor=white, fillcolor=\"$hcode\", style=filled, width=$wv, height=$hv];">>$mirnafile$gotype"temp.tmp"   

            ldata="label=<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\"><TR><TD>$lineid<br />$name<br />$templine1 $templine2 $templine3</TD></TR></TABLE>>"
            echo -e "node$lnumber [$ldata, shape=record, fillcolor=\"$hcode\",fontcolor=white, style=filled];">>$mirnafile$gotype"temp2.tmp"   

            echo -e "$tnumber#$lineid#$name#$templine12#$templine22#$templine32">>$mirnafile$mirname"newtable"$gotype".tmp" 

            tnumber=$[tnumber+1] 
              
          else
            echo -e "node$lnumber [label=\"\", fillcolor=\"$hcode\", style=filled, width=0.5, height=0.25];">>$mirnafile$gotype"temp.tmp"
            name=`grep -w $lineid $mirnafile$gotype"godag.dot"|sed 's/<TD>/\t/g'|sed 's/<\/TD>/\t/g'|sed 's/<br\/>/\t/g'|cut -f4`
            ldata="label=<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\"><TR><TD>$name</TD></TR></TABLE>>"
            echo -e "node$lnumber [$ldata, fillcolor=\"$hcode\", style=filled];">>$mirnafile$gotype"temp2.tmp"  
  
          fi
         


       done < $mirnafile$gotype"p2_1.tmp"


       #echo -e   "digraph dagfig {\n node [fontname="luximb",fontsize=20];\n nodesep=0.1;\n">$mirnafile"godagdisplay.dot"
       head -n 2 $mirnafile$gotype"godag.dot">$mirnafile$gotype"godagdisplay.dot"

       cat $mirnafile$gotype"temp.tmp">>$mirnafile$gotype"godagdisplay.dot"

       echo -e   "digraph dagfig {\n node [fontname="luximb",fontsize=20];\n nodesep=0.1;\n">$mirnafile$gotype"godagdisplay2.dot"
       

       cat $mirnafile$gotype"temp2.tmp">>$mirnafile$gotype"godagdisplay2.dot"


       lno=`cat $mirnafile$gotype"p1.tmp"|wc -l` 
       lno=$[lno-3]



     	#  cat $mirnafile$gotype"p1.tempcolect">>$mirnafile$gotype"godagdisplay.dot"   
       	#  cat $mirnafile$gotype"p1.tempcolect">>$mirnafile$gotype"godagdisplay2.dot"  

       tail -n $lno $mirnafile$gotype"p1.tmp">>$mirnafile$gotype"godagdisplay.dot"   
       tail -n $lno $mirnafile$gotype"p1.tmp">>$mirnafile$gotype"godagdisplay2.dot"  


      
       grep "BFO:" $mirnafile$gotype"godag.dot"|cut -d' ' -f1>$mirnafile$gotype"templist"
       #delete all BFO terms
       while read -r lineread           
       do  
         set -- $lineread
         lineid=$1
         grep -v -w $lineid $mirnafile$gotype"godagdisplay.dot">$mirnafile$gotype"godagdisplay_temp.dot"
         cat $mirnafile$gotype"godagdisplay_temp.dot">$mirnafile$gotype"godagdisplay.dot"
         grep -v -w $lineid $mirnafile$gotype"godagdisplay2.dot">$mirnafile$gotype"godagdisplay2_temp.dot"
         cat $mirnafile$gotype"godagdisplay2_temp.dot">$mirnafile$gotype"godagdisplay2.dot"
       done < $mirnafile$gotype"templist"   
      


###########################

       grep -v "label" $mirnafile$gotype"godagdisplay.dot"|cut -d' ' -f1-3>$mirnafile$gotype"p1.tmp"


       grep "label" $mirnafile$gotype"godagdisplay.dot"|cut -d' ' -f1>$mirnafile$gotype"p2.tmp"

       grep "node" $mirnafile$gotype"p1.tmp"|cut -d' ' -f3>$mirnafile$gotype"c2.tmp"
 
     
       >$mirnafile$gotype"p1.tempcolect"

       while read -r lineread           
       do  
         set -- $lineread
         nodename=$1

          n_c=`grep -w -c $nodename $mirnafile$gotype"c2.tmp"` 
          if [ $nodename != $x ] && [ $n_c -eq 0 ] 
          then
               		echo "$x -> $nodename">>$mirnafile$gotype"p1.tempcolect"
          fi

       	done < $mirnafile$gotype"p2.tmp"


       grep -v "}" $mirnafile$gotype"godagdisplay.dot">$mirnafile$gotype"p1.tmp"
      
       cat  $mirnafile$gotype"p1.tempcolect">>$mirnafile$gotype"p1.tmp"
       echo "}" >>$mirnafile$gotype"p1.tmp"

       cat $mirnafile$gotype"p1.tmp">$mirnafile$gotype"godagdisplay.dot"



       grep -v "}" $mirnafile$gotype"godagdisplay2.dot">$mirnafile$gotype"p1.tmp"
      
       cat  $mirnafile$gotype"p1.tempcolect">>$mirnafile$gotype"p1.tmp"
       echo "}" >>$mirnafile$gotype"p1.tmp"

       cat $mirnafile$gotype"p1.tmp">$mirnafile$gotype"godagdisplay2.dot"



#########################

       dot -Tpng $mirnafile$gotype"godagdisplay.dot" -o $mirnafile$mirname"new"$gotype".png" 
       dot -Tpng $mirnafile$gotype"godagdisplay2.dot" -o $mirnafile$mirname"new"$gotype"2.png" 

       
       dot -Tjpg $mirnafile$gotype"godagdisplay.dot" -o $mirnafile$mirname"new"$gotype".jpg" 
       dot -Tjpg $mirnafile$gotype"godagdisplay2.dot" -o $mirnafile$mirname"new"$gotype"2.jpg" 

       dot -Ttiff $mirnafile$gotype"godagdisplay.dot" -o $mirnafile$mirname"new"$gotype".tiff" 
       dot -Ttiff $mirnafile$gotype"godagdisplay2.dot" -o $mirnafile$mirname"new"$gotype"2.tiff" 

       dot -Tpdf $mirnafile$gotype"godagdisplay.dot" -o $mirnafile$mirname"new"$gotype".pdf" 
       dot -Tpdf $mirnafile$gotype"godagdisplay2.dot" -o $mirnafile$mirname"new"$gotype"2.pdf" 

