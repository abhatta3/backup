<?php
include("header_new.inc");

$myFile=$_GET["My_key"];

$matrix1=file_get_contents("$myFile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 

?>



<div id="outernew">
<h3><a href="http://compbio.uthsc.edu/miR2GO/help_enrich.php">Enriched functional categories</a></h3>
<br>
<table style="background-color: #9932CC; font-family:arial; font-weight: bold; font-size: 14px; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2">
<tr>
<td style="background-color: #9932CC; color: #FFFFFF">Term ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Term name</td>
<td style="background-color: #9932CC; color: #FFFFFF">Domain</td>
<td style="background-color: #9932CC; color: #FFFFFF">P-value</td>
<td style="background-color: #9932CC; color: #FFFFFF">Term size</td>
<td style="background-color: #9932CC; color: #FFFFFF">Query size</td>
<td style="background-color: #9932CC; color: #FFFFFF">Overlap size</td>
</tr>

<?php
$row=0;
foreach($str_arrmat as $datamat)
{
  $row++;
  if(strlen($datamat)>5 && $row>1)
  {

  $data_cell=explode("\t",$datamat);
   if($data_cell[9]!="mi")
   {

     if(trim($data_cell[9])=="BP" || trim($data_cell[9])=="MF" || trim($data_cell[9])=="CC")
     {
  
?>
  <tr>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[8]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[11]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[9]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[2]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[3]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[4]); ?> </td>
          <td style="background-color: #FFFF0F; color: #6B248E"> <?php print($data_cell[5]); ?> </td>

  </tr>
 <?php
   }
   else
   {

?>
  <tr>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[8]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[11]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[9]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[2]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[3]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[4]); ?> </td>
          <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[5]); ?> </td>

  </tr>
 <?php
   }
  }
 }
}
?>
</table>
