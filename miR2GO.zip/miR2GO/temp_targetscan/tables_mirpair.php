<?php
include("header_new.inc");

$myFile=$_GET["My_key"];

$statusfile="./temp/$myFile"."status";
while (!file_exists($statusfile)) sleep(1);


$myFiletemp="./temp/$myFile";


$myFileload="./temp/".$myFile.".png";
$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';


$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);



?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>



<div id="outernew">
</br>
<h2>Results</h2>
</br>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out1">Enriched functional categories for predicted miRNA target sets</a></h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair</br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>

<?php

foreach($str_arrmat as $datamat)
{
  if(strlen($datamat)>5)
  {

  $data_cell=explode("\t",$datamat);

?>
  <tr>
  <?php
  $i=1;
  foreach($data_cell as $cell)
  {
       $cell=trim($cell);
       if($i==1)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
       <?php
       }
       else if($i>1 && $i<4)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($cell);?>>download</a> </td>
       <?php
       }
       else
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($cell);?>" target='_blank'>display</a></br><a href=<?php print($cell);?>>download</a> </td>
       <?php
       } 
    $i++; 
  }
   ?>
  </tr>
 <?php
 }
}
?>
</table>
</br>
</br>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out2">Functional similarity scores and gene ontology graphs</a></h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair</br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
</tr>

<?php
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>5)
  {

  $data_cell1=explode("\t",$datamat1);
  $datatosend1=trim($data_cell1[0]);
  $datatosend=$myFile.";".$datatosend1;
?>
  <tr>
  <?php
  foreach($data_cell1 as $cell)
  {
        $cell=trim($cell);
  ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
 
  <?php
  }
  ?>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";BP"; print($datatosend);?>" target='_blank'>Biological Process</a></br>
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";MF"; print($datatosend);?>" target='_blank'>Molecular Function</a></br>
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";CC"; print($datatosend);?>" target='_blank'>Cellular Component</a></br>
  </td> 
  </tr>
 <?php
 }
}
?>
</table>

</div>
