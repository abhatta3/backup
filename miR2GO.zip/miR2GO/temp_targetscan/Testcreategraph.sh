#!/bin/bash
#input files

kv=$1
mirid=$2
point=$3
allele=$4
gotype=$5

mirnafile="./temp/"$kv



export LC_ALL="C"


       if [ $allele == "T" ]
       then
          allele="U"
       fi
       
       mirname=$mirid"_"$point"_"$allele

       f_ref="./disrupted/"$kv$mirname
       f_mut="./created/"$kv$mirname
       f_common="./common/"$kv$mirname

	f_figinput=$mirnafile$mirname"fig"$gotype
       
       cat $f_figinput|awk '!x[$0]++'>$mirnafile$gotype"figfileinput.tmp"
       
       Rscript gofig.r $mirnafile$gotype"figfileinput.tmp" $mirnafile$gotype"godag.dot"

       dot -Tpng $mirnafile$gotype"godag.dot" -o $mirnafile$mirname"new"$gotype".png" 
       dot -Tpng $mirnafile$gotype"godag.dot" -o $mirnafile$mirname"new"$gotype"2.png" 


