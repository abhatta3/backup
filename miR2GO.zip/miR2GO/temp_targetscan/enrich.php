<?php
include("header_new.inc");



$myFile=$_GET["My_key"];
$matrixfile=file_get_contents("./temp/$myFile");
$statusfile="./temp/$myFile"."status";
$thresholdfile="./temp/$myFile"."threshold";
$filterfile="./temp/$myFile"."filter";
$thrval=file_get_contents("$thresholdfile");
$filter=file_get_contents("$filterfile");
$filter=trim($filter);
$algf="./temp/$myFile"."algo";
$algo=file_get_contents("$algf");
$algo=trim($algo);

$data_cell0=array(); 
$fileval=array();
$thrval=trim($thrval);
$si=0;
$seq_arr=array();

$snpfile="./temp/$myFile"."temp";



 //convert from fasta to tab
 $mystring = $matrixfile;
 $findme   = '>';
 $pos = strpos($mystring, $findme);
 
 if($pos!==false)
 {
     $matrixfile=shell_exec('sh fastatotab.sh ./temp/'.$myFile);

 }

 
$str_arrmat0=array();
$str_arrmat0=explode("\n",$matrixfile);





if(!file_exists($statusfile))
{

foreach($str_arrmat0 as $datamat0)
{
  if(strlen($datamat0)>5)
  {
   $datamat0=str_replace("\t",' ',$datamat0);
   $datamat0=str_replace(",",' ',$datamat0);
   $datamat0=str_replace(";",' ',$datamat0);
   $datamat0=str_replace('  ',' ',$datamat0);
   $data_cell0=explode(' ',$datamat0);
   $i=0;
   foreach($data_cell0 as $cell)
   {  
    if(strlen($cell)>0)
    {   
      $fileval[$i]=trim($cell);
      $i++;
    } 
   }

   
   $mystring = $fileval[1];
   $findme   = '[';
   $pos = strpos($mystring, $findme);
  
   if(strlen($fileval[0])<3 || strlen($fileval[1])<6)
   {
     print("Input data formatting error");
   }
   else if($pos === false && file_exists($snpfile))
   {

       $mirid=$fileval[0];
       $seed1=$fileval[1];
       $point=$fileval[2];
       $allele=$fileval[3];
       $seed2=$seed1;
       if($allele=='T')
             $allele='U';
       $seed2[$point-1]=$allele;
       //$thrval="0.01";
       $mirname=$mirid."_".$point."_".$allele;

       if($algo=="TS")
       { 
          $seed1=substr($seed1, 1, 7);
          $seed2=substr($seed2, 1, 7);
          $dataref=$mirid."\t".$seed1."\t9606";
          $datamut=$mirid."\t".$seed2."\t9606";
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref_t.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut_t.tmp";
       }
       else if($algo=="MR")
       {
          $dataref=">".$mirid."\n".$seed1;
          $datamut=">".$mirid."\n".$seed2;
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut.tmp";
       }
       else
       {

          $dataref=">".$mirid."\n".$seed1;
          $datamut=">".$mirid."\n".$seed2;
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut.tmp";

	   $fhref = fopen($dirref, 'w') or die("can't open file");
          fwrite($fhref, "$dataref");
          fclose($fhref);

          $fhmut = fopen($dirmut, 'w') or die("can't open file");
          fwrite($fhmut, "$datamut");
          fclose($fhmut);

          $seed1=substr($seed1, 1, 7);
          $seed2=substr($seed2, 1, 7);
          $dataref=$mirid."\t".$seed1."\t9606";
          $datamut=$mirid."\t".$seed2."\t9606";
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref_t.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut_t.tmp";


       }

       $fhref = fopen($dirref, 'w') or die("can't open file");
       fwrite($fhref, "$dataref");
       fclose($fhref);

       $fhmut = fopen($dirmut, 'w') or die("can't open file");
       fwrite($fhmut, "$datamut");
       fclose($fhmut);

       shell_exec('sh runprediction.sh '.$myFile.' '.$algo.' '.$mirid.' '.$point.' '.$allele.' '.$thrval.' '.$filter);



   }  
   else if($pos !== false)
   {
       $mirid=$fileval[0];
       $seq_arr[$si]=$mystring;
       $si++; 
       $loc=$pos+1;
       $mutref=$mystring[$pos+1];
       $mutpoint=$mystring[$pos+3];

       $stringf=substr($mystring, 0, $pos);
       $mystringl=strlen($mystring)-1;  
       $stringe=substr($mystring, $pos+5,$mystringl); 
       $newstring=$stringf.$mutref.$stringe;


       $seed1=$newstring;
       $point=$loc;
       $allele=$mutpoint;

       $seed2=$seed1;
       if($allele=='T')
             $allele='U';
       $seed2[$point-1]=$allele;
       //$thrval="0.01";
       $mirname=$mirid."_".$point."_".$allele;

       if($algo=="TS")
       { 
          $seed1=substr($seed1, 1, 7);
          $seed2=substr($seed2, 1, 7);
          $dataref=$mirid."\t".$seed1."\t9606";
          $datamut=$mirid."\t".$seed2."\t9606";
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref_t.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut_t.tmp";
       }
       else if($algo=="MR")
       {
          $dataref=">".$mirid."\n".$seed1;
          $datamut=">".$mirid."\n".$seed2;
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut.tmp";
       }
       else
       {

          $dataref=">".$mirid."\n".$seed1;
          $datamut=">".$mirid."\n".$seed2;
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut.tmp";

	   $fhref = fopen($dirref, 'w') or die("can't open file");
          fwrite($fhref, "$dataref");
          fclose($fhref);

          $fhmut = fopen($dirmut, 'w') or die("can't open file");
          fwrite($fhmut, "$datamut");
          fclose($fhmut);

          $seed1=substr($seed1, 1, 7);
          $seed2=substr($seed2, 1, 7);
          $dataref=$mirid."\t".$seed1."\t9606";
          $datamut=$mirid."\t".$seed2."\t9606";
          $dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."ref_t.tmp";
          $dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$mirname."mut_t.tmp";


       }

       $fhref = fopen($dirref, 'w') or die("can't open file");
       fwrite($fhref, "$dataref");
       fclose($fhref);

       $fhmut = fopen($dirmut, 'w') or die("can't open file");
       fwrite($fhmut, "$datamut");
       fclose($fhmut);

       shell_exec('sh runprediction.sh '.$myFile.' '.$algo.' '.$mirid.' '.$point.' '.$allele.' '.$thrval.' '.$filter);


   } 

  }
  
 }

}//end of status
else
{

  foreach($str_arrmat0 as $datamat0)
  {
      if(strlen($datamat0)>5)
      {
           $datamat0=str_replace("\t",' ',$datamat0);  
           $datamat0=str_replace('  ',' ',$datamat0);
           $data_cell0=explode(' ',$datamat0);
           $seq_arr[$si]=trim($data_cell0[1]);
           $si++;
      }
   } 

}

$si=0;

$myFileload="./temp/".$myFile.".png";
$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';

$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);

shell_exec('sh maketar.sh '.$myFile);



?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRmut2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>



<div id="outernew">
<h2>Results</h2>
</br>
<?php
if(file_exists($snpfile))
{
 $alldbsnpid=array();
 $il=0;
  foreach($str_arrmat0 as $datamat0)
  {
      if(strlen($datamat0)>1)
      {
                 $data_cell0=explode(' ',$datamat0);
            
                  $seq=$data_cell0[1]; $loc=$data_cell0[2]-1; $loca=$loc-2; $locb=$loc+1; $sl=strlen($seq)-$locb;  $al=$data_cell0[3]; 
                   if($al=='T')
                      $al='U';
                  $sp1=substr($seq, 0, $loc);  
                  $sp2=substr($seq, $loc,1); $sp3=substr($seq, $locb,$sl); $dstring=$sp1."[".$sp2."/".$al."]".$sp3;  
                  $seq_arr[$si]=$dstring;
                  $si++; 
                 
            
      }
  }  
}



?>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out1">Enriched functional categories for predicted miRNA target sets</a></h3>
<table align="center" style="background-color: #9932CC; font-family:arial; font-weight: bold; font-size: 14px ; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>

<?php


  $i=0;
foreach($str_arrmat as $datamat)
{
  if(strlen($datamat)>5)
  {
	$data_cell=explode("\t",$datamat);
  ?>
  <tr>
       <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[0]); ?> </td>
       <td style="background-color: #EFCFFE; color: #6B248E"><?php print($seq_arr[$i]); $i++; ?></td>

		<td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($data_cell[3]);?>>download</a> </td>
		<td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($data_cell[4]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[5]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[5]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[6]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[6]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[7]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[6]);?>>download</a> </td>
		
  </tr>
 <?php
  

 }
}


?>



</table>
</br>
<a href="./Results.all.<?php print($myFile);?>/Results.all.tar"><h3>Download all results</h3></a>


</br>
</br>

</br>
</br>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out2">Functional similarity scores and gene ontology graphs</a></h3>
<table align="center" style="background-color: #9932CC; font-family:arial; font-weight: bold; font-size: 14px ; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
</tr>

<?php
$i=0;
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>5)
  {

  $data_cell1=explode("\t",$datamat1);
 
  $datatosend1=str_replace("\t", ";", $datamat1);
  
?>
  <tr>

       <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell1[0]); ?> </td>
      <td style="background-color: #EFCFFE; color: #6B248E" ><?php print($seq_arr[$i]); $i++;?></td>  
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[3]);?></td>
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[4]);?></td>
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[5]);?></td>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";BP"; print($datatosend);?>" target='_blank'>Biological Process</a></br>
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";MF"; print($datatosend);?>" target='_blank'>Molecular Function</a></br>
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";CC"; print($datatosend);?>" target='_blank'>Cellular Component</a></br>
  </td> 
  </tr>
 <?php
 }
}
?>
</table>
</div>
<?php
$stausprint=1;
$fhrefstatus = fopen($statusfile, 'w') or die("can't open file");
fwrite($fhrefstatus, $stausprint);
fclose($fhrefstatus)
?>