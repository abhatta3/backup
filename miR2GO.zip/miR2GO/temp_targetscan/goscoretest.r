#perform functional enrichment for input gene list #
#use gprofiler for functional enrichment and then gosimsem for compariso between two groups of functionally enriched terms for two input gene lists #

args <- commandArgs(trailingOnly = TRUE)
pval_thr=as.numeric(args[1])
filtertype=args[2]

data1txt=args[3]
data2txt=args[4] 
data3txt=args[5]
f_ref=args[6]
f_mut=args[7] 
f_common=args[8] 
f_output=args[9]
f_figinput=args[10]
f_figinputMF=args[11]
f_figinputCC=args[12]


library(gProfileR)
library(GOSemSim)    


q1 <- scan(data1txt, what="", sep="\n")
q2 <- scan(data2txt, what="", sep="\n")
q3 <- scan(data3txt, what="", sep="\n")


result1<-gprofiler(q1, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result1, file = f_ref, row.names=FALSE, quote=FALSE, sep = "\t")

result2<-gprofiler(q2, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result2, file = f_mut, row.names=FALSE, quote=FALSE, sep = "\t")

result3<-gprofiler(q3, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result3, file = f_common, row.names=FALSE, quote=FALSE, sep = "\t")


