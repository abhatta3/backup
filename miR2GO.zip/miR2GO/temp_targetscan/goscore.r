#perform functional enrichment for input gene list #
#use gprofiler for functional enrichment and then gosimsem for compariso between two groups of functionally enriched terms for two input gene lists #

args <- commandArgs(trailingOnly = TRUE)
pval_thr=as.numeric(args[1])
filtertype=args[2]

data1txt=args[3]
data2txt=args[4] 
data3txt=args[5]
f_ref=args[6]
f_mut=args[7] 
f_common=args[8] 
f_output=args[9]
f_figinput=args[10]
f_figinputMF=args[11]
f_figinputCC=args[12]


library(gProfileR)
library(GOSemSim)    


q1 <- scan(data1txt, what="", sep="\n")
q2 <- scan(data2txt, what="", sep="\n")
q3 <- scan(data3txt, what="", sep="\n")


result1<-gprofiler(q1, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result1, file = f_ref, row.names=FALSE, quote=FALSE, sep = "\t")

result2<-gprofiler(q2, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result2, file = f_mut, row.names=FALSE, quote=FALSE, sep = "\t")

result3<-gprofiler(q3, organism="hsapiens", ordered_query=F, significant=T,exclude_iea=F, region_query=F, max_p_value=pval_thr, max_set_size=0,
correction_method="analytical", hier_filtering=filtertype, domain_size="annotated", custom_bg="", numeric_ns="")
write.table(result3, file = f_common, row.names=FALSE, quote=FALSE, sep = "\t")


    if (nrow(result1)>0) {

      if (nrow(result1[result1[][10]=='BP',][9])>0) {	
       gs1_BP<-result1[result1[][10]=='BP',][9]
	write.table(gs1_BP, file = f_figinput, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v1bp<-nrow(gs1_BP)
      } else {
        
        v1bp<-0
      }

      if (nrow(result1[result1[][10]=='MF',][9])>0) {	
       gs1_MF<-result1[result1[][10]=='MF',][9]
	write.table(gs1_MF, file = f_figinputMF, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v1mf<-nrow(gs1_MF)
      } else {

        v1mf<-0
      }

      if (nrow(result1[result1[][10]=='CC',][9])>0) {	
       gs1_CC<-result1[result1[][10]=='CC',][9]
	write.table(gs1_CC, file = f_figinputCC, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v1cc<-nrow(gs1_CC)
      } else {
        
        v1cc<-0
      }

    }



    if (nrow(result2)>0) {

      if (nrow(result2[result2[][10]=='BP',][9])>0) {	
       gs2_BP<-result2[result2[][10]=='BP',][9]
	write.table(gs2_BP, file = f_figinput, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v2bp<-nrow(gs2_BP)
      } else {
        
        v2bp<-0
      }

      if (nrow(result2[result2[][10]=='MF',][9])>0) {	
       gs2_MF<-result2[result2[][10]=='MF',][9]
	write.table(gs2_MF, file = f_figinputMF, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v2mf<-nrow(gs2_MF)
      } else {

        v2mf<-0
      }

      if (nrow(result2[result2[][10]=='CC',][9])>0) {	
       gs2_CC<-result2[result2[][10]=='CC',][9]
	write.table(gs2_CC, file = f_figinputCC, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
       v2cc<-nrow(gs2_CC)
      } else {
        
        v2cc<-0
      }
        
    }


    if (nrow(result3)>0) {

      if (nrow(result3[result3[][10]=='BP',][9])>0) {	
       gs3_BP<-result3[result3[][10]=='BP',][9]
	write.table(gs3_BP, file = f_figinput, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
      } 

      if (nrow(result3[result3[][10]=='MF',][9])>0) {	
       gs3_MF<-result3[result3[][10]=='MF',][9]
	write.table(gs3_MF, file = f_figinputMF, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
      } 

      if (nrow(result3[result3[][10]=='CC',][9])>0) {	
       gs3_CC<-result3[result3[][10]=='CC',][9]
	write.table(gs3_CC, file = f_figinputCC, row.names=FALSE, col.names=FALSE, quote=FALSE,  sep = "\t", append=TRUE)
      } 

    }



mywangscore <- function (GO1, GO2, ont = "MF", organism = "human", measure = "Wang")
{
    wh_ont <- match.arg(ont, c("MF", "BP", "CC"))
    wh_organism <- match.arg(organism, c("human", "fly", "mouse",
        "rat", "yeast", "zebrafish", "worm", "arabidopsis", "ecolik12",
        "bovine", "canine", "anopheles", "ecsakai", "chicken",
        "chimp", "malaria", "rhesus", "pig", "xenopus"))
    wh_measure <- match.arg(measure, c("Resnik", "Jiang", "Lin",
        "Rel", "Wang"))
    GO1 <- unlist(GO1)
    GO2 <- unlist(GO2)
    m <- length(GO1)
    n <- length(GO2)

    if (n == 0 && m == 0) {
        return(NA)
    }
    else if (n == 0 && m != 0) {
        return(0)
    }
    else if (n != 0 && m == 0) {
        return(0)
    }

    scores <- matrix(nrow = m, ncol = n)
   
    rownames(scores) <- GO1
    colnames(scores) <- GO2

    for (i in 1:m) {
        for (j in 1:n) {
           scores[i, j]<-goSim(GO1[i], GO2[j], wh_ont, wh_organism,wh_measure) 
           if(!is.finite(scores[i, j])) {
              scores[i, j]=0
           } 
               
        }
    }

    if (!sum(!is.na(scores))) {
        return(NA)
    }
    if(m>1 && n>1) {
      p1<-sum(sapply(1:m, function(x) {max(scores[x, ], na.rm = TRUE)}))
      p2<-sum(sapply(1:n, function(x) {max(scores[, x], na.rm = TRUE)}))
      sim<-(p1+p2)/(m+n)    
     
    } else {
       p1<-max(scores, na.rm = TRUE)
       p2<-sum(scores, na.rm = TRUE)
       sim<-(p1+p2)/(m+n)
    }

   #write.table(scores, file = "ref_enrich.txt", sep = "\t")
   #return(sim)
   return(round(sim, digits = 3))
}


if(v1bp>0 && v2bp>0){
  BPD<-mywangscore(gs1_BP, gs2_BP, ont="BP", measure="Wang")
} else {
 BPD <- NA
}

if(v1mf>0 && v2mf>0){
  MFD<-mywangscore(gs1_MF, gs2_MF, ont="MF", measure="Wang")
} else {
 MFD <- NA
}

if(v1cc>0 && v2cc>0){
  CCD<-mywangscore(gs1_CC, gs2_CC, ont="CC", measure="Wang")
} else {
 CCD <- NA
}
 
  
  x<-c(BPD,MFD,CCD)

  write(x, file=f_output, sep = "\t")
