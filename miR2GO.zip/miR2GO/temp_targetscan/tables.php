<?php
include("header_new.inc");

$myFile=$_GET["My_key"];

$statusfile="./temp/$myFile"."status";
while (!file_exists($statusfile)) sleep(1);

$seq_arr=array();
$si=0;

$matrixfile=file_get_contents("./temp/$myFile");
$str_arrmat0=array();
$str_arrmat0=explode("\n",$matrixfile);

$myFileload="./temp/".$myFile.".png";
$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';


$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);


//$str_arrmat2=array();
//$data_cell2=array(); 
//$str_arrmat2=explode("\n",$matrix3);

  foreach($str_arrmat0 as $datamat0)
  {
      if(strlen($datamat0)>5)
      {
           $datamat0=str_replace("\t",' ',$datamat0);  
           $datamat0=str_replace('  ',' ',$datamat0);
           $data_cell0=explode(' ',$datamat0);
           $seq_arr[$si]=trim($data_cell0[1]);
           $si++;
      }
   } 

$si=0;
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>






<div id="outernew">
<h2>Results</h2>
</br>
<?php

$snpfile="./temp/$myFile"."temp";

if(file_exists($snpfile))
{
 $alldbsnpid=array();
 $il=0;
  foreach($str_arrmat0 as $datamat0)
  {
      if(strlen($datamat0)>1)
      {
                 $data_cell0=explode(' ',$datamat0);
            
                  $seq=$data_cell0[1]; $loc=$data_cell0[2]-1; $loca=$loc-2; $locb=$loc+1; $sl=strlen($seq)-$locb;  $al=$data_cell0[3]; 
                   if($al=='T')
                      $al='U';
                  $sp1=substr($seq, 0, $loc);  
                  $sp2=substr($seq, $loc,1); $sp3=substr($seq, $locb,$sl); $dstring=$sp1."[".$sp2."/".$al."]".$sp3;  
                  $seq_arr[$si]=$dstring;
                  $si++; 
                 
            
      }
  }  
}
?>


<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out1">Enriched functional categories for predicted miRNA target sets</a></h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>

<?php
  $i=0;
foreach($str_arrmat as $datamat)
{
  if(strlen($datamat)>5)
  {
	$data_cell=explode("\t",$datamat);
  ?>
  <tr>
       <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell[0]); ?> </td>
       <td style="background-color: #EFCFFE; color: #6B248E"><font size="1"><?php print($seq_arr[$i]); $i++; ?></font></td>

		<td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($data_cell[3]);?>>download</a> </td>
		<td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($data_cell[4]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[5]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[5]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[6]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[6]);?>>download</a> </td>
              <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($data_cell[7]);?>" target='_blank'>display</a></br><a href=<?php print($data_cell[6]);?>>download</a> </td>
		
  </tr>
 <?php
 }
}
?>
</table>
</br>
</br>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_out2">Functional similarity scores and gene ontology graphs</a></h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
</tr>

<?php
$i=0;
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>5)
  {

  $data_cell1=explode("\t",$datamat1);
 
  $datatosend1=str_replace("\t", ";", $datamat1);
  
?>
  <tr>

       <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($data_cell1[0]); ?> </td>
      <td style="background-color: #EFCFFE; color: #6B248E" ><font size="1"><?php print($seq_arr[$i]); $i++;?></font></td>  
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[3]);?></td>
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[4]);?></td>
	<td style="background-color: #EFCFFE; color: #6B248E"><?php print($data_cell1[5]);?></td>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";BP"; print($datatosend);?>" target='_blank'>Biological Process</a></br>
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";MF"; print($datatosend);?>" target='_blank'>Molecular Function</a></br>
  <a href="godagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";CC"; print($datatosend);?>" target='_blank'>Cellular Component</a></br>
  </td> 
  </tr>
 <?php
 }
}
?>
</table>

</div>
