#!/bin/bash

kv=$1





tar -cvf "Results.all."$kv"/Results.all.tar"    "Results.all."$kv"/"
