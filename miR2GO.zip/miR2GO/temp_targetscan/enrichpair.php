<?php
include("header_new.inc");
?>
<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRmut2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>



<div id="outernew">
</br>
<h2>Results</h2>
</br>
<?php
$myFile=$_GET["My_key"];
$myFiletemp="./temp/$myFile";
$statusfile="./temp/$myFile"."status";
$thresholdfile="./temp/$myFile"."threshold";
$filterfile="./temp/$myFile"."filter";
$thrval=file_get_contents("$thresholdfile");
$filter=file_get_contents("$filterfile");
$filter=trim($filter);
$algf="./temp/$myFile"."algo";
$algo=file_get_contents("$algf");
$algo=trim($algo);
$str_arrmat0=array();
$data_cell0=array(); 
$data_cell1=array(); 
$fileval=array();
$str_arrmat1=array();



$thrval=trim($thrval);



if(!file_exists($statusfile))
{

  if(file_exists($myFiletemp))
  {
   $matrixfile=file_get_contents("$myFiletemp");
   $str_arrmat0=explode("\n",$matrixfile);
   foreach($str_arrmat0 as $datamat0)
   {
      $datamat0=trim($datamat0);
      if(strlen($datamat0)>1)
      { 
         $str_arrmat1=explode(",",$datamat0);
         $cell1=trim($str_arrmat1[0]);
         $cell2=trim($str_arrmat1[1]);

         $result1=shell_exec('grep -w '.$cell1.' '."./mature.txt");
         $result2=shell_exec('grep -w '.$cell2.' '."./mature.txt");

         $data_cell0=explode(' ',$result1);
         $data_cell1=explode(' ',$result2);

         $d11=$data_cell0[0];
         $d12=$data_cell0[1];
         $d21=$data_cell1[0];
         $d22=$data_cell1[1];
         if(strlen($d12)<7)
         {
             print("Input miRNA ID $cell1 not supported<br \>");
         }
         else if(strlen($d22)<7)
         {
             print("Input miRNA ID $cell2 not supported<br \>");
         } 
         else
         {  
 
	         if($algo=="TS")
       	  { 
          		$seed1=substr($d12, 1, 7);
          		$seed2=substr($d22, 1, 7);
          		$dataref=$d11."\t".$seed1."\t9606";
          		$datamut=$d21."\t".$seed2."\t9606";
          		$dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."ref_t.tmp";
          		$dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."mut_t.tmp";
         	  }
         	  else if($algo=="MR")
         	  {
          		$dataref=">".$d11."\n".$d12;
          		$datamut=">".$d21."\n".$d22;
          		$dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."ref.tmp";
          		$dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."mut.tmp";
         	  }
         	  else
         	  {

          		$dataref=">".$d11."\n".$d12;
          		$datamut=">".$d21."\n".$d22;
          		$dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."ref.tmp";
          		$dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."mut.tmp";

	   		$fhref = fopen($dirref, 'w') or die("can't open file");
          		fwrite($fhref, "$dataref");
          		fclose($fhref);

          		$fhmut = fopen($dirmut, 'w') or die("can't open file");
          		fwrite($fhmut, "$datamut");
          		fclose($fhmut);

          		$seed1=substr($d12, 1, 7);
          		$seed2=substr($d22, 1, 7);
          		$dataref=$d11."\t".$seed1."\t9606";
          		$datamut=$d21."\t".$seed2."\t9606";
          		$dirref="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."ref_t.tmp";
          		$dirmut="/var/www/html/compbio/miR2GO/temp_targetscan/temp/".$myFile.$datamat0."mut_t.tmp";


         	  }

         	$fhref = fopen($dirref, 'w') or die("can't open file");
         	fwrite($fhref, "$dataref");
         	fclose($fhref);

         	$fhmut = fopen($dirmut, 'w') or die("can't open file");
         	fwrite($fhmut, "$datamut");
         	fclose($fhmut);

              shell_exec('sh pair_runprediction.sh '.$myFile.' '.$algo.' '.$datamat0.' '.$thrval.' '.$filter);

         	//if($algo=="TS")
           	//	shell_exec('sh pair_runprediction.sh '.$myFile.' '.$datamat0.' '.$thrval.' '.$filter);
         	//else if($algo=="MR")
           	//	shell_exec('sh pair_runpredictionMR.sh '.$myFile.' '.$datamat0.' '.$thrval.' '.$filter);
         	//else if($algo=="TS(union)MR") 
           	//	shell_exec('sh pair_runprediction_u.sh '.$myFile.' '.$datamat0.' '.$thrval.' '.$filter);
         	//else if($algo=="TS(intersection)MR") 
           	//	shell_exec('sh pair_runprediction_i.sh '.$myFile.' '.$datamat0.' '.$thrval.' '.$filter);

        }

      }
    }
  }
  
}//end of status

//shell_exec('sh goscoreTSnew.sh '.$myFile);

$myFileload="./temp/".$myFile.".png";
//shell_exec('sh goscoreTSnew.sh '.$myFile);

$outputfile='./temp/'.$myFile.'output.tmp';
$outputfilegoss='./temp/'.$myFile.'output.tmp.goss';

$outputfilefig='./temp/'.$myFile.'outputfig.tmp';

//shell_exec('sh creategraphFulltable.sh '.$myFile);


//$matrix3=file_get_contents("$outputfilefig");

$matrix2=file_get_contents("$outputfilegoss");

$matrix1=file_get_contents("$outputfile");

$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$data_cell=array(); 


$str_arrmat1=array();
$data_cell1=array(); 
$str_arrmat1=explode("\n",$matrix2);


//$str_arrmat2=array();
//$data_cell2=array(); 
//$str_arrmat2=explode("\n",$matrix3);



shell_exec('sh maketar.sh '.$myFile);

?>
<br>
<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out1">Enriched functional categories for predicted miRNA target sets</a></h3>
<table align="center" style="background-color: #9932CC;font-family:arial; font-weight: bold; font-size: 14px ; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair</br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>
<?php
foreach($str_arrmat as $datamat)
{
  if(strlen($datamat)>5)
  {

  $data_cell=explode("\t",$datamat);

?>
  <tr>
  <?php
  $i=1;
  foreach($data_cell as $cell)
  {
       $cell=trim($cell);
       if($i==1)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
       <?php
       }
       else if($i>1 && $i<4)
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href=<?php print($cell);?>>download</a> </td>
       <?php
       }
       else
       {
       ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <a href="displaytable.php?My_key=<?php print($cell);?>" target='_blank'>display</a></br><a href=<?php print($cell);?>>download</a> </td>
       <?php
       } 
    $i++; 
  }
   ?>
  </tr>
 <?php
 }
}
?>
</table>
</br>
<a href="./temp/<?php print($myFile);?>Data/Results.tar"><h3>Download all results</h3></a>

</br>
</br>

</br>
</br>

<h3><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRpair2GO_out2">Functional similarity scores and gene ontology graphs</a></h3>
<table align="center" style="background-color: #9932CC;font-family:arial; font-weight: bold; font-size: 14px ; text-align: center;" width="100%" cellspacing="1" cellpadding="5" border="2"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair</br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
</tr>

<?php
foreach($str_arrmat1 as $datamat1)
{
  if(strlen($datamat1)>5)
  {

  $data_cell1=explode("\t",$datamat1);
  $datatosend1=trim($data_cell1[0]);
  $datatosend=$myFile.";".$datatosend1;
?>
  <tr>
  <?php
  foreach($data_cell1 as $cell)
  {
        $cell=trim($cell);
  ?>
        <td style="background-color: #EFCFFE; color: #6B248E"> <?php print($cell); ?> </td>
 
  <?php
  }
  ?>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";BP"; print($datatosend);?>" target='_blank'>Biological Process</a></br>
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";MF"; print($datatosend);?>" target='_blank'>Molecular Function</a></br>
  <a href="pairgodagnew.php?My_key=<?php $datatosend=$myFile.";".$datatosend1.";CC"; print($datatosend);?>" target='_blank'>Cellular Component</a></br>
  </td> 
  </tr>
 <?php
 }
}
?>
</table>

</div>
<?php
$stausprint=1;
$fhrefstatus = fopen($statusfile, 'w') or die("can't open file");
fwrite($fhrefstatus, $stausprint);
fclose($fhrefstatus)
?>