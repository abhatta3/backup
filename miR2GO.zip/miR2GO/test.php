<?php 
include("header_new.inc");
include("header_batchsearch.inc");


$data_cell0=array();
$data_cell0[1]="ab[c/x]defgh";



$mystring = $data_cell0[1];
$findme   = '[';
$pos = strpos($mystring, $findme);

// Note our use of ===.  Simply == would not work as expected
// because the position of 'a' was the 0th (first) character.
if ($pos === false) {
    echo "The string '$findme' was not found in the string '$mystring'";
} else {

     $loc=$pos+1;
     $mutref=$mystring[$pos+1];
     $mutpoint=$mystring[$pos+3];

     $stringf=substr($mystring, 0, $pos);
     $mystringl=strlen($mystring)-1;  
     $stringe=substr($mystring, $pos+5,$mystringl); 
     $newstring=$stringf.$mutref.$stringe;
    echo "The string '$findme' was found in the string '$mystring'";
    echo " and exists at position $pos";
    echo "new string=$newstring";
    echo "loc=$loc";
    echo "mut=$mutpoint";    
}


$data_cell0[2]=4;
$data_cell0[3]="X";

$seq=$data_cell0[1]; 
$loc=$data_cell0[2]-1; 
$loca=$loc-2; 
$locb=$loc+1; 
$sl=strlen($seq)-$locb;  
$al=$data_cell0[3];

$sp1=substr($seq, 0, $loc);  
$sp2=substr($seq, $loc,1);
$sp3=substr($seq, $locb,$sl);
$dstring=$sp1."[".$sp2."/".$al."]".$sp3;

//echo $dstring;


?>

<A TITLE="Your text description"><font color="red" size=3>[?]</font></A>