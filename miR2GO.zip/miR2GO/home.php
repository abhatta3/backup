<?php 

include("header_new.inc");



$filename = './temp_targetscan/temp/';

if (!file_exists($filename)) {
    mkdir($filename, 0775, true);
}



$filename = './temp_targetscan/disrupted/';

if (!file_exists($filename)) {
    mkdir($filename, 0775, true);
}


$filename = './temp_targetscan/created/';

if (!file_exists($filename)) {
    mkdir($filename, 0775, true);
}


$filename = './temp_targetscan/common/';

if (!file_exists($filename)) {
    mkdir($filename, 0775, true);
}


?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRmut2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>


<!-- Main content -->
<div id="outer">
<h1>miR2GO: Comparative functional analysis for microRNAs</h1>
<br><IMG SRC="miR2GOfig.png" ATL="" BORDER=0 WIDTH=700 HEIGHT=400 align="middle"><BR>
<br>
<br>
    <p align="justify">MicroRNAs (miRNAs) are a class of posttranscriptional regulators that involve in almost every biological process. The dysfunctions of miRNAs have been linked with many diseases. A miRNA may interact with Argonaute family proteins to form a RNA-induced silencing complex (RISC) and guide the RISC to bind to mRNA targets. The sequence complementarity between miRNAs and their binding sites in mRNAs is crucial to the target recognition. Genetic and somatic mutations in miRNA sequences, especially those in the seed region, can disrupt the interactions between miRNAs and their targets. These mutations can also make the miRNA bind to a set of new targets. Thus, the mutations in miRNAs can alter miRNA targeting and rewire the miRNA regulatory networks. The main purpose of this web server is to provide a computational tool for the assessment of functional impacts of genetic and somatic mutations in miRNAs. The first function of this web server, miRmut2GO, allows users to analyze the changes of target genes caused by miRNA mutations and view the functional impacts of these changes in a gene ontology graph. This web server can also be used for analyzing the differences and similarities between the functions of different miRNAs. Different miRNAs perform different functions because they bind to different sets of target genes. The second function of the web server, miRpair2GO, allows users to perform comparative gene ontology analysis for the target gene sets of different miRNAs. 
<br><br>
<b>*A note about web browser usage:</b> The function of displaying GO figures is not supported by the current version of Internet Explorer. The default threshold for connection timeout in Firefox is 300 seconds. It may take longer time to run the queries containing more multiple mutations. Here is an <a href="http://compbio.uthsc.edu/miR2GO/firefox.php" target="_blank">instruction</a> on how to change the connection timeout setting in Firefox. We suggest to use Google Chrome when accessing miR2GO.</p>
    <p align="justify">&nbsp;</p>
    <p align="justify"><span class="td_head"><strong>How to cite miR2GO:</strong></span></p>
    <p align="justify"><br>
    <span class="style1">Bhattacharya A and Cui Y (2015) <a href="http://bioinformatics.oxfordjournals.org/content/31/14/2403">miR2GO:  Comparative functional analysis for microRNAs</a>. Bioinformatics 31:2403-2405.</span></p>
    <p align="justify"><br>
      <b>Developed and maintained by: </b><a href="http://compbio.uthsc.edu/" target="_blank">Yan Cui's Lab at University of Tennessee Health Science Center</a>
      <br>
    </p>
<br>
<br>
<br>
</div>
</body>
</html>

