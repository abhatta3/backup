<?php

$key=$_POST["My_key"];
if($key=="")
  $key="ab";//uniqid("");

include("header_new.inc");
?>

<!-- Site navigation menu -->
<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRSNP2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/downloads/">Download</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>

</ul>


<!-- Main content -->
<div id="outer">

<table width=100% align=center>
<tr>
<td>
<h2>Table of Contents</h2>
<ol>
<li><a href="#introduction">Introduction</a>
<li><a href="#method_miRSNP2GO">miRSNP2GO overview</a>
<li><a href="#method_miRpair2GO">miRpair2GO overview</a>
<li><a href="#target_prediction">miRNA target prediction</a>
<li><a href="#enrich_term">Functional enrichment of GO terms</a>
<li><a href="#score">Similarity scores</a>
<li><a href="#godag">GO dag figures</a>
</ol>
</td>
</tr>
</table>


<br>
<table>
<tr>
<a name=learn_methods><h2>1. Introduction to miR2GO</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify">miR2GO provides the integrative platform to compare the miRNA target gene sets for similarities in enriched GO terms. miRSNP2GO and miRpair2GO are two independent work flows of miR2GO. miRSNP2GO provides the services to compare between target gene sets for reference and mutation sequences of the same miRNA. On the other hand, miRpair2GO compares pair of miRNAs for their target gene sets.</p> 
</td></tr>
</table>

<br>
<table>
<tr>
<a name=method_miRSNP2GO><h2>2. Overview of miRSNP2GO</h2></a>
</tr>
<br>
<tr><td>
<p align="justify"> 
<IMG SRC="mir2gosnpoverview.png" ATL="" BORDER=0 WIDTH=812 HEIGHT=290><br>
miRSNP2GO provides two input options to users. The first option is for advance users of bioinformatics tools who can prepare their own data and paste in the text box where users are allowed to prepare their own data with any unique id as miRNA id and any nucleotide sequnce as miRNA sequnce. Each row of their data must include miRNA id, miRNA sequence, location of mutation in miRNA sequence and derive allele of the mutation.This option of miRSNP2GO is particularly useful for the analysis of new miRNA sequences those are newly identified from experiments and yet to be included in miRBase. 
<br>
For the second input option of miRSNP2GO, users have to give the miRNA ids from miRBase release 20 as input. Such input are restricted to analysis of SNPs from dbSNP release 138 only. For each input miRNA id the genomic locations of mature miRNAs are retrieved from miRBase release 20. Then for each mature miRNA location, the genomic coordinate of 2nd base as seed start and 8th base as seed end are compared against the genomic locations of dbSNPs in the table "snp138" from track "ALL SNPs (138)" of UCSC table browser to identify the SNPs in miRNA seeds.
</p> 
</td></tr>
</table>

<br>
<table>
<tr>
<a name=method_miRpair2GO><h2>3. Overview of miRpair2GO</h2></a>
</tr>
<br>
<tr><td>
<p align="justify"> 
<IMG SRC="mir2gopairoverview.png" ATL="" BORDER=0 WIDTH=812 HEIGHT=290><br>


</p> 
</td></tr>
</table>
<br>
<table>
<tr>
<a name=target_prediction><h2>4. miRNA target prediction</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify"> </p> 
</td></tr>
</table>
<br>
<table>
<tr>
<a name=enrich_term><h2>5. Computing functional enrichment of GO terms</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify"> </p> 
</td></tr>
</table>
<br>
<table>
<tr>
<a name=similarity><h2>6. Computing similarity scores from GO terms</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify"> </p> 
</td></tr>
</table>
<br>
<table>
<tr>
<a name=godag><h2>7. Displaying enriched GO terms in a directed acyclic graph</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify"> </p> 
</td></tr>
</table>

</div>
</html>
