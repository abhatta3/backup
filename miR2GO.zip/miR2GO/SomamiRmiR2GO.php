<script>
function check(id) { 
var thistextbox = id.replace('box', 'area');
var othertextarea = 'textarea1';
if(id.slice(-1) == '1'){
    othertextarea = 'textarea2';
}
var othertextbox = othertextarea.replace('area', 'box');
document.getElementById(id).checked = true;
document.getElementById(thistextbox).disabled = false;
document.getElementById(othertextarea).disabled = true;
document.getElementById(othertextbox).checked = false;

}</script>


<?php 
include("header_new.inc");
include("header_batchsearch.inc");

$searchID=$_GET["seq"];


/////////////Generate a random key/////////////////////
$alphas=array();
$alphas = array_merge(range('A', 'Z'), range('a', 'z'));
$al1=rand(0,51);
$al2=rand(0,51);
$al3=rand(0,51);
$alpha="$alphas[$al1]"."$alphas[$al2]"."$alphas[$al3]";
$keyval=$alpha;
if($_POST["My_key"]!="")
  $keyval=$_POST["My_key"];

////////////////////max parent/////////////////////////

$sid=$keyval."_input";
$dir="/var/www/html/compbio/miR2GO/temp_targetscan/temp/";


if(isset($_POST['my_algo'])) 
   $sym_algo = $_POST['my_algo'];
else
   $sym_algo = "TS";

if(isset($_POST['my_filter'])) 
   $sym_hr = $_POST['my_filter'];
else
   $sym_hr = "moderate";

if(isset($_POST['my_thr'])) 
   $sym_thr = $_POST['my_thr'];
else
  $sym_thr = "0.01";

    if(isset($_POST['text_box'])) { //only do file operations when appropriate
        $a = $_POST['text_box'];
        $myFile = $dir.$keyval;
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$a\n");
        fclose($fh);

        $myFile = $dir.$keyval."filter";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_hr\n");
        fclose($fh);

        $myFile = $dir.$keyval."threshold";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_thr\n");
        fclose($fh);

        $myFile = $dir.$keyval."algo";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_algo\n");
        fclose($fh);

?>

<script>
window.open("http://compbio.uthsc.edu/miR2GO/result.php?My_key=<?php print($keyval);?>",'_self',false);
</script>
<?php
  
   }

    if(isset($_POST['text_box1'])) { //only do file operations when appropriate
        $b = $_POST['text_box1'];
        $myFile = $dir.$keyval."temp";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$b\n");
        fclose($fh);

        $myFile = $dir.$keyval."filter";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_hr\n");
        fclose($fh);

        $myFile = $dir.$keyval."threshold";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_thr\n");
        fclose($fh);

        $myFile = $dir.$keyval."algo";
        $fh = fopen($myFile, 'w') or die("can't open file");
        fwrite($fh, "$sym_algo\n");
        fclose($fh);


?>

<script>
window.open("http://compbio.uthsc.edu/miR2GO/result.php?My_key=<?php print($keyval);?>",'_self',false);
</script>
<?php
  
   }
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRmut2GO</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>  
  <li><a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO">Help</a>
  <li><a href="http://compbio.uthsc.edu/miR2GO/home.php">Home</a>
</ul>


<div id="outernew">
<h3><font color=#33339f>miRmut2GO: Functional analysis of genetic and somatic mutations in microRNAs</font></h3>
<br/>
<form id="form1" name="form" method="post" action="<?php $_SERVER['PHP_SELF'] ?>">
<table>
<tr>
<td align="left">1. <a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_in1"><strong>Select miRNA target prediction method</strong></a>
</td>
</tr>  
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;<span>Use single prediction method</span>
</td>
</tr>
<tr>
<td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="radio" type="radio" name="my_algo" value="TS" checked checked /> <span>TargetScan</span>
</td>
</tr>
<tr>
</tr>
<tr>
<td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="radio" type="radio" name="my_algo" value="MR" /> <span>miRanda</span>
</td>
</tr>
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;<span>Combine results from the two prediction methods</span>
</td>
</tr>
<tr>
<td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="radio" type="radio" name="my_algo" value="TSunionMR" /> <span>Union</span>
</td>
</tr>
<tr>
<td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="radio" type="radio" name="my_algo" value="TSintersectionMR" /> <span>Intersection</span>
</td>
</tr>
<TR>
<TD>
&nbsp;
</TD>
</TR>
<tr>
<td align="left">2. <a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_in2"><strong>Specify p-value threshold for functional enrichment analysis</strong></a></td> 
</tr>  
<tr>
<td>
<?php
if(isset($_POST['my_thr'])) 
{
?> 
    <textarea name="my_thr" id="my_thr" cols="8" rows="1"><?php print($sym_thr) ?></textarea>
<?php
}
else
{
?>
   <textarea name="my_thr" id="my_thr" cols="8" rows="1">0.01</textarea>
<?php
}
?>
</td>
</tr>
<TR>
<TD>
&nbsp;
</TD>
</TR>
<tr>
<td align="left">3. <a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_in3"><strong>Select Gene Ontology hierarchical filtering level</strong></a></td>
</tr>  
<tr>
<td>
  <input class="radio" type="radio" name="my_filter" value="none" /> <span>none</span>
</td>
</tr>
<tr>
</tr>
<tr>
<td>
  <input class="radio" type="radio" name="my_filter" value="moderate" checked /> <span>moderate</span>
</td>
</tr>
<tr>
<td>
  <input class="radio" type="radio" name="my_filter" value="strong"/> <span>strong</span>
</td>
</tr>
</table>
<br />
<p>
4.
<input type="radio" id="textbox1" onclick="check(this.id)" checked="true" /> <a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_in4"><strong>Paste miRNA sequences</strong></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=example_mirsnp2go_1.php>Example (CSV)</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=example_mirsnp2go_fasta.php>Example (fasta)</a><br>&nbsp;&nbsp;IDs and Sequences in fasta format<br>
<?php
if(isset($_POST['text_box'])) 
{
?> 
    <textarea name="text_box" id="textarea1" cols="50" rows="5"><?php print($a) ?></textarea>
<?php
}
else
{
?>
   <textarea name="text_box" id="textarea1" cols="50" rows="5"><?php print($searchID);?>
</textarea>
<?php
}
?>
<br><strong>OR
<br>
&nbsp;&nbsp;&nbsp;<input type="radio" id="textbox2" onclick="check(this.id)"/> <a href="http://compbio.uthsc.edu/miR2GO/help.php#miRmut2GO_in4">Paste miRNA IDs or dbSNP IDs</strong> </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=example_mirsnp2go_2.php >Example (search by miRNA)</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=example_mirsnp2go_2dbsnp.php >Example (search by SNP)</a><br>


<?php
if(isset($_POST['text_box1'])) 
{
?> 
    <textarea name="text_box1" id="textarea2" disabled="true" cols="35" rows="5"><?php print($b) ?></textarea>
<?php
}
else
{
?>
   <textarea name="text_box1" id="textarea2" disabled="true" cols="30" rows="5"></textarea>
<?php
}
?>
</p>
  <p>
   <br>
    <input type="submit" name="button" id="button" value="Submit" />
<br>
<br>
</p>

</form>


</div>

</body>
</html>


