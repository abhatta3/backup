<?php 

include("header_new.inc");
?>
<p align="justify">
<br>
<br>
<b>How can I change the connection timeout setting in Firefox?</b><br>(from superuser.com) 
<br>
<br>
After the last Firefox update we had the same session timeout issue & following setting helped to resolve it.
<br>
We can control it with network.http.response.timeout parameter.
<br>
<br>
1. Open Firefox & type in 'about:config' in the address bar & press Enter.
<br>
<br>
2. Click on the 'I'll be careful, I promise' button.
<br>
<br>
3. Type 'timeout' in the search box and network.http.response.timeout parameter will be displayed.
<br>
<br>
4. Doube click on the 'network.http.response.timeout' parameter & enter the time value (it is in seconds) that you don't want your session not to timeout, in the box.
<br>
<br>
</p>