<?php 

include("header_new.inc");
?>

<!-- Main content -->
<div id="outer">
<table width=100% align=center>
<tr>
<td>
<h2>Table of Contents</h2>

<a href="#intro">Introduction</a><br>
<a href="#miRmut2GO">miRmut2GO</a><br>
<a href="#miRpair2GO">miRpair2GO</a><br>

</td>
</tr>
</table>
<br>
<a name=intro><h2>Introduction</h2></a>
<br>
<p align="justify">
miR2GO is an integrative web-platform for comparative analysis of microRNA function. It includes two functions: <a href="http://compbio.uthsc.edu/miR2GO/mir2goSNP.php">miRmut2GO</a> and <a href="http://compbio.uthsc.edu/miR2GO/mir2gocompare.php">miRpair2GO</a>. miRmut2GO is used to compare target gene sets for the reference (wild-type) and derived (mutated) alleles of miRNAs with genetic and /or somatic mutations, while miRpair2GO is used to compare target gene sets for different miRNAs. 
</p>
<br>
<a name=miRmut2GO><h2>miRmut2GO</h2></a>
<br>

<strong>Input</strong><br><br>
<ol>
<li><p align="justify"><a name=miRmut2GO_in1>Select <font color= "red">prediction method</font>:</a><br>
Users can select one of the following miRNA target prediction methods<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">TargetScan</font>: predict miRNA targets using <a href= "http://www.targetscan.org/">TargetScan</a>.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">miRanda</font>: predict miRNA targets using <a href="http://www.microrna.org/microrna/home.do">miRanda</a>.<br> 
Or users can combine the output of these two prediction methods by using: <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">Union</font> of the predicted target sets from TargetScan and miRanda, or<br> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">Intersection</font> of the predicted target sets from TargetScan and miRanda. <br><br>
<br>
</p>

<li><p align="justify"><a name=miRmut2GO_in2>Specify <font color= "red">p-value threshold for functional enrichment analysis</font></a>
The p-value threshold is used to determine the significantly enriched functional categories for each target gene set.</p> <br><br>  

<li><p align="justify"><a name=miRmut2GO_in3>Select Gene Ontology <font color= "red">hierarchical filtering level</font></a>
Hierarchical filtering is used to group the similar GO terms in the hierarchy of the GO graph. For each group of GO terms, one GO term is selected as the representative term for the group. Three hierarchical filtering options are:<br>
<font color= "red">none</font>: No hierarchical filtering, thus all the enriched GO terms are presented independently. <br>
<font color= "red">moderate</font>: Moderate filtering allows a single parent for each group in the GO hierarchy where all the enriched descendent terms of the parent term are included in the group and then the term with the lowest enrichment p-value is considered as representative term for the group.<br> 
<font color= "red">strong</font>: Strong filtering allows multiple parents for the same group. For strong filtering option, the groups in the GO term hierarchies are defined by including the GO terms with common descendent in the same group. Thus the total number of representative terms are expected to be lower by using strong filtering. <br><br>
</p>
<li><p align="justify"><a name=miRmut2GO_in4>Paste <font color= "red">miRNA sequences</font></a><br>
The first option is to enter miRNA ID (a unique identifier for the miRNA, but it does not have to be a miRBase ID) and miRNA sequence in the textbox. IDs and sequences are should be in csv (comma separated) or fasta formats. miRNA sequence is the ~22 nucleotide of mature miRNA sequence. The input sequence specifies the SNP (or mutation) as [reference allele/derived allele] at the SNP (or mutation) site. Users can enter multiple input entries for multiple miRNAs.<br>
The second option is to enter either the miRNA IDs (must be the miRBase ID) or dbSNP IDs as input. Users can enter multiple input rows for multiple miRNAs.
</br>
</br>
*Note: One miRNA could have multiple SNPs in its sequence and for such cases the webserver will give output for each SNP in the miRNA sequence. For a dbSNP id the webserver will only give the result for that SNP. This is visible from our miRNA id example. 
</p><br><br>
</ol>


<a name=miRmut2GO_out><strong>Output</strong></a><br><br>
<ol>
<li><p align="justify"><a name=miRmut2GO_out1><font color= "red">Enriched functional categories for miRNA target predictions</font></a>:<br> 
Example:<br>
<h3>Enriched functional categories for predicted miRNA target sets</h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">Reference targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Derived targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>
  <tr>
       <td style="background-color: #EFCFFE; color: #6B248E">hsa-miR-593-5p</td>
       <td style="background-color: #EFCFFE; color: #6B248E"><font size="1">AGG[C/G]ACCAGCCAGGCAUUGCUCAGC</font></td>
       <td style="background-color: #EFCFFE; color: #6B248E">download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
  </tr>
</table>
<br>
<font color= "red">Reference targets:</font> Download target prediction results for the input miRNA (with the reference allele).<br>
<font color= "red">Derived targets:</font> Download target prediction results for the input miRNA (with the derived allele).<br>
<font color= "red">Reference targets functional enrichment:</font> Display the <a href="help_enrich.php">enriched functional categories</a> for the reference target genes. Download link can be used for downloading the same content in txt format.<br>
<font color= "red">Derived targets functional enrichment:</font> Display <a href="help_enrich.php">enriched functional categories</a> for derived target genes. Download link can be used for downloading the same content in txt format.<br>
<font color= "red">Common targets functional enrichment:</font> Display the <a href="help_enrich.php">enriched functional categories</a> for the common targets of reference and derived alleles of the miRNA. Download link can be used for downloading the same content in txt format.<br>
<br>
*Note: <u>Download all results</u> link can be used for downloading all the results as a zip folder of .txt files.
<br>
</br>
</p>
<li><p align="justify"><a name=miRmut2GO_out2><font color= "red">Functional similarity scores and gene ontology graphs</font>:</a><br> 
Example:<br>
<h3>Functional similarity scores and gene ontology graphs</h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID</td>
<td style="background-color: #9932CC; color: #FFFFFF">Sequence</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
 <tr>
       <td style="background-color: #EFCFFE; color: #6B248E">hsa-miR-593-5p</td>
       <td style="background-color: #EFCFFE; color: #6B248E"><font size="1">AGG[C/G]ACCAGCCAGGCAUUGCUCAGC</font></td>

	<td style="background-color: #EFCFFE; color: #6B248E">0.551</td>
	<td style="background-color: #EFCFFE; color: #6B248E">0.434</td>
	<td style="background-color: #EFCFFE; color: #6B248E">0.561</td>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a>Biological Process</a></br>
  <a>Molecular Function</a></br>
  <a>Cellular Component</a></br>
  </td>
  </tr>
</table>
<br>

<font color= "red">Similarity score</font>: A score (ranging from 0 to 1) for the semantic similarity between the enriched GO terms associated with target gene sets for the reference and derived alleles. A score close to 1 indicates high similarity. A score close to 0 indicates low similarity. "NA" represents no score as there is no significantly enriched GO term.</br>
<font color= "red"><a href="help_GO.php">Gene Ontology figures</a></font>: Links to open the Directed Acyclic Graph (DAG) for biological process, molecular function and cellular component.</br> 
</br>
</p>
</ol>

<br>
<a name=miRpair2GO><h2>miRpair2GO</h2></a>
<br>

<strong>Input</strong><br><br>
<ol>
<li><p align="justify"><a name=miRpair2GO_in1>Select <font color= "red">prediction method</font>:</a><br>
Users can select one of the following miRNA target prediction methods<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">TargetScan</font>: predict miRNA targets using <a href= "http://www.targetscan.org/">TargetScan</a>.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">miRanda</font>: predict miRNA targets using <a href="http://www.microrna.org/microrna/home.do">miRanda</a>.<br> 
Or users can combine the output of these two prediction methods<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">Union</font> of the predicted target sets from TargetScan and miRanda.<br> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color= "red">Intersection</font> of the predicted target sets from TargetScan and miRanda. <br><br>
<br>
</p>

<li><p align="justify"><a name=miRpair2GO_in2>Specify <font color= "red">p-value threshold for functional enrichment analysis</font></a>
The p-value threshold is used to determine the significantly enriched functional categories for each target gene set.</p> <br><br>  

<li><p align="justify"><a name=miRpair2GO_in3>Select Gene Ontology <font color= "red">hierarchical filtering level</font></a>
Hierarchical filtering is used to group the similar GO terms in the hierarchy of the GO graph. For each group of GO terms, one GO term is selected as the representative term for the group. Three hierarchical filtering options are:<br>
<font color= "red">none</font>: No hierarchical filtering, thus all the enriched GO terms are presented independently. <br>
<font color= "red">moderate</font>: Moderate filtering allows a single parent for each group in the GO hierarchy where all the enriched descendent terms of the parent term are included in the group and then the term with the lowest enrichment p-value is considered as representative term for the group.<br> 
<font color= "red">strong</font>: Strong filtering allows multiple parents for the same group. For strong filtering option, the groups in the GO term hierarchies are defined by including the GO terms with common descendent in the same group. Thus the total number of representative terms are expected to be lower by using strong filtering. <br><br>
</p>
<li><p align="justify"><a name=miRpair2GO_in4>Paste <font color= "red">miRNA pairs</font></a><br>
<font color= "red">Paste miRNA id pairs</font>: Users can enter multiple input rows for multiple miRNA pairs.
</p><br><br>
</ol>


<a name=miRpair2GO_out><strong>Output</strong></a><br><br>
<ol>
<li><p align="justify"><a name=miRpair2GO_out1><font color= "red">Enriched functional categories for miRNA target predictions</font>:</a><br> 
Example:<br>
<h3>Enriched functional categories for predicted miRNA target sets</h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair<br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II</br>targets</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA I targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA II targets</br>functional enrichment</td>
<td style="background-color: #9932CC; color: #FFFFFF">Common targets</br>functional enrichment</td>
</tr>
  <tr>
       <td style="background-color: #EFCFFE; color: #6B248E">hsa-miR-1,hsa-miR-9-5p</td>
       <td style="background-color: #EFCFFE; color: #6B248E">download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
       <td style="background-color: #EFCFFE; color: #6B248E">display</br>download</td>
  </tr>
</table>
<br>

<font color= "red">miRNA I targets</font>: Download target prediction results for the input miRNA I.<br>
<font color= "red">miRNA II targets</font>: Download target prediction results for the input miRNA II.<br>
<font color= "red">miRNA I targets functional enrichment</font>: Display the <a href="help_enrich.php">enriched functional categories</a> for miRNA I target genes. The download link can be used for downloading the same content in txt format.<br> 
<font color= "red">miRNA II targets functional enrichment</font>: Display the <a href="help_enrich.php">enriched functional categories</a> for miRNA II target genes. The download link can be used for downloading the same content in txt format.<br> 
<font color= "red">Common targets functional enrichment</font>: Display the <a href="help_enrich.php">enriched functional categories</a> for the common targets of miRNA I and miRNA II. The download link can be used for downloading the same content in txt format.<br>
<br></p>
<li><p align="justify"><a name=miRpair2GO_out2><font color= "red">Functional similarity scores and gene ontology graphs</font>:</a><br> 
Example:<br>
<h3>Functional similarity scores and gene ontology graphs</h3>
<table align="center" style="background-color: #9932CC; font-weight: bold; font-size: 12px ; text-align: center;" width="900" cellspacing="1" cellpadding="5" border="0"><tr>
<td style="background-color: #9932CC; color: #FFFFFF">miRNA ID pair<br>miRNA I,miRNA II</td>
<td style="background-color: #9932CC; color: #FFFFFF">Biological process</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Molecular function</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Cellular component</br>similarity score</td>
<td style="background-color: #9932CC; color: #FFFFFF">Gene Ontology figure</td>
 <tr>
       <td style="background-color: #EFCFFE; color: #6B248E">hsa-miR-1,hsa-miR-9-5p</td>
	<td style="background-color: #EFCFFE; color: #6B248E">0.419</td>
	<td style="background-color: #EFCFFE; color: #6B248E">0.74</td>
	<td style="background-color: #EFCFFE; color: #6B248E">0.816</td>
  <td style="background-color: #EFCFFE; color: #6B248E">
  <a>Biological Process</a></br>
  <a>Molecular Function</a></br>
  <a>Cellular Component</a></br>
  </td>
  </tr>
</table>
<br>

<font color= "red">Similarity score</font>: A score (ranging from 0 to 1) for the semantic similarity between the enriched GO terms associated with target gene sets for miRNA I and miRNA II. A score close to 1 indicates high similarity. A score close to 0 indicates low similarity. "NA" represents no score as there is no significantly enriched GO term.<br>
<font color= "red"><a href="help_GO.php">Gene Ontology figures</a></font>: Links to open the Directed Acyclic Graph (DAG) for biological process, molecular function and cellular component.<br>
<br><br>
<b>*A note about web browser usage:</b> The function of displaying GO figures is not supported by the current version of Internet Explorer. The default threshold for connection timeout in Firefox is 300 seconds. It may take longer time to run the queries containing more multiple mutations. Here is an <a href="http://compbio.uthsc.edu/miR2GO/firefox.php" target="_blank">instruction</a> on how to change the connection timeout setting in Firefox. We suggest to use Google Chrome when accessing miR2GO.
<br><br>


</p>
</ol>
</div>
</body>
</html>
