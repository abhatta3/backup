<?php 
include("header_new.inc");
$keyval=$_GET["My_key"];

$myFiletemp="./temp_targetscan/temp/$keyval"."temp";
$matrixfile=file_get_contents("$myFiletemp");

$myFile="./temp_targetscan/temp/$keyval";


$str_arrmat0=array();
$str_arrmat0=explode("\n",$matrixfile);

$fhref = fopen($myFile, 'w') or die("can't open file");
$dataref="";
foreach($str_arrmat0 as $datamat0)
 {
  
  $datamat0=trim($datamat0);
  if(strlen($datamat0)>1)
  {
     $result=shell_exec('grep '.$datamat0.' '."./temp_targetscan/snp138|cut -f1-4");
     $dataref=$result."\n".$dataref;

  }

} 
fwrite($fhref, "$dataref");
fclose($fhref);

?>

<div>
<p><h3><?php 
print("Web server is now executing your task.<br /> Execution may take several minutes.<br /> Your results will apear in the browser up on completion.<br /> You can also access you results at any time from the following link:<br />");
?>
<a href="http://compbio.uthsc.edu/miR2GO/report.php?My_key=<?php print($keyval);?>" target="_blank">http://compbio.uthsc.edu/miR2GO/report.php?My_key=<?php print($keyval);?></a>
<br><br></h3>
<br>
<table align="center"><tr><td><b></br></br></br>Computing ....</b>
<div style="font-size:20pt;padding:6px;border:solid black 4px">
<span id="progress1">&nbsp; &nbsp;</span>
<span id="progress2">&nbsp; &nbsp;</span>
<span id="progress3">&nbsp; &nbsp;</span>
<span id="progress4">&nbsp; &nbsp;</span>
<span id="progress5">&nbsp; &nbsp;</span>
<span id="progress6">&nbsp; &nbsp;</span>
<span id="progress7">&nbsp; &nbsp;</span>
<span id="progress8">&nbsp; &nbsp;</span>
<span id="progress9">&nbsp; &nbsp;</span>
<span id="progress10">&nbsp; &nbsp;</span>
</p>
</div>
</td></tr></table>

<script language="javascript">
<!-- Begin Script
var progressEnd = 10;	// set to number of progress <span>'s.
var progressColor = 'blue';	// set to progress bar color
var progressInterval = 1000;	// set to time between updates (milli-seconds)

var progressAt = progressEnd;
var progressTimer;
function progress_clear() {
for (var i = 1; i <= progressEnd; i++) document.getElementById('progress'+i).style.backgroundColor = 'transparent';
progressAt = 0;
}

function progress_update() {
progressAt++;
if (progressAt > progressEnd) progress_clear();
else document.getElementById('progress'+progressAt).style.backgroundColor = progressColor;
progressTimer = setTimeout('progress_update()',progressInterval);
}
// End -->

progress_update();	
</script>
</div>
<script>
window.open("./temp_targetscan/enrich.php?My_key=<?php print($keyval);?>",'_self',false);
</script>
