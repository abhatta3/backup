<?php 

include("header_new.inc");
?>

<!-- Main content -->
<div id="outer">
<h3>Enriched functional categories</h3>
<br>

Example:<br>
<br><IMG SRC="enrichtable.png" ATL="" BORDER=0 WIDTH=550 HEIGHT=450 align="middle"><BR>


<br>
<p>
<font color= "red">Term ID</font>:Identifiers for the functional terms.<br><br>
<font color= "red">Term name</font>: A brief description of the functional term.<br><br>
<font color= "red">Domain</font>: Abbreviation for the class or source of the functional terms:<br>
<table border=1>
<tr>
<th>
Domain
</th>
<th>
Description
</th>
</tr>
<td>BP</td><td>Biological Process</td>
</tr>
<tr>
<td>MF</td><td>Molecular Function</td>
</tr>
<tr>
<td>CC</td><td>Cellular Component</td>
</tr>
<tr>
<td>ke</td><td>Pathway in KEGG database</td>
</tr>
<tr>
<td>re</td><td>Pathway in Reactome pathway database</td>
</tr>
<tr>
<td>tf</td><td>TRANSFAC regulatory motifs</td>
</tr>
<tr>
<td>bi</td><td>BioGRID protein interaction network</td>  
</tr>
</table>
<br>
<font color= "red">P-value</font>:Functional enrichment p-value calculated using Fisher's exact test.<br><br>
<font color= "red">Term size</font>: Total number of gene for the term in the background set.<br><br>
<font color= "red">Query size</font>: Total number of genes in the query set.<br><br>
<font color= "red">Overlap size</font>: Number of genes in the overlap of the query set and background set.<br><br> 
</p>