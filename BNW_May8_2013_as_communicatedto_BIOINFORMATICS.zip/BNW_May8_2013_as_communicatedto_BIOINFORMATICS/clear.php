<?php

$keyval=$_GET["My_key"];

$vf1=$keyval."var.txt";
$vf2=$keyval."varname.txt";
$vf3=$keyval."vardata.txt";
unlink($vf1);
unlink($vf2);
unlink($vf3);
?>
<script>
window.open("http://compbio.uthsc.edu/BNW/layout.php?My_key=<?php print($keyval);?>",'_self',false);
</script>
