<?php

////////////////This code load a data file and creates deal input file for Exhaustive search. execute_bn.php link is for execution of deal and create_tiers.php is for adding restrictions///////////////////////////////////


include("header_new.inc");
include("header_batchsearch.inc");
$searchID="";
$UploadValue="NO";
$TextFile=$HTTP_POST_FILES["MyFile"]["name"];

/////////////Generate a key value for current use///////////////////////////////////////////////
$alphas=array();
$alphas = array_merge(range('A', 'Z'), range('a', 'z'));

$al1=rand(0,51);
$al2=rand(0,51);
$al3=rand(0,51);

$alpha="$alphas[$al1]"."$alphas[$al2]"."$alphas[$al3]";
$keyval=$alpha;


if($_POST["My_key"]!="")
  $keyval=$_POST["My_key"];



$sid=$keyval."deal_input";
$dir="/var/www/html/compbio/BNW/";

$TextinFileFinal=$dir.$sid.".txt";
$TextinFile=$dir.$sid."_temp.txt";
$TextinFilenamelist=$dir.$keyval."name.txt";

if(isset($HTTP_POST_VARS["searchkey"]))
{
   $searchID=$HTTP_POST_VARS["searchkey"];
}

if($searchID!="")
{
?>

<!-- Site navigation menu -->
<ul class="navbar2">
  <li><a href="create_tiers.php?My_key=<?php print($keyval);?>" target='_blank'>Select additional constraints</a>  
  <li><a href="execute_bn.php?My_key=<?php print($keyval);?>" target='_blank'>Perform Bayesian network modeling with no restraints</a>
</ul>
<ul class="navbar">
  <li><a href="help.php#file_format" target="_blank">Data formatting guidelines  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
  <li><a href="help.php">Help</a>
</ul>
<?php
}
else
{

?>
<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="help.php#file_format" target="_blank">Data formatting guidelines</a>
  <li><a href="help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
</ul>
<?php
}



if(isset($HTTP_POST_VARS["MyUpload"]))
{
   $UploadValue=$HTTP_POST_VARS["MyUpload"];
   if ($UploadValue=="YES")
   {
        if($TextFile!="")
        {
            $sta=move_uploaded_file($HTTP_POST_FILES['MyFile']['tmp_name'],$TextinFile);
            if(!$sta)
            {
                 echo "<script type='text/javascript'> window.alert ('Sorry, error uploading $TextFile.')</script>";
                 flush();
                 exit();
            }
            else
            {
                 $searchID=file_get_contents("$TextinFile");
  		  unlink($TextinFile);

            }

        }

       else
       {
           echo "<script type='text/javascript'> window.alert ('Sorry, please select upload file.')</script>";
       }
   }
}

?>
<div id="outernew">
<h2>Upload data file for structure learning using an exhaustive search and model averaging</h2>
<br>
<FORM name="key_search" enctype="multipart/form-data" ACTION="bn_file_load.php" METHOD=POST>

<table align="left" cellspacing="3" cellpadding="1" border="0"  width="80%">
<tr>
<td align="left">Content of uploaded data file:<br>
          <textarea name="searchkey" rows="10" cols="100"><?PHP print($searchID)?> </textarea>
</td>
</tr>
<tr>
<td>
<INPUT style="background-color:#FFFFFF;color:#0000FF" type="file" name="MyFile" size=45 > 
<INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Upload" onclick="return Upload();">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
<INPUT TYPE="hidden" name="MyUpload" value="NO"> 
</td>
</tr>
<tr>
<td>
<INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Example" onclick="return demo();">&nbsp&nbsp&nbsp
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
</td>
</tr>
</table>
<br>
<br>
</FORM>
</div>
<?php

////////////Find out variable types//////////////////////////////////

  $str_arr=array();
  $str_arr=explode("\n",$searchID);
  $data=array();
  $lc=0;
   
  $fph = fopen($TextinFilenamelist,"w");
  $fpmain = fopen($TextinFileFinal,"w");
  
  $cont_arr=array();
  $i=0;
  $data_type=array();
  foreach($str_arr as $line)
  {
    if($lc==0)
      {
        fwrite($fph, "$line\n");
	fwrite($fpmain, "$line\n");
       $name_t=$line;

	fclose($fph); 
        $data=explode("\t",$line);
	$j=0;
       foreach($data as $d_c)
	  {
	    $data_type[$j]=0;
            $j++;
          }
          $lcc=$j;
      }        
    else
      { 
         $data=explode("\t",$line);
	 $j=0;
         foreach($data as $d_c) 
         {
            $d_c=trim($d_c);
	     $cont_arr[$i][$j]=$d_c; 
            $mystring = $d_c;
	     $findme   = '.';
	     $pos = strpos($mystring, $findme);

           if ($pos != false)
           {
	             //echo "Continuous";
                   $data_type[$j]=1;
           }
             $j++;
         }
	 $i++; 
      }
     $lc++;
     
  }
$lc--;


$data_count=0;
//$count_arr=array();     
$l_type="";

for($j=0;$j<$lcc;$j++)
{

       if($data_type[$j]!=1)
	{
           
	  $data_count=0;
   
	   for($i=0;$i<$lc;$i++)
	   {
             $vi=$i+1;
	     for($ii=$vi;$ii<$lc;$ii++)
	       {
                 if($cont_arr[$i][$j]==$cont_arr[$ii][$j] && $cont_arr[$i][$j]!=-9999)
		   {
		       $cont_arr[$ii][$j]=-9999;
               
		   } 
	       }
               
              
           }

	   for($i=0;$i<$lc;$i++)
	     {
	       if($cont_arr[$i][$j]!=-9999 && $cont_arr[$i][$j]!="")
		 $data_count++;
	     }
	   $data_type[$j]=$data_count;
	    
	   
	}
       if($j==0)
         $l_type.=$data_type[$j];
       else
	 $l_type.="\t".$data_type[$j];  
      
    }

/////////////////write contents to different files required for deal and marlab///////////////////
$fptype = fopen("$keyval"."type.txt","w");
$fpnode= fopen("$keyval"."nnode.txt","w");
fwrite($fpnode,"$lcc\n");

fwrite($fptype,"$name_t\n");
for($j=0;$j<$lcc;$j++)
{
  fprintf($fptype,"$data_type[$j]\t");

}
fwrite($fptype,"\n");


  
fwrite($fpmain, "$l_type\n");
$l_c=0;
foreach($str_arr as $line)
  {
    if($l_c!=0)
      {
        
        fwrite($fpmain, "$line\n");
       
      }
      else 
         $l_c=1;
  }
fclose($fpmain);

////////////////create empty banlist and white list/////////////////////////////////
$sid1=$keyval."banlist";
$sid2=$keyval."whitelist";
$wdir="/var/www/html/compbio/BNW/"; 

$Textban=$wdir.$sid1.".txt";
$Textwhite=$wdir.$sid2.".txt";

$fpb = fopen($Textban,"w");
$fpw = fopen($Textwhite,"w");

$datpost="From\tTo\n";

fwrite($fpb,"$datpost");
fwrite($fpw,"$datpost");

?>

</body>
</html>

