<?php 

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="home_structure.php">Learn a network model from data</a>
  <li><a href="home_upload.php">Make predictions using a known structure</a>  
  <li><a href="getting_started.php">Getting started with BNW</a>
  <li><a href="workflow.php">Example workflows</a>
  <li><a href="help.php">Help</a>
  <li><a href="home.php">Home</a>


</ul>


<!-- Main content -->
<div id="outer">
<h1>BNW: from data to predictions</h1>
<IMG SRC="BNW_overview.png" ATL="" BORDER=0 WIDTH=812 HEIGHT=290><BR>
<br>
<br>
    <p align="justify"> The Bayesian Network Web Server (BNW) is a comprehensive web server for Bayesian network modeling of biological data sets. It is designed so that users can quickly and seamlessly upload a dataset, learn the structure of the network model that best explains the data, and use the model to understand and make predictions about relationships between the variables in the model. Many real world data sets, including those used to create genetic network models, contain both discrete (e.g., genotypes) and  continuous (e.g., gene expression traits) variables, and BNW allows for modeling of these hybrid data sets.
<br><br>
<b>*A note about browser usage:</b> The BNW interface for adding structural constraints uses HTML5 features that are may not be supported by many recent versions of Internet Explorer. We have not observed any problems with the interface using recent versions of any other web browser, and ,therefore, we suggest against using Internet Explorer when accessing BNW. 
</p>
<br>
<br>
<br>
</div>
</body>
</html>