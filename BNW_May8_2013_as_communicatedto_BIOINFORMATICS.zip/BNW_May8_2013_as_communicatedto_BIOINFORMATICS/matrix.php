<?php 
$keyval=$_GET["My_key"];

$matfile="/var/www/html/compbio/BNW/".$keyval."matrix.txt";
$fpw=fopen($keyval."Structure_matrix.txt","w");

//echo $matfile;

$mf=$keyval."matrix.txt";
$mfc=file_get_contents("$mf"); 



$nm="/var/www/html/compbio/BNW/".$keyval."name.txt";
$namelist=file_get_contents("$nm");



$str_arrname=array();
$str_arrname=explode("\n",$namelist);
$dataname=array();
$dataname=explode("\t",$str_arrname[0]);


if($mfc!="")
{?>
 <h2> Probability Matrix from Model Averaging </h2>
 <br><table width="90%" align="center" style="background-color:" bordercolor="" border=1 cellspacing="0" cellpadding="0">
  
<tr>
<th>
Name
</th>
<?php
fprintf($fpw,"Model Average Matrix\nName\t");
foreach($dataname as $cell1)
{
  $cell1=trim($cell1);
    ?>
<th> <?php print($cell1);?> </th>
<?php
 fprintf($fpw,"%s\t",$cell1);
}
fprintf($fpw,"\n");
?>
</tr>
<?php
  $matrix=file("$matfile");
  $matrix1=file_get_contents("$matfile");              //file("$matfile");
  $str_arrmat=array();
  $str_arrmat=explode("\n",$matrix1);
  $datamat=array();
  $data_cell=array(); 
  $i=-1; 
   foreach($str_arrmat as $datamat)
   {
       $i++;
       ?>
   <tr>
   <th>
      <?php print trim($dataname[$i]); ?>
   </th>
   <?php
    $dpr=trim($dataname[$i]);
    fprintf($fpw,"%s\t",$dpr);

	$data_cell=explode(" ",$datamat);
        foreach($data_cell as $cell)
	{
         $cell=trim($cell);
         if($cell!="")
          {  
          ?>
          <td>
            <?php  print($cell); ?>
         </td>   
     <?php
           fprintf($fpw,"%s\t",$cell);  
	     }
        }
      ?> 
    <tr>
   <?php
        fprintf($fpw,"\n");
       }
     ?>
 </table>
<?php 

}

/////////////////////////////////Second//////////////////////////////////////////////////////////


$matfile=$keyval."structure_input.txt";
//echo $matfile;


$matrix1=file_get_contents("$matfile");              //file("$matfile");
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$datamat=array();
$data_cell=array(); 

$dataname=array();
$dataname=explode("\t",$str_arrmat[0]);
$n=count($dataname);





//echo $m_line;


if($matrix1!="")
{?>
 <h2> Structure Matrix </h2>
 <br><table width="90%" align="center" style="background-color:" bordercolor="" border=1 cellspacing="0" cellpadding="0">
  
<tr>
<th>
Name
</th>
<?php
fprintf($fpw,"\n\nStructure Matrix\nName\t");

foreach($dataname as $cell1)
{
  $cell1=trim($cell1);
    ?>
<th> <?php print($cell1); ?> </th>
<?php
fprintf($fpw,"%s\t",$cell1);
}
?>
</tr>
<?php
   fprintf($fpw,"\n");
   for($i=0;$i<$n;$i++)
   {
       $ii=$i+1;
       $datamat=explode("\t",$str_arrmat[$ii]);
        
       ?>
   <tr>
   <th>
      <?php print trim($dataname[$i]); ?>
   </th>
   <?php
     $dpr=trim($dataname[$i]);
    fprintf($fpw,"%s\t",$dpr);
 
	foreach($datamat as $cell)
	{
         $cell=trim($cell);
         if($cell!="")
          {  
          ?>
          <td>
            <?php  print $cell; ?>
         </td>   
     <?php
         fprintf($fpw,"%s\t",$cell);
	     }
        }
      ?> 
    <tr>
   <?php
       fprintf($fpw,"\n");
       }
     ?>
 </table>
<?php 

}
?>

<a href=<?php print($keyval);?>Structure_matrix.txt>download</a>
<input type=button onClick="self.close();" value="Close this window">