#!/bin/bash
d=`dirname $0`
#ess=1
k=$1
$d/../src/data2netk_poster.sh $d/names.vd $d/data.idt $d/resdir $k
