#!/bin/bash

binpath=`dirname $0`

if [ $# -ne 4 ]; then
    echo Usage: data2net.sh vdfile datafile resultdir k 1>&2
    exit 1
fi

vdfile=$1;    shift 
datafile=$1;  shift
#score=$1;     shift
rdir=$1;      shift
k=$1;shift


mkdir -p $rdir

nof_vars=`cat $vdfile | wc -l`
echo "The number of variables is $nof_vars."

#HR:
maxindegree=`expr $nof_vars - 1`
echo "maxindegree is $maxindegree."

#HR:
nof_instances=`cat $datafile | wc -l`
#delete the header
nof_instances=`expr $nof_instances - 1`
echo "The number of instances is $nof_instances."


#START=$(date +%s%N)
#$binpath/get_local_scores $vdfile $datafile $score 1 0${rdir}/res
#HR
#echo "get_local_scores is done."
#$binpath/split_local_scores   $nof_vars ${rdir}
#HR
#echo "split_local_scores is done."
#$binpath/reverse_local_scores $nof_vars ${rdir}
#HR
#echo "reverse_local_scores is done."
#END=$(date +%s%N)
#DIFF=$(( $END - $START ))
#DIFF1=$(( $END - $START ))
#echo "Local score took $DIFF1 seconds"

#the above is the same as original bene

START=$(date +%s%N)
$binpath/Poster -m $maxindegree -d $datafile -u $nof_instances -opt 3  -dir ${rdir} > ${rdir}/exactResults_from_POSTER.txt 
END=$(date +%s%N)
DIFF1=$(( $END - $START ))
echo "Poster part took $DIFF1 n-seconds."


START=$(date +%s%N)
$binpath/get_kbest_parents $nof_vars ${rdir} $k
#HR
END=$(date +%s%N)
#DIFF=$(( $END - $START ))
DIFF2=$(( $END - $START ))
echo "get_kbest_parents is done."
echo "get_kbest_parents took $DIFF2 n-seconds."

START=$(date +%s%N)
$binpath/get_kbest_nets $nof_vars ${rdir} $k
#HR
END=$(date +%s%N)
#DIFF=$(( $END - $START ))
DIFF3=$(( $END - $START ))
echo "get_kbest_nets is done."
echo "get_kbest_nets took $DIFF3 n-seconds."

DIFF=`expr $DIFF1 + $DIFF2 + $DIFF3`
echo "The total process took $DIFF n-seconds."
