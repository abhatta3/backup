<?php 
unlink("abmatrix.txt");
unlink("abname.txt");
unlink("structure_input.txt");
unlink("continuous_input.txt");

unlink("net_figure.txt");
unlink("net_figure_new.txt");
unlink("standardized_data.txt");

unlink("structure_input_new.txt");
unlink("structure_old.txt");
unlink("nnode.txt");
unlink("type.txt");
unlink("var.txt");
unlink("varname.txt");
unlink("vardata.txt");

unlink("map.txt");
unlink("mapdata.txt");


$key=$_POST["My_key"];
if($key=="")
  $key="ab";//uniqid("");

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar2">
<li><a href="upload_structure_file.php">Upload data and structure files</a>
</ul>
<ul class="navbar">
  <li><a href="help.php#file_format" target="_blank">Data formatting guidelines</a>
  <li><a href="help.php">Help</a>
  <li><a href="home.php">Home</a>
</ul>

<div id="outer">
<!-- Main content -->
<br>
<br>
<h1>Investigate networks with a known structure</h1>
<br>
<p align="justify"> 
  BNW can be used to study and make predictions for models with a known structure. To use this feature, click the "Upload data and structure files" button below to upload the file containing the data for each of the variables in the network. Then, upload a file containing the network structure. Guidelines for formatting the data and structure data files can be found <a href="help.php#file_format">here</a>.
<br>
<br>
<FORM METHOD="LINK" ACTION="upload_structure_file.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Upload data and structure files" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 300px;">
</FORM>
</p>
<br>
</div>
</body>
</html>