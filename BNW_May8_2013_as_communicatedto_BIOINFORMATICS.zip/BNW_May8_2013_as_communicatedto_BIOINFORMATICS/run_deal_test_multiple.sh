cut  -f1-4 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-5 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-6 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-7 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-8 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-9 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-10 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-11 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
cut  -f1-12 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.
