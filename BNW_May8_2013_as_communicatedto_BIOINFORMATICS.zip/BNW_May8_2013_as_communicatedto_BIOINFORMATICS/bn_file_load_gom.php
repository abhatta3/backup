<?php
////////////////This code load a data file and creates input file for continuous global optimal search (our modification). execute_bn_gom.php link is for execution of structure learning and create_tiers_gom.php is for adding restrictions///////////////////////////////////

include("header_new.inc");
include("header_batchsearch.inc");
$searchID="";
$UploadValue="NO";
$TextFile=$HTTP_POST_FILES["MyFile"]["name"];

/////////////Generate a random key/////////////////////
$alphas=array();
$alphas = array_merge(range('A', 'Z'), range('a', 'z'));

$al1=rand(0,51);
$al2=rand(0,51);
$al3=rand(0,51);

$alpha="$alphas[$al1]"."$alphas[$al2]"."$alphas[$al3]";
$keyval=$alpha;


if($_POST["My_key"]!="")
  $keyval=$_POST["My_key"];


////////////////////max parent/////////////////////////


$type_n=array();

//Get number of parent data and key value for changes in number of parent
$type_n=explode("|",$_POST["nm_parent"]);
$parent_number=$type_n[0];   
if($keyval=="")
   $keyval=$type_n[1];

if($parent_number=="")
{
   $parent_number=2;
}



$sid=$keyval."deal_input";
$dir="/var/www/html/compbio/BNW/";

$TextinFileFinal=$dir.$sid.".txt";

$TextinFile=$dir.$sid."_temp.txt";
$TextinFilenamelist=$dir.$keyval."name.txt";

//print number of parents
$pfile=$dir.$keyval."parent.txt";
$parentf=fopen($pfile,"w");
fwrite($parentf,"$parent_number\n");



if(isset($HTTP_POST_VARS["searchkey"]))
{
   $searchID=$HTTP_POST_VARS["searchkey"];

}

?>




<?php

if($searchID!="")
{
?>

<!-- Site navigation menu -->
<ul class="navbar2">
  <li><a href="create_tiers_gom.php?My_key=<?php print($keyval);?>" target='_blank'>Select additional constraints</a>  
  <li><a href="execute_bn_gom.php?My_key=<?php print($keyval);?>" target='_blank'>Perform Bayesian network modeling with no restraints</a>
</ul>
<ul class="navbar">
  <li><a href="help.php#file_format" target="_blank">Data formatting guidelines</a> 
  <li><a href="help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
</ul>
<?php
}
else
{

?>
<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="help.php#file_format" target="_blank">Data formatting guidelines</a> 
  <li><a href="help.php">Help</a>
  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
</ul>
<?php
}



if(isset($HTTP_POST_VARS["MyUpload"]))
{
   $UploadValue=$HTTP_POST_VARS["MyUpload"];
   if ($UploadValue=="YES")
   {
        if($TextFile!="")
        {
            $sta=move_uploaded_file($HTTP_POST_FILES['MyFile']['tmp_name'],$TextinFile);
            if(!$sta)
            {
                 echo "<script type='text/javascript'> window.alert ('Sorry, error uploading $TextFile.')</script>";
                 flush();
                 exit();
            }
            else
            {
                 $searchID=file_get_contents("$TextinFile");
		 //fclose($fh);
		  unlink($TextinFile);

            }

        }

       else
       {
           echo "<script type='text/javascript'> window.alert ('Sorry, please select upload file.')</script>";
       }
   }
}

?>
<div id="outernew">
<h2><font color=#33339f>Upload data file for global optimal structure learning search</font></h2>
<FORM name="key_search" enctype="multipart/form-data" ACTION="bn_file_load_gom.php" METHOD=POST>

<table align="left" cellspacing="3" cellpadding="1" border="0"  width="80%">
<tr>
<td align="left"><font color=#33339f>Content of uploaded data file:</font><br>
          <textarea name="searchkey" rows="10" cols="100"><?PHP print($searchID)?> </textarea>
</td>
</tr>
<tr>
<td>
<INPUT style="background-color:#FFFFFF;color:#0000FF" type="file" name="MyFile" size=45 > 
<INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Upload" onclick="return Upload();">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
<INPUT TYPE="hidden" name="MyUpload" value="NO"> 
</td>
</tr>
<tr>
<td>
<INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Example" onclick="return demo2();">&nbsp&nbsp&nbsp
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
</td>
</tr>
</table>
<br>
<br>

<table align="left" width=60%>
<tr>

<td align="center">
<br>Select the maximum number of parents for each variables:
</td>
<td align="left">
<br> 
     <form method="post" action="bn_file_load_gom.php" name="form">
      <SELECT NAME="nm_parent"  onchange="form.submit();">
      <?php for($i=1;$i<10;$i++)
      {
        ?>
           <option value=<?php $combined=$i."|".$keyval; print($combined)?> <?php if($parent_number == $i) {print "selected";}?>><?php print($i)?></option>
     <?php
     }
   
     ?>  
     <option value=<?php $combined="0|".$keyval; print($combined)?> <?php if($parent_number == 0) {print "selected";}?>><?php print("ALL")?></option>

      </SELECT>
   </form>
</td>
</tr>
</table>

</FORM>
</div>
<?php
//////////////////Format data for Structure learning "C" code////////

  $str_arr=array();
  $str_arr=explode("\n",$searchID);
  $data=array();
  $lc=0;
   
  $fph = fopen($TextinFilenamelist,"w");
  $fpmain = fopen($TextinFileFinal,"w");
  $fpC = fopen($keyval."continuous_input.txt","w");

///////We dont need this .idt file for this execution. We only prepare this to match the original input. We may remove this. Now it contains all '1'. ////////////
  $stidt="/var/www/html/compbio/BNW/bene-0.9-4/example/".$keyval."deal_input.idt";
  $fpidtname=fopen("$stidt","w");
 
  $cont_arr=array();
  $i=0;
  $data_type=array();
  foreach($str_arr as $line)
  {
    if($lc==0)
      {
        fwrite($fph, "$line\n");
	fprintf($fpmain, "$line\n");
       $name_t=$line;

	fclose($fph); 
        $data=explode("\t",$line);
	$j=0;
       foreach($data as $d_c)
	  {
	    $data_type[$j]=0;
            $j++;
          }
          $lcc=$j;
      }        
    else
      { 
        
         $strline=""; 
         $data=explode("\t",$line);
	 $j=0;
         foreach($data as $d_c) 
         {
            $d_c=trim($d_c);
	     $cont_arr[$i][$j]=$d_c; 
            $mystring = $d_c;
	     $findme   = '.';
	     $pos = strpos($mystring, $findme);
            $strline.="1\t";
  
           if ($pos != false)
           {
	             //echo "Continuous";
                   $data_type[$j]=1;
           }
             $j++;
         }
	 $i++; 
       fwrite($fpidtname,"$strline\n");  
      }
     $lc++;
     
  }
$lc--;


$data_count=0;
    
$l_type="";

for($j=0;$j<$lcc;$j++)
{

       if($data_type[$j]!=1)
	{
           
	  $data_count=0;
   
	   for($i=0;$i<$lc;$i++)
	   {
             $vi=$i+1;
	     for($ii=$vi;$ii<$lc;$ii++)
	       {
                 if($cont_arr[$i][$j]==$cont_arr[$ii][$j] && $cont_arr[$i][$j]!=-9999)
		   {
		       $cont_arr[$ii][$j]=-9999;
               
		   } 
	       }
               
              
           }

	   for($i=0;$i<$lc;$i++)
	     {
	       if($cont_arr[$i][$j]!=-9999 && $cont_arr[$i][$j]!="")
		 $data_count++;
	     }
	   $data_type[$j]=$data_count;
	    
	   
	}
       if($j==0)
         $l_type.=$data_type[$j];
       else
	 $l_type.="\t".$data_type[$j];  
      
    }

///////////////////Write data to files/////////////////
$fptype = fopen($keyval."type.txt","w");
$fpnode= fopen($keyval."nnode.txt","w");
fwrite($fpnode,"$lcc\n");

$stl="/var/www/html/compbio/BNW/bene-0.9-4/example/".$keyval."name.vd";
$fpvdname=fopen("$stl","w");

fwrite($fptype,"$name_t\n");
for($j=0;$j<$lcc;$j++)
{
  fprintf($fptype,"$data_type[$j]\t");
  fwrite($fpvdname,"$name_t\n");
}
fwrite($fptype,"\n");


  
fwrite($fpmain, "$l_type\n");
$l_c=0;
foreach($str_arr as $line)
  {
    if($l_c!=0)
      {
        
        fwrite($fpmain, "$line\n");
       
      }
      else 
         $l_c=1;
  }
fclose($fpmain);

////////////////empty ban and white list/////////////////////////////

$sid1=$keyval."banlist";
$sid2=$keyval."whitelist";
$wdir="/var/www/html/compbio/BNW/"; 

$Textban=$wdir.$sid1.".txt";
$Textwhite=$wdir.$sid2.".txt";

$fpb = fopen($Textban,"w");
$fpw = fopen($Textwhite,"w");

$datpost="From\tTo\n";

fwrite($fpb,"$datpost");
fwrite($fpw,"$datpost");


?>


</body>
</html>

