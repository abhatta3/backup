#include<stdio.h>
#include<stdlib.h>
#include <math.h>

typedef unsigned int varset_t;

#define MAX_NOF_VARS (32)
#define LARGEST_SET(NOF_VARS) ((NOF_VARS)==MAX_NOF_VARS?(varset_t)~0:(1U<<(NOF_VARS))-1)

unsigned int nof_vars;
FILE *out;

varset_t task_index2varset(int nof_taskvars, int task_index)
{
  unsigned int allvars = LARGEST_SET(nof_vars);
  unsigned int fixvars = task_index << nof_taskvars;
  return (~fixvars) & allvars;
}

void scores(int len_vs, varset_t vs)
{
  int i;

  for(i=0; i<nof_vars; ++i){
    varset_t iset = 1U<<i;
    if (vs & iset) {
      
      vs ^= iset;
      printf("child<-parentset\t%d\t%u\n",i, vs);
     fprintf(out,"child<-parentset\t%d\t%u\n",i, vs);
      vs ^= iset;
    }
  }
  
}




void walk_contabs(int len_vs, varset_t vs, int nof_calls)
{
  
  int i;
 
 //printf("%d,%u,%d\n",len_vs,vs,nof_calls);
// fprintf(out,"walk\t%d\%u\t%d\n",len_vs,vs,nof_calls);
 scores(len_vs, vs);
    if (len_vs > 1)
  	{
    
        for (i=0; i<nof_calls; ++i)
		 {
           walk_contabs(len_vs-1, vs^(1U<<i), i);
         }
    }
}

int ilog2(int i) /* i has to be > 0 */
{
  int n = 0;
  while(i>>=1) ++n;
  return n;
}

void main(int argc,char *argv[])
{
    int nof_tasks   = 1;
    int task_index  = 0;
    int nof_fixvars = ilog2(nof_tasks);
    int len_vs;
    unsigned int vs;
    char fname[500];
    if(strcmp(argv[1],"-h")==0)
    {  
        printf("Usage:exefilename number_of_variables output_order_list_file_name\n");
        printf("Example:./a.out 5 tmpdatasequence\n");
        exit;
        
    }
    else
    {
       nof_vars=atoi(argv[1]);
       out=fopen(argv[2],"w");
    
       len_vs=nof_vars;
       vs = task_index2varset(nof_vars - nof_fixvars, task_index);
	walk_contabs(len_vs, vs, nof_vars-nof_fixvars);
    
       fclose(out);
   }
	
}
