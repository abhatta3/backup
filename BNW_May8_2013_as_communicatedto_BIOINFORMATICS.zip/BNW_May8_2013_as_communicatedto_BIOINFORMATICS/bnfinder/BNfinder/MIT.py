# Copyright (c) 2004-2007 Bartek Wilczynski and Norbert Dojer; All Rights Reserved.
#
# This software is distributable under the terms of the GNU
# General Public License (GPL) v2, the text of which can be found at
# http://www.gnu.org/copyleft/gpl-2.0.txt. Installing, importing or otherwise
# using this module constitutes acceptance of the terms of this License.
#
# Disclaimer
# 
# This software is provided "as-is".  There are no expressed or implied
# warranties of any kind, including, but not limited to, the warranties
# of merchantability and fittness for a given application.  In no event
# shall the authors be liable for any direct, indirect, incidental,
# special, exemplary or consequential damages (including, but not limited
# to, loss of use, data or profits, or business interruption) however
# caused and on any theory of liability, whether in contract, strict
# liability or tort (including negligence or otherwise) arising in any way
# out of the use of this software, even if advised of the possibility of
# such damage.
#

import math
from score import score
from scipy.stats import chi2

class MIT(score):
    
    def graph_score(self,number_of_parents,gene_vertex,weights_of_parents,number_of_data_points, list_of_parents): # g(Pa)
        
        # chisquare
        alpha = 0.999
            
        sorted_parents = sorted(list_of_parents, key=lambda gene: gene.n_disc)
      #  print "parents.zie: ", len(list_of_parents)
        sum_of_l_values = 0.0
        
        for i in range(len(sorted_parents)):            
            l_i_sigma = (gene_vertex.n_disc - 1)*(sorted_parents[i].n_disc - 1)
            for j in range(i):
                l_i_sigma *= sorted_parents[j].n_disc
            chisquare_value = chi2.isf(1-alpha, l_i_sigma)
            
            sum_of_l_values += chisquare_value
        #print "sum_of_l_values: ", sum_of_l_values
        return sum_of_l_values    
            
    def lower_bound_for_data_score(self,vertices,data):
        if vertices.n_disc:
            return 0.0
        selected_data = self.sel_data(vertices,[],data)
        score=0.0
        for d in selected_data:
            try:
                score -= d[0]*math.log(d[0],2) + (1-d[0])*math.log(1-d[0],2)
            except:
                pass
        return score*self.data_factor

    def data_score(self,gene_vertex,parents_sequence,data):
        selected_data = self.sel_data(gene_vertex,parents_sequence,data)
        stats_all,stats_parents = self.stats(selected_data,gene_vertex,parents_sequence)
        stats_for_empty_parents, stats_for_empty_parents_fool = self.stats(selected_data,gene_vertex,[])
        score = 0.0
        if gene_vertex.cpd in ['or','and']: # continuous
            raise Exception
        else:
            number_of_effective_observations = len(data)
            number_of_vertices = gene_vertex.n_disc
            mutual_information = 0.0
            for vertex in stats_for_empty_parents.keys():
                probability_of_vertex = stats_for_empty_parents[vertex]            
            for sequence,joint_probability_vertex_and_parents in stats_all.items():
                try:
                    prob_sum = 0;
                    prob_sum_joint = 0;
                    prob_sum_empty = 0;                    
                    for x in stats_parents.keys():
                        prob_sum += stats_parents[x]
                    for x in stats_all.keys():
                        prob_sum_joint+= stats_all[x]
                    for x in stats_for_empty_parents.keys():
                        prob_sum_empty+= stats_for_empty_parents[x]
                    parents_sequence = sequence[:-1] # except the last one
                    probability_of_parents = stats_parents[parents_sequence]
                    mutual_information += float(probability_of_parents) / float(prob_sum) * joint_probability_vertex_and_parents * math.log((float(joint_probability_vertex_and_parents)*prob_sum_empty/(float(probability_of_vertex) * float(probability_of_parents))),2)
                    
                except ZeroDivisionError:
                    pass
            mutual_information /= prob_sum_empty
            #print "number_of_vertices ", number_of_vertices 
            score = 2 * number_of_effective_observations * ( math.log(number_of_vertices,2) - mutual_information)
       
        #print "d_score: ", score*self.data_factor    
        return score*self.data_factor


