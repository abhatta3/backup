#!/usr/bin/env python

print "OK"
