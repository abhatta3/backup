//This code reads data from (key)trylist_table_ban_white.txt and writes data to input of bene-0.9-4. 
//One file for each variables and equal number of entry in ascending order of parents (if convert parent bit string from binary to number).
//If any file include less number of entry (maybe a discrete varible which cannot be a child of continuous variable and deal will not assign any key value)
//then fill the remaining entry with (minimumdata*10) value. 

#include<stdio.h>
#include<string.h>

void main(int argc, char* argv[])
{

FILE *in,*out;
int i,j,jj,count,t,countarr[100],id,max;
char string[500];
double data,mindata=0;

in=fopen(argv[1],"r");


fgets(string,500,in);
//printf("%s\n",string);

fscanf(in,"%d",&count);
//printf("%d\n",count);
fgets(string,500,in);
fgets(string,500,in);
//printf("%s\n",string);
max=0;
for(i=0;i<count;i++)
{
  fscanf(in,"%d",&t);
  countarr[i]=t;
  if(t>max)
   max=t;
  //printf("%d\n",t);
  
}

fgets(string,500,in);
fgets(string,500,in);
//printf("%s\n",string);

for(i=0;i<count;i++)
{
switch( i ) 
 {
    case 0:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/0","wb");
        break;
    case 1 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/1","wb");
        break;
    case 2 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/2","wb");
        break;
    case 3:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/3","wb");
        break;
    case 4 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/4","wb");
        break;
    case 5 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/5","wb");
        break;
    case 6:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/6","wb");
        break;
    case 7 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/7","wb");
        break;
    case 8 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/8","wb");
        break;
    case 9 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/9","wb");
        break;
    case 10:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/10","wb");
        break;
    case 11 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/11","wb");
        break;
    case 12 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/12","wb");
        break;
    case 13:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/13","wb");
        break;
    case 14 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/14","wb");
        break;
    case 15 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/15","wb");
        break;
    case 16:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/16","wb");
        break;
    case 17 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/17","wb");
        break;
    case 18 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/18","wb");
        break;
    case 19 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/19","wb");
        break;
    case 20:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/20","wb");
        break;
    case 21 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/21","wb");
        break;
    case 22 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/22","wb");
        break;
    case 23:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/23","wb");
        break;
    case 24 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/24","wb");
        break;
    case 25 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/25","wb");
        break;
    case 26:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/26","wb");
        break;
    case 27 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/27","wb");
        break;
    case 28 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/28","wb");
        break;
    case 29 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/29","wb");
        break;

  }  
  if(countarr[i]<max)
  {
    for(j=0;j<countarr[i];j++)
    {
      fscanf(in,"%d %s %lf",&id,string,&data);
      fgets(string,500,in);
      fwrite(&data,sizeof(double),1,out);
      if(data<mindata)
        mindata=data;  
      //printf("%lf\n",data);
    }
    jj=max-countarr[i];
    data=mindata*10;
    for(j=0;j<jj;j++)
       fwrite(&data,sizeof(double),1,out);
     
   
  }
  else  
  {
    for(j=0;j<countarr[i];j++)
    {
      fscanf(in,"%d %s %lf",&id,string,&data);
      fgets(string,500,in);
      fwrite(&data,sizeof(double),1,out);
      //printf("%lf\n",data);
    }
  }

 
}

}