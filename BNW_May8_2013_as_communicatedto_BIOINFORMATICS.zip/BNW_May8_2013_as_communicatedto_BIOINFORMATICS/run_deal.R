source("get.newtrylist.R")
nposs = get.newtrylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='zGa',standardize=TRUE)
system("./wl_edit_trylist_table zGabanlist_temp.txt zGawhitelist_temp.txt zGatrylist_table.txt zGatrylist_out.txt")
system("./bn_exhaustive_search zGatrylist_out.txt zGanetworks.txt zGamatrix.txt")
