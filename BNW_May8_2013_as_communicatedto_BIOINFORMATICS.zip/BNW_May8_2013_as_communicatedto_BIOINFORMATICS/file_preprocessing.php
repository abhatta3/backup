<?php

////////////////This code load a data file and creates input file for global optimal search (original C code). "list_new_structure.php" link is for execution of structure learning ///////////////////////////////////

////////////Function that search for data type///////////////////////
function node_type($searchID)
{

  $str_arr=array();
  $str_arr=explode("\n",$searchID);
  $data=array();
  $lc=0;
   
  
  $cont_arr=array();
  $i=0;
  $data_type=array();
  foreach($str_arr as $line)
  {
    if($lc==0)
      {
  
        $data=explode("\t",$line);
	  $j=0;
         foreach($data as $d_c)
	  {
	     $data_type[$j]=0;
             $j++;
         }
          $lcc=$j;
      }        
      else
      { 
         $data=explode("\t",$line);
	  $j=0;
         foreach($data as $d_c) 
         {
            $d_c=trim($d_c); 
	     $cont_arr[$i][$j]=$d_c; 
            $mystring = $d_c;
	     $findme   = '.';
	     $pos = strpos($mystring, $findme);
            if ($pos != false) {
	               $data_type[$j]=1;
	      }
	       
	     $j++;
          }
         $i++;
       }
       $lc++;
     
    }

$lc--;


$data_count=0;
//$count_arr=array();     
$l_type="";

for($j=0;$j<$lcc;$j++)
    {
 
       if($data_type[$j]!=1)
	{
           
	  $data_count=0;
   
	   for($i=0;$i<$lc;$i++)
	   {
            $vi=$i+1; 
	     for($ii=$vi;$ii<$lc;$ii++)
	       {
                 if($cont_arr[$i][$j]==$cont_arr[$ii][$j])
		   {
		     $cont_arr[$ii][$j]=-9999;
               
		   } 
	       }
               
              
            }
	   for($i=0;$i<$lc;$i++)
	   {
	       if($cont_arr[$i][$j]!=-9999 && $cont_arr[$i][$j]!="")
		 $data_count++;
	   }
	   $data_type[$j]=$data_count;
	    
	   
	}
       if($j==0)
         $l_type.=$data_type[$j];
       else
	 $l_type.="\t".$data_type[$j];  
      
    }

return($l_type);


}


include("header_new.inc");
include("header_batchsearch.inc");
$searchID="";
$UploadValue="NO";
$TextFile=$HTTP_POST_FILES["MyFile"]["name"];

/////////////////Generate key/////////////////////////////////////////////////

$alphas=array();
$alphas = array_merge(range('A', 'Z'), range('a', 'z'));

$al1=rand(0,51);
$al2=rand(0,51);
$al3=rand(0,51);

$alpha="$alphas[$al1]"."$alphas[$al2]"."$alphas[$al3]";
$keyval=$alpha;


if($_POST["My_key"]!="")
  $keyval=$_POST["My_key"];

$sid=$keyval."deal_input";

$dir="/var/www/html/compbio/BNW/bene-0.9-4/example/";
$TextinFileFinal=$dir.$sid.".idt";
$TextinFile=$dir.$sid."_temp.txt";
$TextinFilenamelist=$dir.$keyval."name.vd";

if(isset($HTTP_POST_VARS["searchkey"]))
{
   $searchID=$HTTP_POST_VARS["searchkey"];
}

if(isset($HTTP_POST_VARS["MyUpload"]))
{
   $UploadValue=$HTTP_POST_VARS["MyUpload"];
   if ($UploadValue=="YES")
   {
        if($TextFile!="")
        {
            $sta=move_uploaded_file($HTTP_POST_FILES['MyFile']['tmp_name'],$TextinFile);
            if(!$sta)
            {
                 echo "<script type='text/javascript'> window.alert ('Sorry, error uploading $TextFile.')</script>";
                 flush();
                 exit();
            }
            else
            {
                 $searchID=file_get_contents("$TextinFile");
		 //fclose($fh);
		  unlink($TextinFile);

            }

        }

       else
       {
           echo "<script type='text/javascript'> window.alert ('Sorry, please select upload file.')</script>";
       }
   }
}


?>


<?php


if($searchID!="")
{
?>

<!-- Site navigation menu -->
<ul class="navbar2">
  <li><a href="list_new_structure.php?My_key=<?php print($keyval);?>" target='_blank'>Perform Bayesian network modeling</a>
</ul>
<ul class="navbar">
  <li><a href="help.php#file_format" target='_blank'>Data formatting guidelines  <li><a href="help.php" target='_blank'>Help</a>
  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
</ul>
<?php
}
else
{

?>
<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="help.php#file_format" target='_blank'>Data formatting guidelines  <li><a href="help.php" target='_blank'>Help</a>
  <li><a href="http://compbio.uthsc.edu/BNW/home.php">Home</a>
</a>
</ul>
<?php
}
?>

<div id="outernew">
<h2>Upload data file for global optimal structure learning</h2>
<br>
  Note: If continuous data is used, it will be discretized into three levels
<br>
<br>
<FORM name="key_search" enctype="multipart/form-data" ACTION="file_preprocessing.php" METHOD=POST>
<table align="left" cellspacing="3" cellpadding="1" border="0"  width="80%">
<tr>
  
   <td align="left">Content of uploaded data file:<br>
          <textarea name="searchkey" rows="10" cols="100"><?PHP print($searchID)?> </textarea>
  </td>
</tr>
<tr>
    
   
   <td>
       <INPUT style="background-color:#FFFFFF;color:#0000FF" type="file" name="MyFile" size=45 > 
       <INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Upload" onclick="return Upload();">
      <INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
        <INPUT TYPE="hidden" name="MyUpload" value="NO"> 
   </td>
</tr>
<tr>
    <td>
       <INPUT style="color:#0000FF; font-size:14; font-weight:bold" TYPE="submit" value="Example" onclick="return demo3();">&nbsp&nbsp&nbsp
      <INPUT TYPE="hidden" NAME="My_key" value=<?php print($keyval) ?> >
    </td>
</tr>

</table>
</FORM>
</div>
<?php
  $str_arr=array();
  $str_arr=explode("\n",$searchID);
  $data=array();
  $lc=0;
   
  $TextinFileFinaltxt=$dir.$sid.".txt";
  $fptxt=fopen($TextinFileFinaltxt,"w");
  fwrite($fptxt, "$searchID");

  $fph = fopen($TextinFilenamelist,"w");
  $fpmain = fopen($TextinFileFinal,"w");

  $cont_arr=array();
  $i=0;
  
  $line_cell_min=array();
  $line_cell_max=array();

  foreach($str_arr as $line)
  {
    $line=trim($line); 
    if($line!="")
    { 
      if($lc==0)
       {  
 
       $name_list=$line;
       $data=explode("\t",$line);
	$j=0;
          foreach($data as $d_c)
	   {
	     
           $line_cell_min[$j]=999999999;
           $line_cell_max[$j]=-999999999;
 
            $j++;
          }
          $lcc=$j;
       }        
       else
       {
        
        $data=explode("\t",$line);
        
	 $j=0;
          foreach($data as $d_c) 
          {
            $d_c=trim($d_c);
            if($line_cell_min[$j]>$d_c)
                $line_cell_min[$j]=$d_c;
            else if($line_cell_max[$j]<$d_c) 
                $line_cell_max[$j]=$d_c;

            $cont_arr[$i][$j]=$d_c; 
        
             $j++;
           }
	   $i++; 
        }
        $lc++;
    }
 }
$lc--;


/////////////////write data to files/////////////////////////////////////////////


$fpC = fopen("$keyval"."continuous_input.txt","w");
$fptype = fopen("$keyval"."type.txt","w");
$fpnode= fopen("$keyval"."nnode.txt","w");
$fpname= fopen("$keyval"."name.txt","w");

fwrite($fpname,"$name_list\n");

fwrite($fpnode,"$lcc\n");

fwrite($fpC,"$name_list\n");

$ntp=node_type($searchID);
$ntp_arr=array();
$ntp_arr=explode("\t",$ntp);


fwrite($fptype,"$name_list\n");

for($j=0;$j<$lcc;$j++)
{
  $val=trim($ntp_arr[$j]);
 

  if($val==1)
  {
      fprintf($fpC,"3\t");
      fprintf($fptype,"3\t");
  }
  else
  {
    fprintf($fpC,"$val\t");
    fprintf($fptype,"$val\t");

  }
}
fprintf($fpC,"\n");

fwrite($fptype,"\n");



for($i=0;$i<$lc;$i++)
{
   $flag=0;
    for($j=0;$j<$lcc;$j++)
    {
      $vtp=trim($cont_arr[$i][$j]);
      if($vtp!="")
      {
        $flag=1;
        $val=trim($ntp_arr[$j]);
        if($val!=1)
        {
           $v=$vtp-1;
           fprintf($fpmain,"$v\t"); 
           fprintf($fpC,"$vtp\t");
         
        }
        else
        {
           $range1=$line_cell_min[$j]+($line_cell_max[$j]-$line_cell_min[$j])/3;
           $range2=$line_cell_min[$j]+($line_cell_max[$j]-$line_cell_min[$j])*2/3;
                     
           if($cont_arr[$i][$j]>=$line_cell_min[$j] && $cont_arr[$i][$j]<$range1)
           {
                 fprintf($fpmain, "0\t");
                 fprintf($fpC,"1\t");
           
           }
           else if($cont_arr[$i][$j]>=$range1 && $cont_arr[$i][$j]<$range2)
           {
              fprintf($fpmain, "1\t");
              fprintf($fpC,"2\t"); 

           }
           else
           {
              fprintf($fpmain, "2\t");
              fprintf($fpC,"3\t"); 

           } 
  
	  }
        }
    }
    if($flag==1)
    {
      fprintf($fpmain, "\n");    
      fprintf($fpC,"\n"); 
    }  
}

$data=explode("\t",$name_list);
for($j=0;$j<$lcc;$j++)
{         
 $val=trim($ntp_arr[$j]);
 $data[$j]=trim($data[$j]); 
 if($val==1)
 {         
           $range1=$line_cell_min[$j]+($line_cell_max[$j]-$line_cell_min[$j])/3;
           $range2=$line_cell_min[$j]+($line_cell_max[$j]-$line_cell_min[$j])*2/3;
           fprintf($fph,"%s\t[%f .. %f]\t]%f .. %f]\t]%f .. %f]\n",$data[$j],$line_cell_min[$j],$range1,$range1,$range2,$range2,$line_cell_max[$j]);
 }
 else if($val>1)
 {
    
      fprintf($fph,"%s",$data[$j]);
      $m1=$line_cell_min[$j]-1;
      $m2=$line_cell_max[$j]-1;
      for($jj=$m1;$jj<=$m2;$jj++)
      {
          fprintf($fph,"\t%d",$jj);  
      }
      fprintf($fph,"\n");

 }
}
fclose($fpC);


?>