<?php 

$keyval=$_GET["My_key"];

$matfile=$keyval."matrix.txt";

$file=fopen("run_deal.R","w");

$code="source(\"get.newtrylist.R\")\n";
$code.="nposs = get.newtrylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='$keyval',standardize=TRUE)\n";
$code.="system(\"./wl_edit_trylist_table ".$keyval."banlist_temp.txt ".$keyval."whitelist_temp.txt ".$keyval."trylist_table.txt ".$keyval."trylist_out.txt\")\n";
$code.="system(\"./bn_exhaustive_search ".$keyval."trylist_out.txt ".$keyval."networks.txt ".$keyval."matrix.txt\")\n";

fwrite($file,$code);
fclose($file);

shell_exec('R CMD BATCH --no-save run_deal.R');

$nm="/var/www/html/compbio/BNW/".$keyval."name.txt";
$namelist=file_get_contents("$nm");

$fps = fopen($keyval."structure_input.txt","w");
$fpc = fopen($keyval."continuous_input.txt","w");

fwrite($fps,"$namelist");
$matrix1=file_get_contents("$matfile");
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$datamat=array();
$data_cell=array(); 
//$i=0;
foreach($str_arrmat as $datamat)
{
	$data_cell=explode(" ",$datamat);
       foreach($data_cell as $cell)
	{
         $cell=trim($cell);
         if($cell!="")
          {  
             if($cell>=0.5) 
                fprintf($fps,"1\t");
             else
                fprintf($fps,"0\t");
          }
        }
       fprintf($fps,"\n");
       //$i++;
}

$dealinput=$keyval."deal_input.txt";
$cmat=file_get_contents("$dealinput");
fwrite($fpc,"$cmat");

$matfile=$keyval."structure_input.txt";

//$grfilename=$keyval."graphviz.txt";
//$grfilenametemp=$keyval."graphviztemp.txt";
//$fout=fopen("$grfilename","w");
//$fouttemp=fopen("$grfilenametemp","w");

$fout=fopen($keyval."graphviz.txt","w");


$matrix1=file_get_contents("$matfile");           
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$datamat=array();
$data_cell=array(); 

$dataname=array();
$dataname=explode("\t",$str_arrmat[0]);
$n=count($dataname);

$initialstring="digraph G {\n"."size=\"10,10\";  ratio = fill;\n"."node [shape=square,width=1.5];\n";

$endstring="}";

fwrite($fout,"$initialstring");

for($i=1;$i<=$n;$i++)
{
         $ii=$i-1; 
         $row_name=trim($dataname[$ii]);  

 
         $col_arr=explode("\t",$str_arrmat[$i]);
        
        
	   for($j=0;$j<$n;$j++)
	   {
               $col_val=trim($col_arr[$j]);
               if($col_val==1)
               { 
                  $col_name=trim($dataname[$j]);
                  fprintf($fout,"%s -> %s;\n",$row_name,$col_name);  
                  
                 
	        }
          }
          
     
} 
fwrite($fout,"$endstring");   
 
//$figfile=$keyval."graphviz.jpg";
//$cmd="/usr/bin/dot -Tpng -o $figfile $grfilenametemp";
//system($cmd);
//print($figfile);
//shell_exec('/usr/bin/dot -Tpng -o /var/www/html/compbio/BNW/graphviz.jpg /var/www/html/compbio/BNW/graphviztemp.txt');

?>
<script>
window.open("http://compbio.uthsc.edu/BNW/layout.php?My_key=<?php print($keyval);?>",'_self',false);
</script>


