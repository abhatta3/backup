<?php
$pfile="./data/example_chl/"."bWRcontinuous_input.txt";
$data=file_get_contents("$pfile");

?>
<script>
window.open("bn_genenet.php?My_Genenet=<?php print($data);?>",'_self',false);
</script>

