source("get.newtrylist.R")
nposs = get.newtrylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='',standardize=TRUE)


