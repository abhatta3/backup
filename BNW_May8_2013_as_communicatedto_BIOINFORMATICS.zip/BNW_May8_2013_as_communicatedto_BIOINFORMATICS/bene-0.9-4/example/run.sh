#!/bin/bash

d=`dirname $0`

if [ $# -eq 1 ]; then
	ess=$1
else
    ess=1
fi


score=`$d/../src/data2netnew.sh $d/wYXname.vd $d/wYXdeal_input.idt $ess $d/resdir`
echo Score : $score
echo Arcs :
$d/../src/net2parents $d/resdir/net - | $d/../src/parents2arcs - -
