#include<stdio.h>
void main()
{
FILE *fp1,*fp2;
int i,varset,v;
double d;
unsigned int nof_parsets;
unsigned int dd;

//nof_parsets = 1U<<(8-1);
//printf("%d",nof_parsets);

fp1=fopen("0","rb");
fp2=fopen("tab.txt","w");

/*  for(varset=32; varset; --varset){
         for(v=0; v<8; ++v){
	if (varset & (1U<<v)){
	    fprintf(fp2,"%d\n",v);
	}
      }
    }
*/

while(!feof(fp1))
   {
     fread(&d, sizeof(double), 1, fp1);
      // fread(&dd, sizeof(unsigned int), 1, fp1);

      fprintf(fp2,"%lf\n",d);
//fprintf(fp2,"%u\n",dd);

   }




}