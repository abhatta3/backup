#!/bin/bash

rm -f get_local_scores split_local_scores reverse_local_scores \
   get_best_parents get_best_sinks get_best_order get_best_net \
   score_net score_nets net2parents parents2arcs arcs2dot \
   *.exe *.o *~
