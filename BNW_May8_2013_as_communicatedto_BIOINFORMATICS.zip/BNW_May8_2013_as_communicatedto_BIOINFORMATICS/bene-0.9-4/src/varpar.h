#ifndef __VARPAR_H__
#define __VARPAR_H__

#include "cfg.h"

varset_t parset2varset(int v, varset_t set);
varset_t varset2parset(int v, varset_t set);

#endif
