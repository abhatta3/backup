#include<stdio.h>
#include<string.h>
struct d{
int s;
double data;
}pd[1000];

void main()
{

FILE *in,*out;
int i,j,jj,count,t,countarr[100],id,maxs;
char string[500];
double data;

in=fopen("/var/www/html/compbio/BNW/abtrylist_table_ban_white.txt","r");
fgets(string,500,in);
//printf("%s\n",string);

fscanf(in,"%d",&count);
//printf("%d\n",count);
fgets(string,500,in);
fgets(string,500,in);
//printf("%s\n",string);

for(i=0;i<count;i++)
{
  fscanf(in,"%d",&t);
  countarr[i]=t;
  //printf("%d\n",t);
  
}

fgets(string,500,in);
fgets(string,500,in);
//printf("%s\n",string);

for(i=0;i<count;i++)
{
switch( i ) 
 {
    case 0:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/0","wb");
        break;
    case 1 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/1","wb");
        break;
    case 2 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/2","wb");
        break;
    case 3:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/3","wb");
        break;
    case 4 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/4","wb");
        break;
    case 5 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/5","wb");
        break;
    case 6:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/6","wb");
        break;
    case 7 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/7","wb");
        break;
    case 8 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/8","wb");
        break;
    case 9 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/9","wb");
        break;
    case 10:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/10","wb");
        break;
    case 11 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/11","wb");
        break;
    case 12 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/12","wb");
        break;
    case 13:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/13","wb");
        break;
    case 14 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/14","wb");
        break;
    case 15 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/15","wb");
        break;
    case 16:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/16","wb");
        break;
    case 17 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/17","wb");
        break;
    case 18 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/18","wb");
        break;
    case 19 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/19","wb");
        break;
    case 20:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/20","wb");
        break;
    case 21 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/21","wb");
        break;
    case 22 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/22","wb");
        break;
    case 23:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/23","wb");
        break;
    case 24 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/24","wb");
        break;
    case 25 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/25","wb");
        break;
    case 26:
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/26","wb");
        break;
    case 27 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/27","wb");
        break;
    case 28 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/28","wb");
        break;
    case 29 :
        out=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/resdir/29","wb");
        break;


  }  
  maxs=0;
  if(countarr[i]<countarr[i+1])
  {
     for(j=0;j<countarr[i];j++)
     {
  	       fscanf(in,"%d %s %lf",&id,string,&data);
  	       fgets(string,500,in);
     }
  	  for(j=0;j<countarr[i+1];j++)
      { 
        
        data=-9999.0;
		fwrite(&data,sizeof(double),1,out);
        
      }

  }
  else
  {
  for(j=0;j<countarr[i];j++)
  {
    fscanf(in,"%d %s %lf",&id,string,&data);
    pd[j].data=data;
    pd[j].s=strlen(string);
    if(pd[j].s>maxs)
      maxs=pd[j].s;

    fgets(string,500,in);
    //fwrite(&data,1,sizeof(double),out);
   // printf("%lf\n",data);
  }
  
  for(jj=1;jj<=maxs;jj++)
  {
      for(j=0;j<countarr[i];j++)
      { 
          if(jj==pd[j].s)
          {
              fwrite(&pd[j].data,sizeof(double),1,out);
             // printf("%d\t%lf\n",pd[j].s,pd[j].data);
          }  
      }
 
   }
  }
}

}
