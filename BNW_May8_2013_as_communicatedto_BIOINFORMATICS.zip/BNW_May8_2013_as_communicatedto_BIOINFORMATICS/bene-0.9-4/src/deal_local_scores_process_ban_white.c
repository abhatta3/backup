#include<stdio.h>
#include<string.h>

struct b{
int t; 
char f;
}ban[1000],white[1000];

void main(int argc, char* argv[])
{
FILE *in,*inwhite,*inban,*out,*ftemp;
int i,j,jj,jjj,jjjj,jc,wc,count,flag,countban,countwhite,t,countarr[100],id,maxs;
char string[500],wstring[100];
double data;


ftemp=fopen("/var/www/html/compbio/BNW/otputdilename.txt","w");
fprintf(ftemp,"%s\n%s\n%s\n%s\n",argv[1],argv[2],argv[3],argv[4]);


in=fopen(argv[1],"r");

inban=fopen(argv[2],"r");

inwhite=fopen(argv[3],"r");

out=fopen(argv[4],"w");

fscanf(inban,"%d",&countban);
fgets(string,500,inban);
fgets(string,500,inban);
for(i=0;i<countban;i++)
{
 fscanf(inban,"%d %s",&ban[i].t,&ban[i].f);
 fgets(string,500,inban);
}

fscanf(inwhite,"%d",&countwhite);
fgets(string,500,inwhite);
fgets(string,500,inwhite);
for(i=0;i<countwhite;i++)
{
  fscanf(inwhite,"%d %c",&white[i].t,&white[i].f);
  fgets(string,500,inwhite);
}

fgets(string,500,in);
fputs(string,out);

fscanf(in,"%d",&count);
fprintf(out,"%d",count);

fgets(string,500,in);
fputs(string,out);
fgets(string,500,in);
fputs(string,out);

for(i=0;i<count;i++)
{
  fscanf(in,"%d",&t);
  countarr[i]=t;
  fprintf(out,"%d\t",t);
}

fgets(string,500,in);
fputs(string,out);
fgets(string,500,in);
fputs(string,out);

for(i=0;i<count;i++)
{
  for(j=0;j<countarr[i];j++)
  {
    fscanf(in,"%d %s %lf",&id,string,&data);
    flag=0;
    for(jj=0;jj<countban && flag==0;jj++)
    {
      if(id==ban[jj].t)
	  {
	     t=strlen(string);
	     
		 for(jjj=0;jjj<t;jjj++)
		 {
		   if(ban[jj].f==string[jjj])
		    {
			   flag=1;
			   break;
		    }
		 }
	  }
    }
    if(flag!=0)
      data=-1000.0;
    else
    {  
      flag=0;
      wc=0;
      //white list
      for(jj=0;jj<countwhite;jj++)
      {
          
          if(id==white[jj].t)
	   {
            flag=2;
	     wstring[wc]=white[jj].f;
            wc++;
          }
       }   
       jc=0;
	for(jjj=0;jjj<t && flag!=3;jjj++)
	{
           	for(jjjj=0;jjjj<wc;jjjj++)
          	{

		   if(wstring[jjjj]==string[jjj])
		    {
                        jc++;
                        if(jc==wc)
			       flag=3;
                        
			   break;
		    }
             }
	}
	   
      
       if(flag==2)
         data=-1000.0;
     }
      
    fprintf(out,"%d\t%s\t%lf\n",id,string,data);
   
    fgets(string,500,in);
  }
}
}
