#ifndef __REG_H__
#define __REG_H__
#include "cfg.h"

extern score_t reg(int N, int K);

#endif
