#ifndef _LS_LOO_H_
#define _LS_LOO_H_

#include "cfg.h"
#include "get_local_scores.h"

extern scorefun init_LOO_scorer();
extern void free_LOO_scorer();

#endif
