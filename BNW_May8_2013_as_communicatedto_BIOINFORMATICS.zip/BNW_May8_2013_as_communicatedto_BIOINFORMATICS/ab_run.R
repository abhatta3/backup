source("get.trylist.R")
nposs = get.trylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='ab',standardize=TRUE)
system("./wl_edit_trylist_table abbanlist_temp.txt abwhitelist_temp.txt abtrylist_table.txt abtrylist_out.txt")
system("./bn_exhaustive_search abtrylist_out.txt abnetworks.txt abmatrix.txt")
