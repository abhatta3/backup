<?php 
unlink("abmatrix.txt");
unlink("abname.txt");
unlink("structure_input.txt");
unlink("continuous_input.txt");

unlink("net_figure.txt");
unlink("net_figure_new.txt");
unlink("standardized_data.txt");

unlink("structure_input_new.txt");
unlink("structure_old.txt");
unlink("nnode.txt");
unlink("type.txt");
unlink("var.txt");
unlink("varname.txt");
unlink("vardata.txt");

unlink("map.txt");
unlink("mapdata.txt");


$key=$_POST["My_key"];
if($key=="")
  $key="ab";//uniqid("");

include("header_new.inc");

//file_preprocessingnew.php
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="help.php#learn_methods">Structure learning method descriptions</a>
  <li><a href="help.php">Help</a>
  <li><a href="home.php">Home</a>

</ul>

<div id="outer">
<!-- Main content -->
<h2>Select a structure learning method</h2>
<br>
<vr>
<FORM METHOD="LINK" ACTION="bn_file_load.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Exhaustive search with model averaging" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
<br>
<FORM METHOD="LINK" ACTION="bn_file_load_gom.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Global optimal search for all data types" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
<br>
<FORM METHOD="LINK" ACTION="file_preprocessing.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Global optimal search for discrete data" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
</div>
</body>
</html>


