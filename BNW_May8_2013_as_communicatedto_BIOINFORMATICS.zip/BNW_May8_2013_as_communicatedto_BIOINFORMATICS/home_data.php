<?php 
unlink("abmatrix.txt");
unlink("abname.txt");
unlink("structure_input.txt");
unlink("continuous_input.txt");

unlink("net_figure.txt");
unlink("net_figure_new.txt");
unlink("standardized_data.txt");

unlink("structure_input_new.txt");
unlink("structure_old.txt");
unlink("nnode.txt");
unlink("type.txt");
unlink("var.txt");
unlink("varname.txt");
unlink("vardata.txt");

unlink("map.txt");
unlink("mapdata.txt");

$key=$_POST["My_key"];
if($key=="")
  $key="ab";//uniqid("");

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="home.php">Home</a>
  <li><a href="home_data.php">Data</a>
  <li><a href="home_structure.php">Structure Learning</a>
  <li><a href="home_upload.php">Upload structure</a>  
  <li><a href="workflow.php">Work flow diagrams</a>
  <li><a href="help.php">Help</a>



</ul>

<div id="outer">
<!-- Main content -->
<br>
<br>
<h1>Formatting files for use with BNW</h1>
<br>
<h2>Data file format</h2>
  <p align="justify"> Data files uploaded to the Bayesian Network Webserver should be tab-delimited text files with the names of the variables in the first row of the file and the values of the variables for each sample or individual in the remaining rows. <br><br>BNW automatically determines whether variables contain continuous or discrete data. To help ensure that BNW correctly parses data files, they should follow these formatting guidelines:<br>
  1. Variable names should start with a letter, not a number.<br>
  2. Discrete variables should be listed before continuous variables, that is, discrete variables should be the leftmost columns of the file.<br>
3. The values of the levels of discrete variables should be integers starting with 1.<br>
  4. The data values for each continuous variables should include a period (.) in at least one of the samples.<br><br>
    An example input data file for a file with 5 variables is given below. The network contains 2 discrete (Disc1 and Disc2) variables, which are given in the first two columns of the file, and 3 continuous variables (Cont1, Cont2, and Cont3). Disc1 is a discrete variable with two states (1 and 2), while Disc2 has three states (1, 2, and 3). Although the samples of Cont2 are integral values, we wish to deal with this variable as continuous, not discrete. Therefore, the value of Cont2 for the first sample is given as '3.0' instead of '3' so that one of the values of Cont2 contains a '.' and Cont2 is detected as a continuous variable.
</p>
<br>
<table>
<tr><th>Disc1</th><th>&nbsp;</th><th>Disc2</th><th>&nbsp;</th><th>Cont1</th><th>&nbsp;</th><th>Cont2</th><th>&nbsp;</th><th>Cont3</td></tr>
<tr>
<td>2</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>3.25</td><td>&nbsp;</td><td>3.0</td><td>&nbsp;</td><td>0.97</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>3</td><td>&nbsp;</td><td>2.46</td><td>&nbsp;</td><td>2</td><td>&nbsp;</td><td>0.93</td>
</tr>
<tr>
<td>1</td><td>&nbsp;</td><td>2</td><td>&nbsp;</td><td>4.21</td><td>&nbsp;</td><td>33</td><td>&nbsp;</td><td>0.43</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>3</td><td>&nbsp;</td><td>3.76</td><td>&nbsp;</td><td>8</td><td>&nbsp;</td><td>0.88</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>3.69</td><td>&nbsp;</td><td>4</td><td>&nbsp;</td><td>0.91</td>
</tr>
<tr>
<td>1</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>4.27</td><td>&nbsp;</td><td>13</td><td>&nbsp;</td><td>0.38</td>
</tr>
</table>
<br>
<br>
<h2>Structure file format</h2>
<p align="justify">
  If the structure of the network model for a dataset is already known, users can upload this structure by selecting "Upload structure" on the BNW home page. The structure file should be tab-delimited, with the variable names on the first row. The remainder of the file should be an n x n matrix of 0's and 1's, where n is the number of variables in the network. A '1' in row i and column j in this matrix indicates that there is a directed edge connecting variables i and j, (i.e., there is a edge from i to j in the network). '0' indicate that there is not a directed edge from variable i to variable j.
<br><br> An example of a structure data file is shown below. The following edges would be included in the network:
<br>1. Disc1 -> Cont1
<br>2. Dics2 -> Cont2
<br>3. Cont1 -> Cont3
<br>4. Cont2 -> Cont3 
</p>
<br>
<table>
<tr><th>Disc1</th><th>&nbsp;</th><th>Disc2</th><th>&nbsp;</th><th>Cont1</th><th>&nbsp;</th><th>Cont2</th><th>&nbsp;</th><th>Cont3</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>0</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td></tr>
</table>
<br>
</div>
</body>
</html>