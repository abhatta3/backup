get.newtrylist <- function(use.banlist=FALSE,use.whitelist=FALSE,job.id="",standardize=TRUE) {
  ## Function to get parent-child scores to use with structure learning codes
  ## INPUT:
  ## data: a data.frame with the the type of node and data
  ## use.banlist: Use a user-specified banlist (arcs that are excluded
  ##      from the search)
  ##    Banlist should be a matrix with two columns of node names.
  ##    The first column is "From" and the second column is "To"
  ##    Reads from a file called banlist.txt.
  ## use.whitelist: Use a user-specified whitelist (arcs that must be
  ##      included in the network)
  ##    Whitelist should be a matrix with two columns of node names.
  ##    The first column is "From" and the second column is "To".
  ##    Reads from a file called whitelist.txt.
  ## standardize: Flag for to standardize input (TRUE) or leave data
  ##   as is (FALSE)

  library(deal)
#read in input file
  data.fname.temp <- "deal_input.txt"
  data.fname <- paste(job.id,data.fname.temp,sep="")
  
  data.input <- as.data.frame(read.table(file=data.fname,header=TRUE,sep="\t"))
  nnodes = dim(data.input)[2]
  ndata <- dim(data.input)[1] - 1
  data.head <- colnames(data.input)
  node.type <- as.vector(data.input[1,])
  data <- data.input[2:(ndata+1),]
  #if (nnodes > 9) {
  #  cat("You have too many nodes to use this code \n")
  #  stop()
  #}

  banlist.fname.temp <- "banlist.txt"
  banlist.fname <- paste(job.id,banlist.fname.temp,sep="")

  banlist.temp.fname1 <- "banlist_temp.txt"
  banlist.temp.fname <- paste(job.id,banlist.temp.fname1,sep="")

  
  if(use.banlist) {
    banlist <- as.matrix(read.table(file=banlist.fname,sep="\t"))
    if(dim(banlist)[1] == 1) {
      write("0",file=banlist.temp.fname)      
      write("To From",file=banlist.temp.fname,ncolumns=1,append=TRUE)
    } else {
      banlist <- banlist[-1,]
      if(class(banlist) == "character") banlist <- t(banlist)


lettersbw <- c("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z")
      
# rewrite banlist with node numbers instead of names
      for (i in 1:dim(banlist)[1]) {
        pos1 <- match(banlist[i,1],data.head)
        pos2 <- match(banlist[i,2],data.head)
        if(is.na(pos1)) {
          cat("Names of nodes in banlist are incorrect\n")
          cat("pos1",pos1,"\n")
          stop()
        }
        if(is.na(pos2)) {
          cat("Names of nodes in banlist are incorrect\n")
          cat("pos2",pos2,"\n")
          stop()
        }
       if(pos1>9)
       { 
          banlist[i,1] <- lettersbw[pos1]
       }
       else
       {
         banlist[i,1] <- pos1 
       } 
       
       if(pos1>9)
       { 
        banlist[i,2] <- lettersbw[pos2]
       }
       else
       {
        banlist[i,2] <- pos2
       }
      }
      banlist.temp <- banlist
      banlist.temp[,1] <- banlist[,2]
      banlist.temp[,2] <- banlist[,1]


      
      write(dim(banlist)[1],file=banlist.temp.fname,ncolumns=1)
      write("To From",file=banlist.temp.fname,ncolumns=1,append=TRUE)
      write.table(banlist.temp,file=banlist.temp.fname,quote=FALSE,sep="\t",na="NA",row.names=FALSE,col.names=FALSE,append=TRUE)  
    }
  } else {
    write("0",file=banlist.temp.fname)
  }


  whitelist.fname.temp <- "whitelist.txt"
  whitelist.fname <- paste(job.id,whitelist.fname.temp,sep="")

  whitelist.temp.fname1 <- "whitelist_temp.txt"
  whitelist.temp.fname <- paste(job.id,whitelist.temp.fname1,sep="")
  
  if(use.whitelist) {
    whitelist <- as.matrix(read.table(file=whitelist.fname,sep="\t"))
    if(dim(whitelist)[1] == 1) {
      write("0",file=whitelist.temp.fname)      
      write("To From",file=whitelist.temp.fname,ncolumns=1,append=TRUE)
    } else {
      whitelist <- whitelist[-1,]
      if(class(whitelist) == "character") whitelist <- t(whitelist)
      
# rewrite whitelist with node numbers instead of names
      for (i in 1:dim(whitelist)[1]) {
        pos1 <- match(whitelist[i,1],data.head)
        pos2 <- match(whitelist[i,2],data.head)
        if(is.na(pos1)) {
          cat("Names of nodes in whitelist are incorrect\n")
          cat("pos1",pos1,"\n")
          stop()
        }
        if(is.na(pos2)) {
          cat("Names of nodes in whitelist are incorrect\n")
          cat("pos2",pos2,"\n")
          stop()
        }
       if(pos1>9)
       { 
          whitelist[i,1] <- lettersbw[pos1]
       }
       else
       {
         whitelist[i,1] <- pos1 
       } 
       
       if(pos1>9)
       { 
        whitelist[i,2] <- lettersbw[pos2]
       }
       else
       {
        whitelist[i,2] <- pos2
       }

      }
      whitelist.temp <- whitelist
      whitelist.temp[,1] <- whitelist[,2]
      whitelist.temp[,2] <- whitelist[,1]
      
      write(dim(whitelist)[1],file=whitelist.temp.fname,ncolumns=1)
      write("To From",file=whitelist.temp.fname,ncolumns=1,append=TRUE)
      write.table(whitelist.temp,file=whitelist.temp.fname,quote=FALSE,sep="\t",na="NA",row.names=FALSE,col.names=FALSE,append=TRUE)  
    }
  } else {
    write("0",file=whitelist.temp.fname)
  }
  

  
  
# make sure that data types are either factor or numberic
# use the same rule that I used for matlab
#   Continuous nodes will have value of 1
#   Discrete nodes will have a different value
  for (i in 1:nnodes) {
    if (node.type[i] == 1) {
      data[,i] <- as.numeric(data[,i])
    } else {
      data[,i] <- as.factor(data[,i])
    }
  }

## standardize continuous nodes to have mean=zero and std=1 if desired
  if (standardize) {
    orig.data <- data
    for (i in 1:nnodes) {
      if (node.type[i] == 1) {
        mu <- mean(orig.data[,i])
        sigma <- sd(orig.data[,i])
        data[,i] <- orig.data[,i] - mu
        data[,i] <- data[,i]/sigma
      }
    }
  }
      
# rename nodes of data
  orig.nodes <- colnames(data)
  if (nnodes < 10) {
    colnames(data) <- c(1:nnodes)
  } else {
    colnames(data)[1:9] <- c(1:9)
    letters <- c("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z")
    colnames(data)[10:nnodes] <- letters[1:(nnodes-9)]
  }

# check to see if there are any discrete_nodes
# If there are no discrete nodes, you have to set the equivalent sample size
# when using deal
  all.cont <- TRUE
  for (i in 1:nnodes) {
    if(node.type[i] != 1) all.cont <- FALSE
  }

# Count the number of continuous and discrete_nodes
  ndisc = 0
  ncont = 0
  for (i in 1:nnodes) {
    if(node.type[i] != 1) {
      ndisc <- ndisc + 1
    } else {
      ncont <- ncont + 1
    }
  }

# prepare a couple of vectors and matrices
  n.poss.par <- vector(mode = "integer",length=nnodes)
  tot.poss.par <- 0
  par.count <- 0
  for (i in 1:nnodes) {
    if(node.type[i] != 1) {
      n.poss.par[i] <- 2^(ndisc-1)
      tot.poss.par <- tot.poss.par + 2^(ndisc-1)
    } else {
      n.poss.par[i] <- 2^(nnodes-1)
      tot.poss.par <- tot.poss.par + 2^(nnodes-1)
    }
  }


  trylist.fname.temp <- "trylist_table.txt"
  trylist.fname <- paste(job.id,trylist.fname.temp,sep="")
  
  write("Number of nodes",file=trylist.fname,ncolumns=1)
  write(nnodes,file=trylist.fname,ncolumns=1,append=TRUE)
  write("Possible sets of parents per node",file=trylist.fname,ncolumns=1,append=TRUE)
  write(n.poss.par,file=trylist.fname,ncolumns=nnodes,append=TRUE,sep="\t")

  
# so you need an array with dimensions tot.poss.par by nnodes
  trylist <- matrix(nrow=tot.poss.par,ncol=3)
  
# cycle through nodes to get the trylist
  for (i in 1:nnodes) {
# First get temporary banlist
# This is just for getting the parent sets for each node
#   one at a time and in the correct order
    temp.banlist <- matrix(nrow=(nnodes-1)*(nnodes-1),ncol=2)
    itemp.bl <- 0
    for (j in 1:nnodes) {
      if (j != i) {
        itemp.bl <- itemp.bl + 1
        temp.banlist[itemp.bl,1] <- i
        temp.banlist[itemp.bl,2] <- j
      }
    }
    for (j in 1:nnodes) {
      if (j != i) {
        for (k in 1:nnodes) {
          if (k != j) {
            if (k != i) {
              itemp.bl <- itemp.bl + 1
              temp.banlist[itemp.bl,1] <- j
              temp.banlist[itemp.bl,2] <- k
            }
          }
        }
      }
    }

# learn the model structure
    data.nw <- network(data)
    banlist(data.nw) <- temp.banlist
    if (all.cont) {
      data.prior <- jointprior(data.nw,N=2)
    } else {
      data.prior <- jointprior(data.nw)
    }
    data.tr <- maketrylist(data.nw,data,data.prior,timetrace=TRUE)

    for (j in 1:n.poss.par[i]) {
      par.count <- par.count + 1
      trylist[par.count,1] <- i
      trylist[par.count,2] <- gsub(":","",data.tr[[i]][j,1])
      trylist[par.count,3] <- data.tr[[i]][j,2]
      if (j==1) trylist[par.count,2] <- as.integer(0)
    }
  }


  colnames(trylist) <- c("Child","Parents","Score")

  write.table(trylist,file=trylist.fname,quote=FALSE,sep="\t",na="NA",row.names=FALSE,col.names=TRUE,append=TRUE)
  
  return(tot.poss.par)
  
}
