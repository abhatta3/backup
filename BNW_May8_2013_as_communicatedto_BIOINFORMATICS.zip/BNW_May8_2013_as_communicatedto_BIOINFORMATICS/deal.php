<?php

$file=fopen("run_deal.R","w");

$code="source(\"get.newtrylist.R\")\n";
$code.="nposs = get.newtrylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='ab',standardize=TRUE)\n";
//$code.="system(\"./wl_edit_trylist_table abbanlist_temp.txt abwhitelist_temp.txt abtrylist_table.txt abtrylist_out.txt\")\n";
fwrite($file,$code);
shell_exec('R CMD BATCH --no-save run_deal.R');
/*
$score=file_get_contents("abtrylist_table.txt");

$ban=file_get_contents("abbanlist_table.txt");
$white=file_get_contents("abwhitelist_table.txt");


$str_score=array();
$str_score=explode("\n",$score);
$dat_score=array();
$dat_score=explode("\t",$str_score[0]);

$str_ban=array();
$str_ban=explode("\n",$ban);
$dat_ban=array();
$dat_ban=explode("\t",$str_ban[0]);

$str_white=array();
$str_white=explode("\n",$white);
$dat_white=array();
$dat_white=explode("\t",$str_white[0]);

*/




?>

