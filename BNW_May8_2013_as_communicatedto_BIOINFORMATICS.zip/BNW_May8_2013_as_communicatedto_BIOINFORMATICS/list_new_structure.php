<?php 
////////////////////////////////This code execute global optimal search and display graphviz figure/////////////////////////////////////////////////

include("header_new.inc");

$keyval=$_GET["My_key"];

$file=fopen("/var/www/html/compbio/BNW/bene-0.9-4/example/run.sh","w");
$code=file_get_contents("bnruntemp1");
$code.="score=`\$d/../src/data2net.sh \$d/$keyval"."name.vd \$d/$keyval"."deal_input.idt \$ess \$d/resdir`\n";
$code.="echo Score : \$score\necho Arcs :\n\$d/../src/net2parents \$d/resdir/net - | \$d/../src/parents2arcs - -\n";
fwrite($file,$code);
fclose($file);
$data=shell_exec('/var/www/html/compbio/BNW/bene-0.9-4/example/run.sh');


$str_arrmat=array();
$str_arrmat=explode("\n",$data);
$datamat=array();
$data_cell=array(); 

$fps = fopen($keyval."structure_input.txt","w");
$ft=$keyval."name.txt";
$matrix1=file_get_contents("$ft");

$arrmat=array();
$arrmat=explode("\n",$matrix1);
$name_cell=array();
$name_cell=explode("\t",$arrmat[0]);
$ft=$keyval."nnode.txt";
$n=file_get_contents("$ft");
$n=trim($n);

for($i=0;$i<$n;$i++)
{
 $ii=$i+1;
 $val=$name_cell[$i];
 if($ii==$n)
   fprintf($fps,"$val\n");
 else
   fprintf($fps,"$val\t");
}

for($i=0;$i<$n;$i++)
{

  for($j=0;$j<$n;$j++)
  {
    $flag=0;    
/////////////////
     foreach($str_arrmat as $datamat)
     {
	$data_cell=explode(" ",$datamat);
       $val1=trim($data_cell[0]);
       $val2=trim($data_cell[1]);
        

        if($val1==$i && $val2==$j && $i!=$j && $val1!="" && $val2!="")
	 {
          $flag=1;
 
        }
    
     }
  $jj=$j+1;
  if($jj==$n)
     fprintf($fps,"$flag\n");  
  else
      fprintf($fps,"$flag\t");
////////////////////

  } 
}


$initiallines=file_get_contents("temp_shell_file_initial_structure");
$all_lines="$initiallines"."$keyval\nfi\nexit";

$fp=fopen("run_initialstructure.sh","w");
fwrite($fp,"$all_lines");
fclose($fp);

shell_exec('/var/www/html/compbio/BNW/run_initialstructure.sh /usr/local/MATLAB/R2012a/');



/////////////////////////////////structure matrix//////////////////////////////////////////////////////////


$matfile="$keyval"."structure_input.txt";


$fout=fopen($keyval."graphviz.txt","w");

//$fouttemp=fopen("/var/www/html/compbio/BNW/graphviztemp.txt","w");
//$grfilename=$keyval."graphviz.txt";
//$grfilenametemp=$keyval."graphviztemp.txt";
//$fout=fopen("$grfilename","w");
//$fouttemp=fopen("$grfilenametemp","w");


$matrix1=file_get_contents("$matfile");           
$str_arrmat=array();
$str_arrmat=explode("\n",$matrix1);
$datamat=array();
$data_cell=array(); 

$dataname=array();
$dataname=explode("\t",$str_arrmat[0]);
$n=count($dataname);

$initialstring="digraph G {\n"."size=\"10,10\";  ratio = fill;\n"."node [shape=square,width=1.5];\n";
//$initialstring_temp="digraph G {\n"."size=\"6,6\";  ratio = fill;\n";


$endstring="}";

fwrite($fout,"$initialstring");
//fwrite($fouttemp,"$initialstring_temp");

for($i=1;$i<=$n;$i++)
{
         $ii=$i-1; 
         $row_name=trim($dataname[$ii]);  

 
         $col_arr=explode("\t",$str_arrmat[$i]);
        
        
	   for($j=0;$j<$n;$j++)
	   {
               $col_val=trim($col_arr[$j]);
               if($col_val==1)
               { 
                  $col_name=trim($dataname[$j]);
                  fprintf($fout,"%s -> %s;\n",$row_name,$col_name);  
                  //fprintf($fouttemp,"%s -> %s;\n",$row_name,$col_name);
                 
	        }
          }
          
     
} 
fwrite($fout,"$endstring");   
//fwrite($fouttemp,"$endstring");

//$figfile=$keyval."graphviz.jpg";
//$cmd="/usr/bin/dot -Tpng -o $figfile $grfilenametemp";
//system($cmd);
//print($figfile);
//shell_exec('/usr/bin/dot -Tpng -o /var/www/html/compbio/BNW/graphviz.jpg /var/www/html/compbio/BNW/graphviztemp.txt');

?>
<script>
window.open("http://compbio.uthsc.edu/BNW/layout.php?My_key=<?php print($keyval);?>",'_self',false);
</script>




