#!/bin/bash

D=g++

$D -o get_kbest_parents get_kbest_parents.cc 
$D -o get_kbest_nets get_kbest_nets.cc 

