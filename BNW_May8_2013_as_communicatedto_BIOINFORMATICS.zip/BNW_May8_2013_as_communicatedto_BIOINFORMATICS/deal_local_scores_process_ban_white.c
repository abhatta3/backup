#include<stdio.h>
#include<string.h>

struct b{
int t; 
char f;
}ban[1000],white[1000];


double determineminimumscore(char *filename)
{
FILE *in;
int count,countarr[100],i,j,t,id;
char string[1000];
double data,minscore=0;

in=fopen(filename,"r");

fgets(string,500,in);

fscanf(in,"%d",&count);
fgets(string,500,in);
fgets(string,500,in);


for(i=0;i<count;i++)
{
  fscanf(in,"%d",&t);
  countarr[i]=t;
}

fgets(string,500,in);
fgets(string,500,in);

for(i=0;i<count;i++)
{
  for(j=0;j<countarr[i];j++)
  {
    fscanf(in,"%d %s %lf",&id,string,&data);
    if(data<minscore)
       minscore=data;
    fgets(string,500,in);

   }
}

minscore=minscore*10;

fclose(in);
return minscore; 
}

void main(int argc, char* argv[])
{
FILE *in,*inwhite,*inban,*out;
int i,j,jj,jjj,jjjj,jc,wc,count,flag,countban,countwhite,t,countarr[100],id,maxs;
char string[500],wstring[100];
double data,minimumscore;

minimumscore=determineminimumscore(argv[1]);



in=fopen(argv[1],"r");

inban=fopen(argv[2],"r");

inwhite=fopen(argv[3],"r");

out=fopen(argv[4],"w");

fscanf(inban,"%d",&countban);
fgets(string,500,inban);
fgets(string,500,inban);
for(i=0;i<countban;i++)
{
 fscanf(inban,"%d %s",&ban[i].t,&ban[i].f);
 fgets(string,500,inban);
}

fscanf(inwhite,"%d",&countwhite);
fgets(string,500,inwhite);
fgets(string,500,inwhite);
for(i=0;i<countwhite;i++)
{
  fscanf(inwhite,"%d %c",&white[i].t,&white[i].f);
  fgets(string,500,inwhite);
}

fgets(string,500,in);
fputs(string,out);

fscanf(in,"%d",&count);
fprintf(out,"%d",count);

fgets(string,500,in);
fputs(string,out);
fgets(string,500,in);
fputs(string,out);

for(i=0;i<count;i++)
{
  fscanf(in,"%d",&t);
  countarr[i]=t;
  fprintf(out,"%d\t",t);
}

fgets(string,500,in);
fputs(string,out);
fgets(string,500,in);
fputs(string,out);

for(i=0;i<count;i++)
{
  for(j=0;j<countarr[i];j++)
  {
    fscanf(in,"%d %s %lf",&id,string,&data);
    flag=0;
    for(jj=0;jj<countban && flag==0;jj++)
    {
      if(id==ban[jj].t)  //child in banlist
	  {
	     t=strlen(string);
	     
		 for(jjj=0;jjj<t;jjj++)
		 {
		   if(ban[jj].f==string[jjj]) //parent in banlist
		    {
			   flag=1;
			   break;
		    }
		 }
	  }
    }
    if(flag!=0)  //child and parent in banlist
      data=minimumscore;
    else
    {  
      flag=0;
      wc=0;

      for(jj=0;jj<countwhite;jj++)  
      {
          
          if(id==white[jj].t) //child in whitelist. list all parents in a string array
	   {
            flag=2;
	     wstring[wc]=white[jj].f;
            wc++;
          }
       }   
       jc=0;
	for(jjj=0;jjj<t && flag!=3;jjj++)
	{
           	for(jjjj=0;jjjj<wc;jjjj++)
          	{

		   if(wstring[jjjj]==string[jjj])    
		    {
                        jc++;
                        if(jc==wc)         //all the parent in the string array are also in parent set
			       flag=3;
                        
			   break;
		    }
             }
	}
	   
      
       if(flag==2)           //ban all enties where parent list excludes atlist one parent from parent array
         data=minimumscore;
     }
      
    fprintf(out,"%d\t%s\t%lf\n",id,string,data);
   
    fgets(string,500,in);
  }
}
}
