<?php 

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="home_structure.php">Learn a network model from data</a>
  <li><a href="home_upload.php">Make predictions using a known structure</a>  
  <li><a href="workflow.php">Example workflows</a>
  <li><a href="help.php">Help</a>
  <li><a href="home.php">Home</a>


</ul>


<!-- Main content -->
<div id="outer">
<h1>Getting Started with BNW</h1>
<br>
    <p align="justify"> New users of BNW can learn network models for example data sets for each of the <a href="home_structure.php">structure learning methods</a> or view <a href="workflow.php">workflow diagrams</a>.
<br>
<br>
    They can also use example network models to make predictions for a <a href="http://compbio.uthsc.edu/BNW/layout.php?My_key=abcd" target="_blank">5 node hybrid network</a> learned using an exhaustive search followed by model averaging, a <a href="http://compbio.uthsc.edu/BNW/layout.php?My_key=wxyz" target="_blank">6 node hybrid network</a> learned by identifying the global optimal structure with no restrictions, and a <a href="http://compbio.uthsc.edu/BNW/layout.php?My_key=lmno" target="_blank">16 node discrete network</a>.
<br>
<br>
    To begin modeling your own data, please read this <a href="help.php#file_format">overview of input file formatting</a> and then upload the data file after selecting a <a href="help.php#learn_methods">structure learning method</a>.
<br>
<br>
    If you already know the structure of your network, you can upload file containing your data and the network structure <a href="home_upload.php">here</a>.
</p>
<br>
</div>
</body>
</html>