cut  -f1-4 /home/abhatta3/src/data_large_1.txt >/var/www/html/compbio/BNW/deal_input.txt
start_time=`date +%s`
R CMD BATCH --no-save run_deal_test.R
end_time=`date +%s`
echo execution time was `expr $end_time - $start_time` s.