<?php
/////////Clear temp files. We will use shell script to do this. This is just a quick temporary code///////////////
array_map('unlink', glob("/var/www/html/compbio/BNW/*.txt"));
array_map('unlink', glob("/var/www/html/compbio/BNW/bene-0.9-4/example/*.vd"));
array_map('unlink', glob("/var/www/html/compbio/BNW/bene-0.9-4/example/*.idt"));
array_map('unlink', glob("/var/www/html/compbio/BNW/bene-0.9-4/example/*.txt"));

print("Successfully clear all temp file from BNW");
?>
