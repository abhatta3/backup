<?php

$key=$_POST["My_key"];
if($key=="")
  $key="ab";//uniqid("");

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="home_structure.php">Learn a network model from data</a>
  <li><a href="home_upload.php">Make predictions using a known structure</a>  
  <li><a href="workflow.php">Example workflows</a>
  <li><a href="help.php">Help</a>
  <li><a href="home.php">Home</a>
</ul>


<!-- Main content -->
<div id="outer">

<table width=100% align=center>
<tr>
<td>
<h2>Table of Contents</h2>
<ol>
<li><a href="#learn_methods">Description of structure learning methods</a>
<li><a href="#constraint_interface">Structural constraint interface</a>
<li><a href="#file_format">Formatting files for BNW</a>
<li><a href="#browser_use">Which browser should I use when accessing BNW?</a>
<!-- <li><a href="#updates">Recent updates and upcoming BNW features</a> -->

</ol>
</td>
</tr>
</table>


<br>
<table>
<tr>
<a name=learn_methods><h2>1. Structure Learning Methods in BNW</h2></a>
</tr>
<br>
<tr><td>
<p align="justify"> The first step in Bayesian network modeling of a dataset is often identifying the network structure that best explains the data. BNW offers several options for structure learning of discrete, continuous, and hybrid (i.e., datasets containing both hybrid and continuous variables) datasets and includes options for the inclusion of structural constraints to limit structure learning searches to biologically or physically meaningful networks.   
<br>
<br>
</td></tr>
<tr><td>
<h3> Exhaustive search with model averaging</h3>
  <p align="justify"> To learn the structure of small networks, BNW can perform an exhaustive search of all network structures followed by model averaging. The Bayesian network score of each possible network structure is calculated using the Bayesian network score provided by <a href="http://www.cran.r-project.org/web/packages/deal/index.html">deal</a>, an R package for Bayesian network strcutre learning, which can be used for discrete, continuous and hybrid data. Then, model averaging is performed to identify those directed edges that are included in many high scoring networks. Users can specify structural constraints after uploading their data file using the Structural Constraint Interface described below. We suggest that users limit networks to 5 nodes, if no structural constraints are used, or 6 or 7, if constraints are included. Click the "Exhaustive Search" button to select this structure learning method.
<br>
<br>
<vr>
<FORM METHOD="LINK" ACTION="bn_file_load.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Exhaustive search with model averaging" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
<br>
<br>
</td></tr>
<tr><td>
<h3> Global optimal search for discrete data</h3>
<p align="justify">
       This current version of the Bayesian Network Web Server also includes a global optimal search based structure learning algorithm which is available as a C language package, <a href="http://www.cs.helsinki.fi/u/tsilande/sw/bene/download/">bene-0.9.4</a>. This structure learning in its current format only supports discrete variables and returns only the best structure from a global optimal search. If users upload continuous data using this method, it will be discretized into three levels (low, midium and high) before structure learning is performed. This section does not support the addition of structural constraints. Click the "Global Optimal Search" button to select this structure learning method. It can be used to quickly learn the structure of networks with as many as 15 variables in a relatively short period of time. Follow the <a href="structure_learning2.htm">work flow</a> diagram of this structure learning for details.
<br>
<br>
<FORM METHOD="LINK" ACTION="file_preprocessing.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Global optimal search for discrete data" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
<br>
<br>
</td></tr>
<tr><td>
<h3> Global optimal search for all data types</h3>
<p align="justify">
  We have recently integrated the local scores provided by deal with the network structure search of the bene package, allowing for the identication of the global optimal network structure of continuous and hybrid datasets. This method supports the addition of structure learning constraints with our Structural Constraint Interface. In recent testing of BNW using this method with no constraints, learning the best scoring network for nodes with up to 7 variables took less than 15 seconds, an 8 variable network took 30 seconds, a 9 variable network took approximately 1 minute, and a 10 variable network took approximately 10 minutes. 
Click the "Continuous Global Optimal Search" button to select this structure learning. 
<br>
<br>
<FORM METHOD="LINK" ACTION="bn_file_load_gom.php">
<INPUT TYPE="hidden" NAME="My_key" value=<?php print($key) ?> >
<INPUT TYPE="submit" VALUE="Global optimal search for all data types" style="color: #fff; padding: 2px 5px; border: 2px solid; border-color: black black black black; background-color: #33339f; font-family: Georgia, ..., serif; font-size: 18px;
display: block; height: 30px; width: 350px;">
</FORM>
</p>
<br>
</td></tr>
</table>



<br>
<table>
<tr>
<a name=constraint_interface><h2>2. Structural constraint interface</h2></a>
</tr>
<br>
<tr><td>
<p align="justify">
BNW includes a Structural Constraint Interface that allows users to help 
limit structure learning to biologically or physically meaningful networks.
 The interface is separated into three sections: (1) assignment of nodes into tiers,
 (2) specification of the interactions allowed between and within tiers, and
 (3) the addition of specific edges that are banned or required in the network.
<br><br><b> Tier Assignment</b>: The first section of the page allows users to
 seperate the variables (nodes) in the network into tiers. By default, 3 tiers are
 shown, but users can change the number of tiers using the drop-down menu at the top of the page.
 For biological networks, Tier1 could contain a set of genotypes, Tier2 could contain gene expression traits,
 and Tier3 could contain phenotypes. Alternately, Tier2 could contain cis-regulated gene expression traits
 while Tier3 contains trans-regulated genes.<br><br>
       <b>Tier Interactions</b>: This section allows for the description of the interactions
 that are allowed within and between tiers. By default, edges are allowed 
 within tiers for all tiers and nodes within a tier are only allowed to be parents
 of nodes within lower ranking tiers. For example, nodes in Tier2 of a network
 with 4 tiers could be the parents of nodes in Tiers3 and 4, but could not be the parents
 of nodes in Tier1. Users can modify the allowed interactions to fit the details of their
 networks. For example, they may want to prohibit interactions within a tier containing
 a set of genotypes.<br><br><b>Specific Banned and Required Edges</b>: Finally,
 users can enter lists of banned and required edges to identify specific interactions that
 should or should not be included in the network. Banned edges can be used if experimental
 testing has shown that a particular regulatory relationship does not exist, while required
 edges can specify known regulatory relationships.
</p>
<br>
</td></tr>
</table>

<br>
<table>
<tr>
<a name=file_format><h2>3. Data formatting guidelines</h2></a>
</tr>
<br>
<tr>
<h3>Data file format</h3>
</tr>
<tr><td>
  <p align="justify"> Data files uploaded to the Bayesian Network Webserver should be tab-delimited text files with the names of the variables in the first row of the file and the values of the variables for each sample or individual in the remaining rows. <br><br>BNW automatically determines whether variables contain continuous or discrete data. To help ensure that BNW correctly parses data files, they should follow these formatting guidelines:<br>
  1. Variable names should start with a letter, not a number.<br>
  2. Discrete variables should be listed before continuous variables, that is, discrete variables should be the leftmost columns of the file.<br>
3. The values of the levels of discrete variables should be integers starting with 1.<br>
  4. The data values for each continuous variables should include a period (.) in at least one of the samples.<br><br>
    An example input data file for a file with 5 variables is given below. The network contains 2 discrete (Disc1 and Disc2) variables, which are given in the first two columns of the file, and 3 continuous variables (Cont1, Cont2, and Cont3). Disc1 is a discrete variable with two states (1 and 2), while Disc2 has three states (1, 2, and 3). Although the samples of Cont2 are integral values, we wish to deal with this variable as continuous, not discrete. Therefore, the value of Cont2 for the first sample is given as '3.0' instead of '3' so that one of the values of Cont2 contains a '.' and Cont2 is detected as a continuous variable.
</p>
<br>
<table>
<tr><th>Disc1</th><th>&nbsp;</th><th>Disc2</th><th>&nbsp;</th><th>Cont1</th><th>&nbsp;</th><th>Cont2</th><th>&nbsp;</th><th>Cont3</td></tr>
<tr>
<td>2</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>3.25</td><td>&nbsp;</td><td>3.0</td><td>&nbsp;</td><td>0.97</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>3</td><td>&nbsp;</td><td>2.46</td><td>&nbsp;</td><td>2</td><td>&nbsp;</td><td>0.93</td>
</tr>
<tr>
<td>1</td><td>&nbsp;</td><td>2</td><td>&nbsp;</td><td>4.21</td><td>&nbsp;</td><td>33</td><td>&nbsp;</td><td>0.43</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>3</td><td>&nbsp;</td><td>3.76</td><td>&nbsp;</td><td>8</td><td>&nbsp;</td><td>0.88</td>
</tr>
<tr>
<td>2</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>3.69</td><td>&nbsp;</td><td>4</td><td>&nbsp;</td><td>0.91</td>
</tr>
<tr>
<td>1</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>4.27</td><td>&nbsp;</td><td>13</td><td>&nbsp;</td><td>0.38</td>
</tr>
</table>
<br>
<br>
<h3>Structure file format</h3>
<p align="justify">
  If the structure of the network model for a dataset is already known, users can upload this structure by selecting "Upload structure" on the BNW home page. The structure file should be tab-delimited, with the variable names on the first row. The remainder of the file should be an n x n matrix of 0's and 1's, where n is the number of variables in the network. A '1' in row i and column j in this matrix indicates that there is a directed edge connecting variables i and j, (i.e., there is a edge from i to j in the network). '0' indicate that there is not a directed edge from variable i to variable j.
<br><br> An example of a structure data file is shown below. The following edges would be included in the network:
<br>1. Disc1 -> Cont1
<br>2. Dics2 -> Cont2
<br>3. Cont1 -> Cont3
<br>4. Cont2 -> Cont3 
</p>
<br>
<table>
<tr><th>Disc1</th><th>&nbsp;</th><th>Disc2</th><th>&nbsp;</th><th>Cont1</th><th>&nbsp;</th><th>Cont2</th><th>&nbsp;</th><th>Cont3</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td><td>&nbsp;</td><td>0</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>1</td></tr>
<tr><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td><td>&nbsp;</td><td>0</td></tr>
</table>
<br>
</table>

<br>
<table>
<tr>
<a name=browser_use><h2>4. Which browser should I use when acessing BNW?</h2></a>
</tr>
<br>
<tr><td>
  <p align="justify"> We are aware that the structural constraint interface does not display or operate correctly using Internet Explorer. This seems to be due to IE not supporting HTML5 drag-and-drop functions, and we have not noticed any problems with this interface using other web browsers. The majority of testing of BNW has been performed using recent versions of Google Chrome and Mozilla Firefox web browsers on computers with Windows operating systems. We have also done some preliminary tests using several browers on Linus and Apple computers and have not noticed significant problems.<br>
</p>
</td>
</tr>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>
</html>