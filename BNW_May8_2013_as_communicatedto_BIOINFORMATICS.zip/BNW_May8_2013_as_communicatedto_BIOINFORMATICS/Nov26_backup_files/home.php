<?php 

include("header_new.inc");
?>

<!-- Site navigation menu -->
<ul class="navbar">
  <li><a href="home.php">Home</a>
  <li><a href="home_structure.php">Structure Learning</a>
  <li><a href="home_upload.php">Upload structure</a>  
  <li><a href="workflow.php">Work flow diagrams</a>
  <li><a href="home_data.php">Data Formatting</a>
  <li><a href="">Help</a>


</ul>

<div id="outer">

<div align="left">
<MAP NAME="map1">
<AREA
 HREF="bn_file_load.php" ALT="Exhaustive search based structure learning" TITLE="Exhaustive search"
   SHAPE=RECT COORDS="10,140,300,350">
<AREA
 HREF="file_preprocessing.php" ALT="Global optimal search based structure learning" TITLE="Global optimal search"
   SHAPE=RECT COORDS="350,140,650,350">

<AREA
 HREF="bn_file_load_gom.php" ALT="Continuous global optimal search based structure learning" TITLE="Continuous global optimal search"
   SHAPE=RECT COORDS="700,140,1050,350">

</MAP>

<IMG SRC="flow.png"
   ALT="" BORDER=0 WIDTH=1050 HEIGHT=900
   USEMAP="#map1"><BR>
</div>

<!-- Main content -->
<br>
<h1>What is Bayesian Network Web Server?</h1>
<br>
<p align="justify"> The Bayesian Network Web Server (BNW) is a comprehensive web server for Bayesian network modeling. BNW can be used to perform structure and parameter learning of a Bayesian network model for user provided data sets. Users can then explore these models to investigate how observations alter the predictions of the network model. Many real world data sets, including those used to create genetic network models, contain both discrete (e.g., genotypes) and  continuous (e.g., gene expression traits), and BNW has been designed for modeling of these hybrid data sets.
</p>
<br>
<br>
<h1>Getting Started with Bayesian Network Web Server</h1>
<br>
<p align="justify"> To start using BNW, click <a href="home_structure.php">Structure Learning</a> and then select a structure learning algorithm. 
All the data upload sections come with one example data set. The input data file formats are described in the <a href="home_data.php">Data</a> section.
BNW also alow users to upload a network structure from <a href="home_upload.php">Upload structure</a>. <a href="workflow.php">Work flow diagrams</a>, 
describes the usage of structure learning algorithms, entering evidence data and predictions. A general help for each section of BNW is included in <a href="">Help</a>.
</p>
<br>
</div>
</body>
</html>