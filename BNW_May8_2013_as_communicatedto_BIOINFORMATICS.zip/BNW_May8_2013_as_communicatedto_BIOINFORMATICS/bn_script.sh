#!/bin/bash
start=$1

filename=${start}_run.R
echo 'source("get.trylist.R")' > $filename
echo 'nposs = get.trylist(use.banlist=TRUE,use.whitelist=TRUE,job.id='"'$1'"',standardize=TRUE)' >> $filename
bl=${start}banlist_temp.txt
wl=${start}whitelist_temp.txt
tl=${start}trylist_table.txt
tl_out=${start}trylist_out.txt
echo 'system("./wl_edit_trylist_table '$bl $wl $tl $tl_out'")' >> $filename
nl=${start}networks.txt
ml=${start}matrix.txt
echo 'system("./bn_exhaustive_search '$tl_out $nl $ml'")' >> $filename
R CMD BATCH --no-save $filename
